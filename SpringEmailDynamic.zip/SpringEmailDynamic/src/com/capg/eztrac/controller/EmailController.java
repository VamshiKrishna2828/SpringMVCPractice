package com.capg.eztrac.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capg.eztrac.beans.Per;
import com.capg.eztrac.service.EzTracMailServiceImpl;

@Controller
public class EmailController {
	
	@Autowired
	private EzTracMailServiceImpl mailService;
	
	@RequestMapping(value={"/"},method=RequestMethod.GET)
	public ModelAndView welcome(){
		System.out.println("In EmailController");
		Per per = new Per();
		ModelAndView mav = new ModelAndView("Welcome","title","Project Estimation Request");
		mav.addObject("per", per);
        return mav;
    }
	@RequestMapping(value={"/savePer"},method=RequestMethod.POST)
	public ModelAndView savePer(@ModelAttribute("per") Per per,BindingResult result){
		System.out.println("In EmailController savePer method"+per);
		HashMap<String,Object> mailInfoObject = new HashMap<String,Object>();
		mailInfoObject.put("from", "vemulavamsi.koundinya@gmail.com");
		mailInfoObject.put("password", "vamshilostmobile21");
		mailInfoObject.put("to", per.getMailTo());
		mailInfoObject.put("cc", per.getMailCc());
		mailInfoObject.put("bCc", per.getMailBcc());
		mailInfoObject.put("subject", per.getMailSubject());
		mailInfoObject.put("body", per.getMailBody());
		boolean success=true;
		if(success){
			mailService.sendEmail(mailInfoObject);
			System.out.println("In success after sendiing mail");
			ModelAndView mav = new ModelAndView("success","message","Your mail successfully delivered");
			return mav;
		}
		else{
			ModelAndView mav = new ModelAndView("success","message","Your mail successfully delivered");
			return mav;
		}
    }

}
