package com.capg.eztrac.service;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
@ComponentScan(basePackages="com.capg")
@PropertySource(value = { "classpath:application.properties" })
public class EzTracMailConfig {
	
	@Autowired
	Environment env;
	
	@Bean
	public JavaMailSender mailSender(){
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost(env.getProperty("mail.host"));
		mailSender.setPort(Integer.parseInt(env.getProperty("mail.port")));
		mailSender.setUsername(env.getProperty("mail.username"));
		mailSender.setPassword(env.getProperty("mail.password"));
		
		Properties javaMailProperties = new Properties();
        javaMailProperties.put("mail.smtp.starttls.enable",env.getProperty("mail.starttls.enable"));
        javaMailProperties.put("mail.smtp.auth", env.getProperty("mail.smtp.auth"));
        javaMailProperties.put("mail.transport.protocol", env.getProperty("mail.transport.protocol"));
        javaMailProperties.put("mail.debug", env.getProperty("mail.debug"));//Prints out everything on screen
        System.out.println(env.getProperty("mail.host")+" "+Integer.parseInt(env.getProperty("mail.port")));
        mailSender.setJavaMailProperties(javaMailProperties);
		return mailSender;
	}

}
