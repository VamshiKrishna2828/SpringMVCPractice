package com.capg.eztrac.service;

import java.util.HashMap;

public interface MailServiceInterface {

	public void sendEmail(HashMap<String,Object> mailInfo);

}
