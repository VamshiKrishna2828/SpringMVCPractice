package com.capg.eztrac.service;

import java.util.HashMap;

import javax.mail.Message;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

@Service("mailService")
public class EzTracMailServiceImpl implements MailServiceInterface{
	
	@Autowired
	private JavaMailSender mailSender;

	@Override
	public void sendEmail(HashMap<String,Object> mailInfo) {
		System.out.println("Testing MailSender"+mailSender);
		MimeMessagePreparator preparator = getMessagePreparator(mailInfo);
		mailSender.send(preparator);
	}
	public MimeMessagePreparator getMessagePreparator(final HashMap<String,Object> mailInfo){
		MimeMessagePreparator messagePreparator = new MimeMessagePreparator() {
			
			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				System.out.println("In prepare method");
				System.out.println(mailInfo.get("from").toString());
				System.out.println(mailInfo.get("to").toString());
				mimeMessage.setFrom(mailInfo.get("from").toString());
				mimeMessage.setRecipient(Message.RecipientType.TO,
                        new InternetAddress(mailInfo.get("to").toString()));
				mimeMessage.setRecipient(Message.RecipientType.CC,
                        new InternetAddress(mailInfo.get("cc").toString()));
				mimeMessage.setRecipient(Message.RecipientType.BCC,
                        new InternetAddress(mailInfo.get("bCc").toString()));
				mimeMessage.setText(mailInfo.get("body").toString());
                mimeMessage.setSubject(mailInfo.get("subject").toString());
				
			}
		};
		return messagePreparator;
		
	}
}
