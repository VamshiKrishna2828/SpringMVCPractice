package com.slokam.lps.applicationService;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.service.impl.ApplicationService;

public class TestApplicationService {

	@Test
	public void test() {
		ApplicationContext context=new ClassPathXmlApplicationContext("F:\\kalyani\\LPS\\ LoanProcessingSystemSecurity\\src\\spring-servlet.xml");
		ApplicationService service=(ApplicationService)context.getBean("applicationService");
		ApplicationPojo pojo=service.getApplication(1);
		Assert.assertEquals("lavanya reddy",pojo.getFirstname());
		
	}

}
