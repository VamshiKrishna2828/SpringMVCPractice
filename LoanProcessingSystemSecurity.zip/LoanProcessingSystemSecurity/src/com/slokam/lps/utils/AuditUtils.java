package com.slokam.lps.utils;

import java.lang.reflect.InvocationTargetException;
import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.AuditPojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.service.inter.IAuditService;
@Component
public class AuditUtils {
	@Autowired
	private IAuditService auditService;
	public void setAuditService(IAuditService auditService) {
		this.auditService = auditService;
	}
	public void auditCheck(Object pre,Object cur,UserPojo user)
	{
		String preVal="";
		String className=cur.getClass().toString();
		className=className.replace("class", "").trim();
		
		List<String> properties=auditService.getProperties(className);
		for(String property:properties)
			
		{
			try {
				/*if(pre==null)
				{
					preVal=BeanUtils.getProperty(cur, property);
				}*/
				if(pre!=null){
			
			    preVal=BeanUtils.getProperty(pre, property);
			
				String curVal=BeanUtils.getProperty(cur, property);
				if(!preVal.equals(curVal))
				{
					AuditPojo audit=new AuditPojo();
					audit.setNewVal(curVal);
					audit.setPreVal(preVal);
					audit.setProperty(property);
					audit.setUser(user);
					audit.setEntity(cur.getClass().getName());
					audit.setDateAndtime(new Date());
					auditService.saveAuditData(audit);
				}
				}
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
