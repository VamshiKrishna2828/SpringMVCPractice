package com.slokam.lps.service.impl;

import java.util.Collection;
import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.slokam.lps.dao.inter.ILoginDao;
import com.slokam.lps.pojo.Authority;
import com.slokam.lps.pojo.LoginUserDetailsPojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.service.inter.ILoginService;
@Service
public class LoginService implements ILoginService,UserDetailsService {
	@Autowired
   private ILoginDao loginDao;
	public UserPojo login(UserPojo user) {
		
		return loginDao.login(user);
	}
	@Override
	public UserDetails loadUserByUsername(String userName)
			throws UsernameNotFoundException {
		UserPojo userPojo=loginDao.login(userName);
		LoginUserDetailsPojo loginUser=new LoginUserDetailsPojo();
		loginUser.setAccountNonExpired(true);
		loginUser.setAccountNonLocked(true);
		loginUser.setCredentialsNonExpired(true);
		loginUser.setEnabled(true);
		loginUser.setUsername(userPojo.getUsername());
		loginUser.setPassword(userPojo.getPassword());
		loginUser.setUserPojo(userPojo);
		Authority auth=new Authority();
		auth.setAuthority(userPojo.getRole().getRoleCode());
		Collection<GrantedAuthority> authorities=new HashSet();
		authorities.add(auth);
		loginUser.setAuthorities(authorities);
		return loginUser;
		
		
		
	}
	

}
