package com.slokam.lps.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.slokam.lps.dao.inter.IApplicationDao;
import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.CountryPojo;
import com.slokam.lps.pojo.QualificationPojo;
import com.slokam.lps.pojo.StatePojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.pojo.WorkItemPojo;
import com.slokam.lps.service.inter.IApplicationService;
@Service
public class ApplicationService implements IApplicationService {
   @Autowired
   private IApplicationDao dao;
	public void setDao(IApplicationDao dao) {
	this.dao = dao;
}

	@Override
	public void saveApplication(ApplicationPojo pojo) {
	dao.saveApplication(pojo);	
		
	}
	
	public List<WorkItemPojo> getWorkItems(UserPojo user) {
		
		return dao.getWorkItems(user);
	}

	@Override
	@Transactional(readOnly=true)
	public ApplicationPojo getApplication(Integer id) {
		
		return dao.getApplication(id);
	}

	@Override
	@Transactional(isolation=Isolation.DEFAULT,propagation=Propagation.REQUIRED,timeout=1000,
	rollbackFor=Exception.class)
	public void updateApplication(ApplicationPojo pojo) {
		dao.updateApplication(pojo);
		
	}

	@Override
	public UserPojo getPrevOwner(Integer workitenId, Integer currentUserid) {
		
		return dao.getPrevOwner(workitenId, currentUserid);
	}

	@Override
	public ApplicationPojo getApplication(String firstName) {
		 return dao.getApplication(firstName);
		
	}

	@Override
	public List<QualificationPojo> getQualifications(String qual) {
		
		return dao.getQualifications(qual);
	}

	@Override
	public List<CountryPojo> getCountries() {
		
		return dao.getCountries();
	}

	@Override
	public List<StatePojo> getStates(Integer countryId) {
		
		return dao.getStates(countryId) ;
	}
	
	

}
