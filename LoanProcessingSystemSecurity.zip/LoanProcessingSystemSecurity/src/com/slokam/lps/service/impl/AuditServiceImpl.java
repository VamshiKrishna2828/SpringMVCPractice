package com.slokam.lps.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.slokam.lps.dao.inter.IAuditDao;
import com.slokam.lps.pojo.AuditPojo;
import com.slokam.lps.service.inter.IAuditService;

@Service
public class AuditServiceImpl implements IAuditService {
	@Autowired
    private IAuditDao auditDao;

	@Override
	public void saveAuditData(AuditPojo auditPojo) {
		auditDao.saveAuditData(auditPojo);
		
	}

	@Override
	public List<String> getProperties(String entity) {
		
		return auditDao.getProperties(entity);
	}
	
	
}
