package com.slokam.lps.service.inter;

import java.util.List;

import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.CountryPojo;
import com.slokam.lps.pojo.QualificationPojo;
import com.slokam.lps.pojo.StatePojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.pojo.WorkItemPojo;

public interface IApplicationService {
public void saveApplication(ApplicationPojo pojo);
public void updateApplication(ApplicationPojo pojo);
public List<WorkItemPojo> getWorkItems(UserPojo user);
public ApplicationPojo getApplication(Integer id);
public UserPojo getPrevOwner(Integer workitenId,Integer currentUserid);
public ApplicationPojo getApplication(String firstName);
public List<QualificationPojo> getQualifications(String qual);
public List<CountryPojo> getCountries();
public List<StatePojo> getStates(Integer countryId);
}
