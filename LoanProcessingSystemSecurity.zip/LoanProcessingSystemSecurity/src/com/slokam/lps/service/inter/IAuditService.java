package com.slokam.lps.service.inter;

import java.util.List;

import com.slokam.lps.pojo.AuditPojo;

public interface IAuditService {
	public void saveAuditData(AuditPojo auditPojo);
	public List<String> getProperties(String entity);
}
