package com.slokam.lps.service.inter;

import com.slokam.lps.pojo.UserPojo;

public interface ILoginService {
public UserPojo login(UserPojo user);

}
