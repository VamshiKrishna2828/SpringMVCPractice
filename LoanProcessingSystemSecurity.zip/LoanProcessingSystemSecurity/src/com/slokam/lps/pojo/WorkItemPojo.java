package com.slokam.lps.pojo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="workitem")
public class WorkItemPojo {
private Integer id;
private ApplicationPojo application;
private UserPojo owner;
private List<WorkItemLogPojo> wilpojo;
@Id
@GeneratedValue
@Column(name="id")
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
@OneToOne
@JoinColumn(name="applicationid")

public ApplicationPojo getApplication() {
	return application;
}
public void setApplication(ApplicationPojo application) {
	this.application = application;
}
@OneToOne
@JoinColumn(name="ownerid")
public UserPojo getOwner() {
	return owner;
}
public void setOwner(UserPojo owner) {
	this.owner = owner;
}
@OneToMany(mappedBy="workitem",cascade=CascadeType.ALL)
public List<WorkItemLogPojo> getWilpojo() {
	return wilpojo;
}
public void setWilpojo(List<WorkItemLogPojo> wilpojo) {
	this.wilpojo = wilpojo;
}
}
