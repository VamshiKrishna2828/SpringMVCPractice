package com.slokam.lps.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="qualification")
public class QualificationPojo {
private Integer id;
private String qualName;
private Integer duration;
@Id
@GeneratedValue
@Column(name="id")
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
@Column(name="qualname")
public String getQualName() {
	return qualName;
}
public void setQualName(String qualName) {
	this.qualName = qualName;
}
@Column(name="duration")
public Integer getDuration() {
	return duration;
}
public void setDuration(Integer duration) {
	this.duration = duration;
}
}
