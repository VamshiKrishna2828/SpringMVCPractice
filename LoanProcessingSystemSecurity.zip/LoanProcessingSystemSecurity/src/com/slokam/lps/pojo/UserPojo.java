package com.slokam.lps.pojo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="login")
public class UserPojo {
private Integer id;
private String username;
private String password;
private UserPojo superUser;
private RolePojo role;

@OneToOne
@JoinColumn(name="role")
public RolePojo getRole() {
	return role;
}
public void setRole(RolePojo role) {
	this.role = role;
}
private String roleCode;
@Id
@GeneratedValue
@Column(name="id")
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
@Column(name="name")
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
@Column(name="password")
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Transient
public String getRoleCode() {
	return roleCode;
}
public void setRoleCode(String roleCode) {
	this.roleCode = roleCode;
}
@OneToOne(fetch=FetchType.LAZY)
@JoinColumn(name="superuser")

//@Transient
public UserPojo getSuperUser() {
	return superUser;
}
public void setSuperUser(UserPojo superUser) {
	this.superUser = superUser;
}




}
