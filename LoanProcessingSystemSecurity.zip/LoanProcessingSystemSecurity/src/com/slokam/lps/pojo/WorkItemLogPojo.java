package com.slokam.lps.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="workitemlog")
public class WorkItemLogPojo {
private Integer id;
private WorkItemPojo workitem;
private UserPojo fromUser;
private UserPojo toUser;
@Id
@GeneratedValue
@Column(name="id")
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
@ManyToOne
@JoinColumn(name="workitemid")
public WorkItemPojo getWorkitem() {
	return workitem;
}
public void setWorkitem(WorkItemPojo workitem) {
	this.workitem = workitem;
}
@OneToOne
@JoinColumn(name="fromid")
public UserPojo getFromUser() {
	return fromUser;
}
public void setFromUser(UserPojo fromUser) {
	this.fromUser = fromUser;
}
@OneToOne
@JoinColumn(name="toid")
public UserPojo getToUser() {
	return toUser;
}
public void setToUser(UserPojo toUser) {
	this.toUser = toUser;
}

}
