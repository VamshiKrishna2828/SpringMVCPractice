package com.slokam.lps.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="application")

public class ApplicationPojo {
@NotBlank(message="Please provide firstname")
private String firstname;
private String lastname;
@NotBlank(message="Please select M or F")
//@Email
private String gender;
@Pattern(regexp="^[A-Z]{5}[0-9]{4}[A-Z]$",message="Please provide proper format")
private String qual;
@Min(value=18)
@Max(50)
private Integer age;
private Integer id;
@Pattern(regexp="^[0-9]{10}$")
private String phone;
private MultipartFile formFile;
private Integer countryId;
private Integer stateId;
@Column(name="sid")
public Integer getStateId() {
	return stateId;
}
public void setStateId(Integer stateId) {
	this.stateId = stateId;
}
@Column(name="cid")
public Integer getCountryId() {
	return countryId;
}
public void setCountryId(Integer countryId) {
	this.countryId = countryId;
}
@Id
@GeneratedValue
@Column(name="id")
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
private WorkItemPojo workitem;

@OneToOne(mappedBy="application", cascade=CascadeType.ALL)

public WorkItemPojo getWorkitem() {
	return workitem;
}
public void setWorkitem(WorkItemPojo workitem) {
	this.workitem = workitem;
}

@Column(name="firstname")

public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
@Column(name="lastname")
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
@Column(name="gender")
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
@Column(name="qual")
public String getQual() {
	return qual;
}
public void setQual(String qual) {
	this.qual = qual;
}
@Column(name="age")
public Integer getAge() {
	return age;
}
public void setAge(Integer age) {
	this.age = age;
}
@Column(name="phone")
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
@Transient
public MultipartFile getFormFile() {
	return formFile;
}
public void setFormFile(MultipartFile formFile) {
	this.formFile = formFile;
}



}
