package com.slokam.lps.pojo;

import org.springframework.security.core.GrantedAuthority;

public class Authority implements GrantedAuthority{
  private String authority;
  
  
	public void setAuthority(String authority) {
	this.authority = authority;
}
	@Override
	public String getAuthority() {
		// TODO Auto-generated method stub
		return authority;
	}

}
