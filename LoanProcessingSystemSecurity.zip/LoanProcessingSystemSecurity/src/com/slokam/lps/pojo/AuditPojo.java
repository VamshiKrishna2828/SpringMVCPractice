package com.slokam.lps.pojo;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="audit")
public class AuditPojo {
private Integer id;
private String preVal;
private String newVal;
private String property;
private UserPojo user;
private String entity;
private Date dateAndtime;
@Id
@GeneratedValue
@Column(name="id")

public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
@Column(name="preVal")
public String getPreVal() {
	return preVal;
}
public void setPreVal(String preVal) {
	this.preVal = preVal;
}
@Column(name="newVal")
public String getNewVal() {
	return newVal;
}
public void setNewVal(String newVal) {
	this.newVal = newVal;
}
@Column(name="property")
public String getProperty() {
	return property;
}
public void setProperty(String property) {
	this.property = property;
}
@OneToOne
@JoinColumn(name="user")
public UserPojo getUser() {
	return user;
}
public void setUser(UserPojo user) {
	this.user = user;
}
@Column(name="entity")
public String getEntity() {
	return entity;
}
public void setEntity(String entity) {
	this.entity = entity;
}
@Column(name="dateandtime")
public Date getDateAndtime() {
	return dateAndtime;
}
public void setDateAndtime(Date dateAndtime) {
	this.dateAndtime = dateAndtime;
}


}
