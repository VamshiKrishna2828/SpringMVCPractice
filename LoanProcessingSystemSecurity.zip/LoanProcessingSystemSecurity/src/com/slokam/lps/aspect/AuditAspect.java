package com.slokam.lps.aspect;

import java.util.ArrayList;
import java.util.Map;


import java.util.Set;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.LoginUserDetailsPojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.utils.AuditUtils;

@Aspect
@Component
public class AuditAspect{

	@Autowired
	private AuditUtils auditUtils;
	
	public void setAuditUtils(AuditUtils auditUtils) {
		this.auditUtils = auditUtils;
	}
	@AfterReturning(pointcut="execution(* com.slokam.lps.controller.*.display*(..))",returning="object")
	public ModelAndView getSessionData(JoinPoint joinpoint,ModelAndView object )
	{
		
		Map modelMap=object.getModelMap();
		/*Set set=modelMap.entrySet();
		for(Object obj:set)
		{
			oldObj=obj;
		}*/
		//Object oldObject=object.getModel();
		Object oldobj= modelMap.get("oldObj");
		
		LoginUserDetailsPojo ludp=(LoginUserDetailsPojo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		ludp.setObj(oldobj);
		
		return object;
		
		
	}
	@After("execution(* com.slokam.lps.controller.*.save*(..))")
	public void saveAudit(JoinPoint joinpoint)
	{
		
		Object[] args=joinpoint.getArgs();
		Object currentObj=args[0];
		LoginUserDetailsPojo ludp=(LoginUserDetailsPojo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		Object oldObj=ludp.getObj();
		UserPojo user=ludp.getUserPojo();
		/*ArrayList<String> properties=new ArrayList<String>();
		properties.add("firstname");
		properties.add("lastname");
		properties.add("age");
		properties.add("gender");
		properties.add("phone");
		properties.add("qual");*/
		auditUtils.auditCheck(oldObj, currentObj, user);
		
	}
	
	
}
