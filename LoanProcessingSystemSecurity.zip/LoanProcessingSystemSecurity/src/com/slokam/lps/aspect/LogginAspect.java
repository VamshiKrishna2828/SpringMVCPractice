package com.slokam.lps.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.slokam.lps.pojo.UserPojo;

@Aspect
@Component
public class LogginAspect {
	@Before("execution(* com.slokam.lps.*.*.*(..))")
	public void BeforeMethod(JoinPoint joinpont){

	System.out.println("Before Method::"+joinpont.getSignature().getName()+"::"+joinpont.getTarget().getClass());
	}
	@After("execution(* com.slokam.lps.*.*.*(..))")
	public void afterMethod(JoinPoint joinpont)
	{
		System.out.println("After Method::"+joinpont.getSignature().getName()+"::"+joinpont.getTarget().getClass());
	}
	@AfterReturning(pointcut="execution(* com.slokam.lps.dao.inter.ILoginDao.login(..))",returning="obj")
	public void afterReturn(JoinPoint joinpoint,UserPojo obj)
	{
			System.out.println("Hello iam in after return::"+joinpoint.getSignature().getName()+"::"+obj.getRole().getRoleCode());
	}
	@AfterThrowing(pointcut="execution(* com.slokam.lps.dao.inter.ILoginDao.login(..))",throwing="exobj")
	public void afterThrow(JoinPoint joinpoint,Throwable exobj)
	{
	System.out.println("After throwing:"+exobj.getMessage()+"::"+joinpoint.getSignature().getName());
	
	}

}
