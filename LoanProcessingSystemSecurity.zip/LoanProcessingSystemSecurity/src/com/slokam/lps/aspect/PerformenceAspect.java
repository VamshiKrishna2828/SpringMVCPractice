package com.slokam.lps.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class PerformenceAspect {
	Object obj=null;
  @Around("execution(* com.slokam.lps.*.*.*(..))")
  
	public Object execution(ProceedingJoinPoint pjoinpoint)
	{
	  long startTime=System.currentTimeMillis();
	  try {
		obj=pjoinpoint.proceed();
	} catch (Throwable e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  long endTime=System.currentTimeMillis();
	  System.out.println("TimeTaken:"+(endTime=startTime)+"::"+pjoinpoint.getSignature().getName());
		return obj;
		
	}
}
