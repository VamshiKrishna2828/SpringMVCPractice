package com.slokam.lps.exception;

public class LpsException extends Exception {
public LpsException(String msg)
{
	super(msg);
}

}
