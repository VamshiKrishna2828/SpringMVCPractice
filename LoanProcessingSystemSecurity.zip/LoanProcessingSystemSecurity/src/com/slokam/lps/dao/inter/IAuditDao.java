package com.slokam.lps.dao.inter;

import java.util.List;

import com.slokam.lps.pojo.AuditPojo;

public interface IAuditDao {
public void saveAuditData(AuditPojo auditPojo);
public List<String> getProperties(String entity);


}
