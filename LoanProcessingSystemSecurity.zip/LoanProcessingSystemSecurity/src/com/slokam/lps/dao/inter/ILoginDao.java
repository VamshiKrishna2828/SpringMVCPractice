package com.slokam.lps.dao.inter;

import com.slokam.lps.pojo.UserPojo;

public interface ILoginDao {
public UserPojo login(UserPojo pojo) ;
public UserPojo login(String userName);
}
