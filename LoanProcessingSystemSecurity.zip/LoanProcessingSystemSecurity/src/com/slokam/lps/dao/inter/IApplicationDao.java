package com.slokam.lps.dao.inter;

import java.util.List;

import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.AuditPojo;
import com.slokam.lps.pojo.CountryPojo;
import com.slokam.lps.pojo.QualificationPojo;
import com.slokam.lps.pojo.StatePojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.pojo.WorkItemPojo;

public interface IApplicationDao {
public void saveApplication(ApplicationPojo pojo);
public List<WorkItemPojo> getWorkItems(UserPojo user);

public ApplicationPojo getApplication(Integer id);
public void updateApplication(ApplicationPojo application);
public UserPojo getPrevOwner(Integer workitenId,Integer currentUserid);
public ApplicationPojo getApplication(String firstName);
public List<QualificationPojo> getQualifications(String qual);
public List<CountryPojo> getCountries();
public List<StatePojo> getStates(Integer countryId);

}
