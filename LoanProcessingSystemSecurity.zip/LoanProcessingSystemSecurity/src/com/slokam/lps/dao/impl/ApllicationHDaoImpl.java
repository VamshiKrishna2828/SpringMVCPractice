package com.slokam.lps.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.slokam.lps.dao.inter.IApplicationDao;
import com.slokam.lps.dao.inter.ILoginDao;
import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.AuditPojo;
import com.slokam.lps.pojo.CountryPojo;
import com.slokam.lps.pojo.QualificationPojo;
import com.slokam.lps.pojo.StatePojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.pojo.WorkItemPojo;
@Repository
public class ApllicationHDaoImpl implements IApplicationDao {
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void saveApplication(ApplicationPojo pojo) {
		hibernateTemplate.save(pojo);	
		
	}
	public List<WorkItemPojo> getWorkItems(UserPojo user){
		List<WorkItemPojo> list=hibernateTemplate.find("select w from WorkItemPojo w"
				+ " join w.owner o where o.id=?",user.getId());
		
			
		return list;
		
		
	}
	
	
	public ApplicationPojo getApplication(Integer id)
	{
		return hibernateTemplate.get(ApplicationPojo.class, id);
	}
	@Override
	public void updateApplication(ApplicationPojo application) {
		hibernateTemplate.update(application);	
	}
	@Override
	public UserPojo getPrevOwner(Integer workitemId, Integer currentUserid) {
		String query="select fu from WorkItemLogPojo wl join "
				+ "wl.workitem w join wl.toUser tu join wl.fromUser fu"
				+ " where w.id=? and tu.id=?";
		List<UserPojo> list=hibernateTemplate.find(query,workitemId,currentUserid);
		if(list.size()>0)
			return list.get(0);
		else
		return null;
	}
	@Override
	public ApplicationPojo getApplication(String firstName) {
		String query="from ApplicationPojo where firstname=?";
		List<ApplicationPojo> list=hibernateTemplate.find(query,firstName);
		if(list.size()>0)
		{
			return list.get(0);
		}
		return null;
	}
	@Override
	public List<QualificationPojo> getQualifications(String qual) {
		String hql="from QualificationPojo where qualName like ?";
		List<QualificationPojo> qualList=hibernateTemplate.find(hql,qual+"%");
		System.out.println(qualList);
		return qualList;
	}
	@Override
	public List<CountryPojo> getCountries() {
		
		return hibernateTemplate.find("from CountryPojo") ;
	}
	@Override
	public List<StatePojo> getStates(Integer countryId) {
		
		return  hibernateTemplate.find("from StatePojo where cid=?",countryId) ;
	}
	
	
}
	
	
	