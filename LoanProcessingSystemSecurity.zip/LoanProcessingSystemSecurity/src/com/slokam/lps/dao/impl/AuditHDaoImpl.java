package com.slokam.lps.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.slokam.lps.dao.inter.IAuditDao;
import com.slokam.lps.pojo.AuditPojo;
@Repository
public class AuditHDaoImpl implements IAuditDao {
	@Autowired
  private HibernateTemplate hibernateTemplate;
	
	public void saveAuditData(AuditPojo auditPojo) {
		hibernateTemplate.save(auditPojo);

	}

	@Override
	public List<String> getProperties(String entity) {
		String hql="select property from EntityPojo where name=?";
		List<String> properties=hibernateTemplate.find(hql,entity);
		return properties;
	}

}
