package com.slokam.lps.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.slokam.lps.dao.inter.IApplicationDao;
import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.AuditPojo;
import com.slokam.lps.pojo.CountryPojo;
import com.slokam.lps.pojo.QualificationPojo;
import com.slokam.lps.pojo.StatePojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.pojo.WorkItemPojo;


public class ApplicationDao implements IApplicationDao {
  @Autowired
  private JdbcTemplate template;
	@Override
	public void saveApplication(ApplicationPojo pojo) {
	String sql="insert into application(firstname,lastname,qual,age,gender,phoneno) "
			+ "values(?,?,?,?,?,?)";
	Object[] params=new Object[6];
	params[0]=pojo.getFirstname();
	params[1]=pojo.getLastname();
	params[2]=pojo.getQual();
	params[3]=pojo.getAge();
	params[4]=pojo.getGender();
	params[5]=pojo.getPhone();
	template.update(sql, params);
		 
	}
	@Override
	public List<WorkItemPojo> getWorkItems(UserPojo user) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ApplicationPojo getApplication(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void updateApplication(ApplicationPojo application) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public UserPojo getPrevOwner(Integer workitenId, Integer currentUserid) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ApplicationPojo getApplication(String firstName) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<QualificationPojo> getQualifications(String qual) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<CountryPojo> getCountries() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<StatePojo> getStates(Integer countryId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
