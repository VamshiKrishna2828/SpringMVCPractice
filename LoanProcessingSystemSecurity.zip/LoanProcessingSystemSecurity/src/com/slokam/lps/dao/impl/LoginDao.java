package com.slokam.lps.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.slokam.lps.dao.inter.ILoginDao;
import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.rowmapper.LoginRowMapper;


public class LoginDao implements ILoginDao {
	@Autowired
	private JdbcTemplate template;
	

	public UserPojo login(UserPojo pojo) {
		String sql="select l.name as name,l.password as "
				+ "pwd,r.roleCode as rcode from login l join role r on l.roleid=r.id "
				+ "where l.name=? and l.password=?";
				
		return template.queryForObject(sql,new LoginRowMapper(),pojo.getUsername(),pojo.getPassword());		
		
		
	}


	@Override
	public UserPojo login(String userName) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}
