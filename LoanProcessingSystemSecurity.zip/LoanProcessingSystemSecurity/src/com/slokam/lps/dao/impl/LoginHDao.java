package com.slokam.lps.dao.impl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.slokam.lps.dao.inter.ILoginDao;
import com.slokam.lps.pojo.RolePojo;
import com.slokam.lps.pojo.UserPojo;
@Repository
public class LoginHDao implements ILoginDao {
	@Autowired
  private HibernateTemplate htemplate;
	
	

	@Override
	public UserPojo login(UserPojo pojo) {
		UserPojo pojo1=null;
		RolePojo role=null;
		UserPojo superUser=null;
		List<Object[]> list=htemplate.find("select u,r,s from UserPojo u join u.role r join u.superUser s "
				+ " where u.username=? and u.password=?",pojo.getUsername(),pojo.getPassword());
		
		if(list.size()>0){
		   Object[] records=list.get(0);
			 pojo1=(UserPojo)records[0];
			role=(RolePojo)records[1];
			UserPojo sUser=(UserPojo) records[2];
			//superUser=(UserPojo) object[2];
			//pojo1.setSuperUser(superUser);
			pojo1.setRole(role);
			pojo1.setSuperUser(sUser);
		
		return pojo1;
		}
		
		else
		return null;
	}



	@Override
	public UserPojo login(String userName) {
		
		UserPojo pojo1=null;
		RolePojo role=null;
		UserPojo superUser=null;
		List<Object[]> list=htemplate.find("select u,r,s from UserPojo u join u.role r join u.superUser s "
				+ " where u.username=?",userName);
		if(list.size()>0){
		   Object[] records=list.get(0);
			 pojo1=(UserPojo)records[0];
			role=(RolePojo)records[1];
			UserPojo sUser=(UserPojo) records[2];
			//superUser=(UserPojo) object[2];
			//pojo1.setSuperUser(superUser);
			pojo1.setRole(role);
			pojo1.setSuperUser(sUser);
		
		return pojo1;
		}
		
		else
		return null;
	}



	
	

	/*public UserPojo login(UserPojo pojo){
		List<UserPojo> list=htemplate.find("from UserPojo where username=? and password=?",pojo.getUsername(),pojo.getPassword());
		
		if(list.size()>0)
			return list.get(0);
		else
			return null;
	}
	*/
	
	
}
