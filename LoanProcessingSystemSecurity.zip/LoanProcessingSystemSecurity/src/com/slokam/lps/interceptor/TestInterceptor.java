package com.slokam.lps.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

public class TestInterceptor implements HandlerInterceptor {

	@Override
	public void afterCompletion(HttpServletRequest arg0,
			HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		Long startTime=(Long)arg0.getAttribute("startTime");
		Long endTime=(Long)arg0.getAttribute("endTime");
		Long timeTaken=(endTime-startTime);
		
		System.out.println("after completion Time taken::"+timeTaken);
		
	}

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1,
			Object arg2, ModelAndView arg3) throws Exception {
		long endTime=System.currentTimeMillis();
		arg0.setAttribute("endTime", endTime);
		System.out.println("postHandle");
		
	}

	@Override
	public boolean preHandle(HttpServletRequest arg0, HttpServletResponse arg1,
			Object arg2) throws Exception {
		long startTime=System.currentTimeMillis();
		
		arg0.setAttribute("startTime", startTime);
		
		
		System.out.println("preHandle");
		return true;
	}

}
