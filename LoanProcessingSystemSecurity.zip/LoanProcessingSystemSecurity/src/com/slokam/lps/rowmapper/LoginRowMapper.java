package com.slokam.lps.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.slokam.lps.pojo.UserPojo;

public class LoginRowMapper implements RowMapper<UserPojo> {

	public UserPojo mapRow(ResultSet rs, int arg1) throws SQLException {
		UserPojo result=new UserPojo();
		result.setUsername(rs.getString("name"));
		result.setPassword(rs.getString("pwd"));
		result.setRoleCode(rs.getString("rcode"));
		return result;
	}

	

}
