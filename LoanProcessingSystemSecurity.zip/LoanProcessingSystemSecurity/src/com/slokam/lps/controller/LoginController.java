package com.slokam.lps.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.CountryPojo;
import com.slokam.lps.pojo.LoginUserDetailsPojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.pojo.WorkItemPojo;
import com.slokam.lps.service.inter.IApplicationService;
import com.slokam.lps.service.inter.ILoginService;

@Controller
public class LoginController {
	@Autowired
	private ILoginService loginService;
	String nextView="";
	@Autowired
	private IApplicationService applicationService;
	
	@RequestMapping("loginDisplay")
	public String loginDisplay()
	{
		System.out.println("iam in login");
		return "login";
	}
	
	/*@RequestMapping("login")
	public ModelAndView login(UserPojo user,HttpSession session)
	{
		ModelAndView mv=null;
		Integer id=null;
		UserPojo pojo=loginService.login(user);
		//System.out.println(pojo.getSuperUser().getId());
		//UserPojo superUser=pojo.getSuperUser();
		session.setAttribute("superUser", pojo);
		if(pojo==null)
		{
     	mv=new ModelAndView("login");
		}
		else if(pojo.getRole().getRoleCode().equals("CU"))
		{
			mv=new ModelAndView("custHome");
			
		}
		else 
		{
			List<WorkItemPojo> workItems=applicationService.getWorkItems(pojo);
			
			
			
//			session.setAttribute("workitems", workItems);
//			mv=new ModelAndView("workitem");
			mv=new ModelAndView("workitem","workItems",workItems);
		}
		
		return mv;
	}*/
	@RequestMapping("loginSuccess")
	public ModelAndView login(UserPojo user,HttpSession session)
	{
		ModelAndView mv=null;
		Integer id=null;
		LoginUserDetailsPojo ludp=(LoginUserDetailsPojo) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		System.out.println(ludp.getUsername());
		
		UserPojo pojo=ludp.getUserPojo();
		System.out.println(pojo.getUsername());
		//System.out.println(pojo.getSuperUser().getId());
		//UserPojo superUser=pojo.getSuperUser();
		session.setAttribute("superUser", pojo);
		if(pojo==null)
		{
     	mv=new ModelAndView("login");
		}
		else if(pojo.getRole().getRoleCode().equals("cu"))
		{
			List<CountryPojo> countries=applicationService.getCountries();
			mv = new ModelAndView("custHome");
			Map map = mv.getModelMap();
			map.put("application", new ApplicationPojo());
			map.put("countries", countries);
			

			//mv=new ModelAndView("custHome","application",new ApplicationPojo());
			
		}
		else 
		{
			List<WorkItemPojo> workItems=applicationService.getWorkItems(pojo);
			
			
			
//			session.setAttribute("workitems", workItems);
//			mv=new ModelAndView("workitem");
			mv=new ModelAndView("workitem","workItems",workItems);
		}
		
		return mv;
	}


}
