package com.slokam.lps.controller;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;






import javax.validation.Valid;

import org.aspectj.weaver.World;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.slokam.lps.pojo.ApplicationPojo;
import com.slokam.lps.pojo.AuditPojo;
import com.slokam.lps.pojo.CountryPojo;
import com.slokam.lps.pojo.QualificationPojo;
import com.slokam.lps.pojo.StatePojo;
import com.slokam.lps.pojo.UserPojo;
import com.slokam.lps.pojo.WorkItemLogPojo;
import com.slokam.lps.pojo.WorkItemPojo;
import com.slokam.lps.service.inter.IApplicationService;
import com.slokam.lps.service.inter.IAuditService;
import com.slokam.lps.utils.AuditUtils;

import org.apache.commons.beanutils.BeanUtils;
@Controller
public class ApplicationController {
@Autowired
private IApplicationService applicationService;
@Autowired
private IAuditService auditService;
@Autowired
private AuditUtils auditUtils;
@RequestMapping("saveApplication")
public ModelAndView saveApplication(@ModelAttribute("application")
@Valid ApplicationPojo app,BindingResult result, HttpServletRequest request,
		Integer workitemid,HttpSession session)
{
	ModelAndView mv=new ModelAndView("custHome");
	List<CountryPojo> countries=applicationService.getCountries();
	List<StatePojo> states=applicationService.getStates(app.getCountryId());
	
	Map map=mv.getModelMap();
	map.put("states", states);
	map.put("application", app);
	map.put("countries", countries);
	map.put("success","Successfully inserted");
	if(result.hasErrors())
	{
		return mv;
	}
	ApplicationPojo app1=new ApplicationPojo();
	UserPojo owner=(UserPojo) session.getAttribute("superUser");
	/*UserPojo owner=new UserPojo();
	owner.setId(7);
	System.out.println(owner.getId());*/
	WorkItemPojo workItem =new WorkItemPojo();
	
	workItem.setOwner(owner.getSuperUser());
	workItem.setApplication(app);
	app.setWorkitem(workItem);
	
	if(owner.getRole().getRoleCode().equals("CU"))
	{
		
   applicationService.saveApplication(app);
   
   MultipartFile formfile=app.getFormFile();
	System.out.println(formfile.getOriginalFilename());
	//File file=new File(" "+formfile.getOriginalFilename());
	File file=new File("F:/uploadedFiles/"+formfile.getOriginalFilename());
	try {
		formfile.transferTo(file);
	} catch (IllegalStateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
	
	else{
		WorkItemLogPojo wilpojo=new WorkItemLogPojo();
		wilpojo.setWorkitem(workItem);
		wilpojo.setFromUser(owner);
		wilpojo.setToUser(owner.getSuperUser());
		ArrayList<WorkItemLogPojo > list=new ArrayList();
		list.add(wilpojo);
		workItem.setWilpojo(list);
		
		workItem.setId(workitemid);
	
	/*ApplicationPojo oldApp=(ApplicationPojo)session.getAttribute("auditApp");
	ArrayList<String> properties=new ArrayList<String>();
	properties.add("firstname");
	properties.add("lastname");
	properties.add("age");
	properties.add("gender");
	properties.add("phone");
	properties.add("qual");
	auditUtils.auditCheck(oldApp, app, properties, owner);
	session.setAttribute("auditApp", app);*/
	applicationService.updateApplication(app);

	
	
	}
	
	
	request.setAttribute("application", app);
	
	return mv;
   /*return new ModelAndView("custHome","success","Successfully inserted") ;*/
   
}
@RequestMapping("displayApplication")
public ModelAndView displayApplication(Integer appId,HttpSession session)
{
	ApplicationPojo application=applicationService.getApplication(appId);
	List<CountryPojo> countries=applicationService.getCountries();
	List<StatePojo> states=applicationService.getStates(application.getCountryId());
	ModelAndView mv=new ModelAndView("custHome");
	Map modelMap=mv.getModelMap();
	modelMap.put("application", application);
	modelMap.put("oldObj", application);
	modelMap.put("countries", countries);
	modelMap.put("states",states);
	return mv;
	//session.setAttribute("auditApp", application);new ModelAndView("custHome","application",application);
}
@RequestMapping("rejectApplication")
public ModelAndView rejectApplication(ApplicationPojo application,Integer workitemid,HttpSession session)
{
	UserPojo owner=(UserPojo) session.getAttribute("superUser");
	/*UserPojo owner=new UserPojo();
	owner.setId(7);
	System.out.println(owner.getId());*/
	UserPojo PreviousOwner=applicationService.getPrevOwner(workitemid, owner.getId());
	
	WorkItemPojo workItem =new WorkItemPojo();
	workItem.setOwner(PreviousOwner);
	workItem.setApplication(application);
	workItem.setId(workitemid);
	
	 WorkItemLogPojo wilpojo=new WorkItemLogPojo();
	 wilpojo.setWorkitem(workItem);
	 wilpojo.setFromUser(owner);
	 wilpojo.setToUser(PreviousOwner);
	 
	 ArrayList<WorkItemLogPojo> worklogs=new ArrayList<WorkItemLogPojo>();
	 worklogs.add(wilpojo);
	 workItem.setWilpojo(worklogs);
	 application.setWorkitem(workItem);
	 
	 applicationService.updateApplication(application);
	
	return new ModelAndView("custHome","application",application);
}
@RequestMapping("checkName")
public ModelAndView checkName(ApplicationPojo application,HttpServletRequest request)
{
	
	ApplicationPojo app=applicationService.getApplication(application.getFirstname());
	if(app==null)
	{
		request.setAttribute("message","You can Proceed");
	}
	else{
		
		request.setAttribute("message","You cannot proceed,select different");
		
	}
	ModelAndView mv=new ModelAndView("result","application",application);
	return mv;
	
}
@RequestMapping("getQual")
public ModelAndView getQualifications(String qualName)
{
	List<QualificationPojo> qualList=applicationService.getQualifications(qualName);
	ModelAndView mv=new ModelAndView("qualList","qualList",qualList);
	
	return mv;
	
}
@RequestMapping("getStates")
public ModelAndView getStates(ApplicationPojo application)

{
	List<CountryPojo> countries=applicationService.getCountries();
	List<StatePojo> states=applicationService.getStates(application.getCountryId());
	ModelAndView mv=new ModelAndView("custHome");
	Map map=mv.getModelMap();
	map.put("states", states);
	map.put("application", application);
	map.put("countries", countries);
	return mv;
}

}
