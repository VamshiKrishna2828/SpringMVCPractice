	
$(document).ready(function() {
	
	const PMO_ROLE = 2;  
	const REQUIREMENT_PHASE = 24; 
	const DESIGN_PHASE = 25; 
	const CANCELLED_PHASE = 33; 
	const ONHOLD_PHASE = 32; 
	 
	functionalValidation();
	
	function functionalValidation(){
		
		var currentPerPhase = $("#currentPerPhase").val();
		var currentBuildPhase = $("#currentbuildphase").val();
		var currentRoleId = $("#currentRoleId").val();
		var onsiteTimesheetLeverage = $("#onsiteTimesheetLeverage").val();
		var onsiteLeverage = $("#onsiteLeverage").val();
		
		
		//If onsiteTimesheetLeverage is exceeding OnsiteLeverage value, the value shld be highlighted
		if(onsiteLeverage!="" && onsiteTimesheetLeverage!="" && parseInt(onsiteTimesheetLeverage)>parseInt(onsiteLeverage)){
			$("#onsiteTimesheetLeverage").addClass("highlight");
			$("#leverageExceed").text("Leverage is exceeding the limit!!!")
		}
		
		//If Build Phase is "cancelled" only PMO can move it to other phases
		if(currentBuildPhase!="" && currentBuildPhase==CANCELLED_PHASE && currentRoleId!=PMO_ROLE){
			$("#currentbuildphase").prop('disabled', true);
		}
		
		//If Per Phase is 'Requirement' or  'Design', Execution LOE's Insertion and updation is blocked
		//If Build Phase is 'On-hold' or 'Cancelled' , Execution LOE's Insertion and updation is blocked
		if(currentPerPhase==REQUIREMENT_PHASE || currentPerPhase==DESIGN_PHASE || currentBuildPhase==ONHOLD_PHASE || currentBuildPhase==CANCELLED_PHASE){
			$("#executionLOEReq").prop('disabled', true);
			$("#executionLOEDesign").prop('disabled', true);
			$("#executionLOECons").prop('disabled', true);
			$("#executionLOETest").prop('disabled', true);
			$("#executionLOERelease").prop('disabled', true);
		}
		
		//If per Phase is "cancelled" build shlould not be accessible to any of the users
		if(currentPerPhase!="" && currentPerPhase==CANCELLED_PHASE){
			var selectElements = $("body").find('select');
			for(var i=0;i<selectElements.length;i++){
				$(selectElements[i]).prop('disabled', true);
			}
			var inputElements = $("body").find('input');
			for(var i=0;i<inputElements.length;i++){
				$(inputElements[i]).prop("readonly", true);
			}
			var textareaElements = $("body").find('textarea');
			for(var i=0;i<textareaElements.length;i++){
				$(textareaElements[i]).prop("readonly", true);
			}
			$("#assign").prop('disabled', true);
			$("#assignAll").prop('disabled', true);
			$("#remove").prop('disabled', true);
			$("#removeAll").prop('disabled', true);
			$("#buildSave").prop('disabled', true);
			$("#buildDelete").prop('disabled', true);
			$("#buildSubmit").prop('disabled', true);
		}
		
	}
	
	//if phase is moved to on-hold or cancelled , then we shlould not allow the user to modify the LOE's
	$("#currentbuildphase").change(function(){
		var buildPhase = $("#currentbuildphase").val();
		if(buildPhase==ONHOLD_PHASE || buildPhase==CANCELLED_PHASE){
			$("#executionLOEReq").prop('disabled', true);
			$("#executionLOEDesign").prop('disabled', true);
			$("#executionLOECons").prop('disabled', true);
			$("#executionLOETest").prop('disabled', true);
			$("#executionLOERelease").prop('disabled', true);
		}
		else{
			$("#executionLOEReq").prop('disabled', false);
			$("#executionLOEDesign").prop('disabled', false);
			$("#executionLOECons").prop('disabled', false);
			$("#executionLOETest").prop('disabled', false);
			$("#executionLOERelease").prop('disabled', false);
		}
	});
	
	//Get the modals
	var auditTrailModal = document.getElementById('auditTrailModal');
	var commentModal = document.getElementById('commentModal');
	var notificationModal = document.getElementById('notificationModal');
	var attachmentModal = document.getElementById('attachmentModal');
	
	//To open the clicked modals only if the mandatory fields are entered
	$(".modalClick").click(function(){
		var form = $('#buildForm');
		var clickedModal = $(this).attr('data-modal-click');
		if (form.parsley().validate({group: 'mandate'})) {
		
			switch(clickedModal) {
			case "attachment": attachmentModal.style.display = "block";
								break;
			case "comment": commentModal.style.display = "block";
								break;
			case "notification":notificationModal.style.display = "block";
								//$("#notificationFrom").val("From@capgemini.com");
								break;
			default:alert("Invalid click ");
				break;
			
			}
		}
		else{
			return;
		}
	});
	
	//To clear the modal data on click of cancel button
    $(".modalCancel").click(function(){
 	   var cancelledModal = $(this).attr('data-modal-cancel');
 	   var childModalAttr = "data-child-"+cancelledModal;
 	   var modalElement = $('[' + childModalAttr + ']').get();
 	   for(var c=0;c<modalElement.length;c++){
 		   if("notificationFrom"==modalElement[c].id){
 			   continue;
 		   }
 		   $(modalElement[c]).val("");
 	   }
    });
	
	$(".modalSubmit").click(function(){
		
		var modalToBesaved = this.id;
		var form = $('#buildForm');
		if(form.parsley().validate({group: modalToBesaved}) && form.parsley().validate({group: 'parent'}) ){
				
			var buildVOUI = {};
			
			//setting Status Code
			var statusCode = $("#statusFlag").val();
			if(statusCode==""){
				$("#statusFlag").val("S");
			}
			else{
				$("#statusFlag").val(statusCode);
			}
			
			//forming child object
			var childModalAttr = "data-child-"+modalToBesaved;
			var childFieldName = $('[' + childModalAttr + ']').get();
			this[modalToBesaved] = {};
			for(var f=0;f<childFieldName.length;f++){
				var childField = $(childFieldName[f]).attr(childModalAttr);
				var childFieldValue = childFieldName[f].value;
				if(childFieldValue == ""){
					this[modalToBesaved] [childField] = null;
				}
				else{
					this[modalToBesaved] [childField] = childFieldValue;
				}
			}
			console.log(this[modalToBesaved]);
			buildVOUI [modalToBesaved] = this[modalToBesaved];
			
			//Forming Parent object
			var parentAttr = "data-parent";
			var parent = $('[' + parentAttr + ']').get();
			for(var i=0;i<parent.length;i++){
				var field = $(parent[i]).attr(parentAttr);
				var childAttr = "data-child-"+field;
				var child = $('[' + childAttr + ']').get();
				if(child.length>0){
					this[field] = {};
					for(var j=0;j<child.length;j++){
						var childField = $(child[j]).attr(childAttr);
						var childVal = child[j].value;
						if(childVal == ""){
							this[field] [childField] = null;
						}
						else{
							this[field] [childField] = childVal;
						}
					}
					buildVOUI [field] =this[field];
				}
				else{
					var parentVal = parent[i].value;
				
					if(parentVal == ""){
						buildVOUI [field] = null;
					}
					else{
						buildVOUI [field] = parentVal;
					}
					
				}
			}
			console.log(buildVOUI);
			
			//Ajax calls for modal submits
			$.ajax({
			      type: "POST",
			      url: "/Eztrac/ajax/buildInsert",
			      data: JSON.stringify(buildVOUI), 
			      dataType: "json", 
			      contentType: "application/json; charset=utf-8",
			      success :function(response) {
			    	  console.log(response);
			    	  var listOfAttachments;
			    	  var listOfComments;
			    	  var listOfNotifications;
			    	  var s = response;
			    	  if(s.attachmentList!=null){
			    		  for(var i=0;i<s.attachmentList.length;i++){
			    			  listOfAttachments+= "<tr><td>"+s.attachmentList[i].url+"</td><td>"+s.attachmentList[i].createdOnString+"</td><td>"+s.attachmentList[i].createdBy+"</td></tr>";
				    	  }
	                       if(listOfAttachments != ""){
	                    	 $("#attachmentLinkUrl").val("");
	                         $("#attachmentTableBody").html(listOfAttachments);
	                       }
	                       $("#buildId").val(s.buildId);
			    	  }
			    	  if(s.commentList!=null){
			    		  for(var i=0;i<s.commentList.length;i++){
			    			  listOfComments+= "<tr><td>"+s.commentList[i].commentBy+"</td><td>"+s.commentList[i].commentOnString+"</td><td>"+s.commentList[i].comment+"</td></tr>";
				    	  }
	                       if(listOfComments != ""){
	                    	 $("#commentLinkComment").val("");  		
	                         $("#commentTableBody").html(listOfComments);
	                       }
	                       $("#buildId").val(s.buildId);
			    	  }
			    	  if(s.notificationList!=null){
			    		  for(var i=0;i<s.notificationList.length;i++){
			    			  listOfNotifications+= "<tr><td>"+s.notificationList[i].subject+"</td><td>"+s.notificationList[i].to+"</td></tr>";
				    	  }
	                       if(listOfNotifications != ""){
	                    	  $("#notificationTo").val("");
	                    	  $("#notificationCc").val("");
	                    	  $("#notificationSubject").val("");
	                    	  $("#notificationMessage").val("");
	                          $("#notificationTableBody").html(listOfNotifications);
	                       }
	                       $("#buildId").val(s.buildId);
			    	  }
			      }
			 });
		}
		else{
			return;
		}
		
	});
	
	
	
	/* START : To set statusFlag - SAVE / SUBMIT */
	
	$("#buildSave").click(function(){
		var form = $('#buildForm');
		if(form.parsley().validate({group: 'mandate'}) && form.parsley().validate({group: 'parent'}) ){
			var status = $('#statusFlag').val();
			if(status == "A"){
				$('#statusFlag').val("A");
			}
			else
			{
				$('#statusFlag').val("S");
			}
			alert($('#statusFlag').val());
			$("#buildForm").find('select').prop('disabled', false);
			$("#buildForm").find('input').prop('disabled', false);
			form.off('submit.Parsley');
		}
		else{
			return;
		}
	});
	
	$("#buildSubmit").click(function(){
		
		var form = $('#buildForm');
		if(form.parsley().validate({group: 'mandate'}) && form.parsley().validate({group: 'parent'}) ){
			$('#statusFlag').val("A");
			alert($('#statusFlag').val());
			$("#buildForm").find('select').prop('disabled', false);
			$("#buildForm").find('input').prop('disabled', false);
			form.off('submit.Parsley');
		}
		else{
			return;
		}
		
	});
	
	$("#buildDelete").click(function(){
		if (confirm("Do you want to DELETE this BUILD ??!!")) {
			var form = $('#buildForm');
			var ele = form.find('select').prop('disabled', false);
			form.off('submit.Parsley');
		}else{
			return false;
		}
	
	});
	
	$("#buildCancel").click(function(){
		 if (confirm("Do you want discard the BUILD changes ??!!")) {
	        var form = $("#cancelForm");
				form.attr('action','/Eztrac/build_edit');
				form.submit();
	    } else {
	    	return;
	    }
	});
	
	/* START : To set statusFlag - SAVE / SUBMIT */
		
		/* START : To show and hide the CC table in build CC */
		$("#buildCCshowtablebutton").click(function(){
			
		$('#buildCCtable').show();
		});
		
		$("#buildCChidetablebutton").click(function(){
		
		$('#buildCCtable').hide();
		});
		/* END : To show and hide the CC table in build CC */
		
		/* START : To show and hide the BuildCC form */
		$(".buildCcLink").click(function(){
			$('#buildCcForm').show();
		});
		
		/* END : To show and hide the BuildCC form */
		
		$("#dummyshow").click(function(){
			
		$('#dummytable').show();
		});
		
		$("#dummyhide").click(function(){
		
		$('#dummytable').hide();
		});
		
		/*START : Related to Modals*/
		
		// Get the modal
		// Get the button that opens the modal
		var auditTrailButton = document.getElementById("auditTrailButton");
		// Get the <span> element that closes the modal
		var span = document.getElementsByClassName("close")[0];

		// When the user clicks the button, open the modal 
		auditTrailButton.onclick = function() {
			auditTrailModal.style.display = "block";
		}
		
		//When the user clicks on 'X' button - to close modal
		$("#auditTrailModalClose").click(function(){
			$('#auditTrailModal').hide();
		});
		$("#attachmentModalClose").click(function(){
			$('#attachmentModal').hide();
		});
		
		$("#commentModalClose").click(function(){
			$('#commentModal').hide();
		});
		
		$("#notificationModalClose").click(function(){
			$('#notificationModal').hide();
		});
		// When the user clicks anywhere outside of the modal, close it
		window.onclick = function(event) {
			if (event.target == auditTrailModal) {
				auditTrailModal.style.display = "none";
			} 
			if (event.target == commentModal) {
				commentModal.style.display = "none";
			}
			if (event.target == notificationModal) {
				notificationModal.style.display = "none";
			}
			if (event.target == attachmentModal) {
				attachmentModal.style.display = "none";
			}  
			
		}
		
		/*END : Related to Modals*/
		/* START : To open and close the accordians */
		var acc = document.getElementsByClassName("accordion");
		var i;

		for (i = 0; i < acc.length; i++) {
			acc[i].onclick = function(){
				this.classList.toggle("active");
				var panel = this.nextElementSibling;
				if (panel.style.display === "block") {
					panel.style.display = "none";
				} else {
					panel.style.display = "block";
				}
			}
		}
		
		var panel = $(".generalAccordian");
	    panel.click();
		/* END : To open and close the accordians */
		
		var assignedToArray = [];
		$("#assign").on('click', function() {
	       var p = $("#assignedToPickList").find("#assignedToData option:selected");
	        p.clone().appendTo("#assignedToResult");
	        p.remove();
	        assignedToArray = [];
	        $("#assignedToResult option").each(function()
    		{
    	    	assignedToArray.push($(this).val());
    	    	$("#assignedTo").val(assignedToArray);
    		});
	      });

	      $("#assignAll").on('click', function() {
			var p = $("#assignedToPickList").find("#assignedToData option");
	        p.clone().appendTo("#assignedToResult");
	        p.remove();
	        assignedToArray = [];
	        $("#assignedToResult option").each(function()
    		{
    	    	assignedToArray.push($(this).val());
    	    	$("#assignedTo").val(assignedToArray);
    		});
	      });

	      $("#remove").on('click', function() {
	       var p = $("#assignedToPickList").find("#assignedToResult option:selected");
	       p.clone().appendTo("#assignedToData");
	       p.remove();
	       assignedToArray = [];
	       $("#assignedToResult option").each(function()
       		{
       	    	assignedToArray.push($(this).val());
       	    	$("#assignedTo").val(assignedToArray);
       		});
	      });

	      $("#removeAll").on('click', function() {
	       var p = $("#assignedToPickList").find("#assignedToResult option");
	       p.clone().appendTo("#assignedToData");
	       p.remove();
       	   $("#assignedTo").val("");
	      });
		
		/* START : To show and hide the picklist for 'assigned to' */
		$("#addEmployees").click(function(){
			
		$('#pickList').show();
		});
		
		$("#hideEmployees").click(function(){
		
		$('#pickList').hide();
		});
		/* END : To show and hide the picklist for 'assigned to' */
		
		$("#showExtraFilter").click(function(){
			$('#extraFilterData').show();
		});
		
		$("#systemId").change(function() {
			$("#subSystemId").empty();
			var defaultOption = "<option value=\"\"> -select- </option>";
			$("#subSystemId").append(defaultOption);
			var systemId = $('#systemId').val();
			$.ajax({
			      type: "POST",
			      url: "/Eztrac/ajax/getSubsystemList",
			      data: JSON.stringify(systemId), 
			      dataType: "json", 
			      contentType: "application/json; charset=utf-8",
			      success :
			      function(response) {
			    	  console.log(response);
			    	  response.forEach(function(item, i){
			    	  var option = "<option value = "+ item.subSystemID+ ">" + item.subSystemName + "</option>";
					  $("#subSystemId").append(option);
			    	  });
			      }
			});
		});

});