var app = app || ( function() {
	globalVariable={
			PROJECTS_PER_NEW:{formName:"switchRole-form",action:"/Eztrac/per_new"},
			PROJECTS_PER_EDIT:{formName:"switchRole-form",action:"/Eztrac/per_edit"},
			PROJECTS_BUILD_NEW:{formName:"switchRole-form",action:"/Eztrac/build_new"},
			PROJECTS_BUILD_EDIT:{formName:"switchRole-form",action:"/Eztrac/build_edit"},
			PROJECTS_TIMESHEET:{formName:"switchRole-form",action:"/Eztrac/timesheet"},
			PROJECTS_TIMESHEET_SAVE:{formName:"timeSheetForm",action:"/Eztrac/saveTimeSheet"},
			PROJECTS_TIMESHEET_SUBMIT:{formName:"timeSheetForm",action:"/Eztrac/submitTimeSheet"},
			PROJECTS_TIMESHEET_DELETE:{formName:"timeSheetForm",action:"/Eztrac/deleteTimeSheet"},
			REPORTS_CARDS_SERVICES_REPORT_INVOICE_REPORTS:{formName:"",action:"/Eztrac/reportCardService"},
			BUILD_SUBMIT:{formName:"buildForm",action:"/Eztrac/build_submit"},
			BUILD_SAVE:{formName:"buildForm",action:"/Eztrac/build_submit"},
			BUILD_DELETE:{formName:"buildForm",action:"/Eztrac/build_delete"},
			BUILD_LIST:{formName:"buildListForm",action:"/Eztrac/build_list"},
			BUILD_DETAIL:{formName:"buildListForm",action:"/Eztrac/build_details"},
			PER_SUBMIT:{formName:"perForm",action:"/Eztrac/per_submit"},
			PER_SAVE:{formName:"perForm",action:"/Eztrac/per_submit"},
			PER_DELETE:{formName:"perForm",action:"/Eztrac/per_delete"},
			PER_LIST:{formName:"perListForm",action:"/Eztrac/per_list"},
			PER_DETAIL:{formName:"perListForm",action:"/Eztrac/per_details"},
			LOG_OUT:{formName:"switchRole-form",action:"/Eztrac/logout"}
	
	}; 
	return globalVariable;
}());
