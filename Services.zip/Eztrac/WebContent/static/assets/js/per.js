$(document).ready(function(){
     
		const COMPLETED_PHASE = 30; 
		const CANCELLED_PHASE = 33;
		const PRE_KICKOFF_PHASE = 23; 
		const SCHEDULED_PHASE = 34;
		const REQUIREMENT_PHASE = 24;
		const RELEASE_PHASE = 28;
		const ONHOLD_PHASE = 32;
		const POST_RELEASE_PHASE = 31;
		const ESTIMATION_PHASE = 29;
		const ADMIN_ROLE_ID = 1;
		const PMO_ROLE = 2;  
	
		var currentRoleId = $("#currentRoleId").val();
	
		 $("#perForm").on('submit',function(e) {
	  	   return validatePerForm();
	     }); 
	     $(".dateValidation").change(function() {
	  	   validatePerForm();
	     });
     
     	functionalValidation();
	
		function functionalValidation(){
			
			var currentPerPhase = $("#currentPhase").val();
			
			//If currentPerPhase is Completed - All the users shld be restricted to update the details
			if(currentPerPhase==COMPLETED_PHASE){
				var selectElements = $("body").find('select');
				for(var i=0;i<selectElements.length;i++){
					$(selectElements[i]).prop('disabled', true);
				}
				var inputElements = $("body").find('input');
				for(var i=0;i<inputElements.length;i++){
					$(inputElements[i]).prop("readonly", true);
				}
				var textareaElements = $("body").find('textarea');
				for(var i=0;i<textareaElements.length;i++){
					$(textareaElements[i]).prop("readonly", true);
				}
				$("#addManager").prop('disabled', true);
				$("#addAllManager").prop('disabled', true);
				$("#removeManager").prop('disabled', true);
				$("#removeAllManager").prop('disabled', true);
				$("#perSave").prop('disabled', true);
				$("#perDelete").prop('disabled', true);
				$("#perSubmit").prop('disabled', true);
			}
			
			//If Per Phase is "cancelled" only PMO can move it to other phases
			if (currentPerPhase != "" && currentPerPhase == CANCELLED_PHASE && currentRoleId != PMO_ROLE) {
				$("#currentPhase").prop('disabled', true);
			}
			
			//If phase is other than on-hold , stop and restart date should be disabled
			if(currentPerPhase!=ONHOLD_PHASE){
				$('#stopDate').prop("readonly", true);
				$('#restartDate').prop("readonly", true);
			}
			
			//If phase is other than cancelled , cancellation date should be disabled
			if(currentPerPhase!=CANCELLED_PHASE){
				$('#cancellationDate').prop("readonly", true);
			}
		}
		
		//If phase changes to on-hold - stop and restart date should be enabled, else disabled
		$("#currentPhase").change(function() {
			$(".error").text("");
			var currentPerPhase = $("#currentPhase").val();
			
			//If phase is moved to on-hold - make stop and restart dates as mandatory
			if(currentPerPhase==ONHOLD_PHASE){
				$('#stopDate').prop("readonly", false);
				$('#restartDate').prop("readonly", false);
				$("#stopDateError").text('Stop date is required.');
				$("#restartDateError").text('Restart date is required.');
				$("#stopDate").focus();
			}
			else{
				$('#stopDate').prop("readonly", true);
				$('#restartDate').prop("readonly", true);
				$('#stopDate').val('');
				$('#restartDate').val('');
			}
			
			//If phase is moved to cancelled - make cancellation date as mandatory
			if(currentPerPhase==CANCELLED_PHASE){
				$('#cancellationDate').prop("readonly", false);
				$("#cancellationDateError").text('Cancellation date is required.');
				$('#cancellationDate').focus();
			}
			else{
				$('#cancellationDate').prop("readonly", true);
				$('#cancellationDate').val('');
			}
			
			//when phase is moved to scheduled or prekickoff  - calculate the planned phase timelines
			if (SCHEDULED_PHASE == $("#currentPhase").val() || PRE_KICKOFF_PHASE == $("#currentPhase").val()) {
				if($("#scheduleCallDate").val()==null || $("#scheduleCallDate").val()==""){
					var currentDate = new Date();
					$("#scheduleCallDate").val(currentDate.getFullYear() + '-' + ("0" + (currentDate.getMonth() + 1)).slice(-2) + '-' + ("0" + currentDate.getDate()).slice(-2));
	            }
				alert($("#currentScheduleStartDate").val());
				alert($("#currentScheduleEndDate").val());
				if($("#currentScheduleStartDate").val()!="" && $("#currentScheduleEndDate").val()!=""){
					alert("its not null");
				}
				if(($("#currentScheduleStartDate").val()!="") && ($("#currentScheduleEndDate").val()!="")){
					evaluatePlannedPhaseTimeLines();
				}
				else{
					$("#currentScheduleStartDateError").text('Schedule Start date is required.');
					$("#currentScheduleEndDateError").text('Schedule End date is required.');
				}
	        }
			
		});
		
		$('.calculatePlannedDates').change(function(){
			if(($("#currentScheduleStartDate").val()!=null || $("#currentScheduleStartDate").val()!="") && 
					($("#currentScheduleEndDate").val()!=null || $("#currentScheduleEndDate").val()!="") &&
					(SCHEDULED_PHASE == $("#currentPhase").val() || PRE_KICKOFF_PHASE == $("#currentPhase").val()) &&
					(null == $("#plannedReqStartDate").val() || "" == $("#plannedReqStartDate").val())){
				evaluatePlannedPhaseTimeLines();
			}
	    });
		
		//To open the clicked modals only if the mandatory fields are entered
       $(".modalClick").click(function(){
              var form = $('#perForm');
              var clickedModal = $(this).attr('data-modal-click');
              if (form.parsley().validate({group: 'mandate'})) {
            	  switch(clickedModal) {
                     case "attachment": attachmentModal.style.display = "block";
                                                       break;
                     case "comment": commentModal.style.display = "block";
                                                       break;
                     case "notification":notificationModal.style.display = "block";
                                                       break;
                     default:alert("Invalid click ");
                           break;
                     
                     }
              }
              else{
                     return;
              }
       });
       
       //To clear the modal data on click of cancel button
       $(".modalCancel").click(function(){
    	   var cancelledModal = $(this).attr('data-modal-cancel');
    	   var childModalAttr = "data-child-"+cancelledModal;
    	   var modalElement = $('[' + childModalAttr + ']').get();
    	   for(var c=0;c<modalElement.length;c++){
    		   if("notificationFrom"==modalElement[c].id){
    			   continue;
    		   }
    		   $(modalElement[c]).val("");
    	   }
       });
       
       $(".modalSubmit").click(function(){
    	   
    	   var modalToBesaved = this.id;
    	   var form = $('#perForm');
    	   
    	   if(form.parsley().validate({group: modalToBesaved}) && form.parsley().validate({group: 'parent'}) && validatePerForm() ){
   				
    	   var perVOUI = {};
    	   
    	   	//setting Status Code
			var statusCode = $("#statusFlag").val();
			if(statusCode==""){
				$("#statusFlag").val("S");
			}
			else{
				$("#statusFlag").val(statusCode);
			}
    	   
			//forming child object
			var childModalAttr = "data-child-"+modalToBesaved;
			var childFieldName = $('[' + childModalAttr + ']').get();
			this[modalToBesaved] = {};
			for(var f=0;f<childFieldName.length;f++){
				var childField = $(childFieldName[f]).attr(childModalAttr);
				var childFieldValue = childFieldName[f].value;
				if(childFieldValue == ""){
					this[modalToBesaved] [childField] = null;
				}
				else{
					this[modalToBesaved] [childField] = childFieldValue;
				}
			}
			console.log(this[modalToBesaved]);
			perVOUI [modalToBesaved] = this[modalToBesaved];
			
    	 //Forming Parent object
			var parentAttr = "data-parent";
			var parent = $('[' + parentAttr + ']').get();
			for(var i=0;i<parent.length;i++){
				var field = $(parent[i]).attr(parentAttr);
				var childAttr = "data-child-"+field;
				var child = $('[' + childAttr + ']').get();
				if(child.length>0){
					this[field] = {};
					for(var j=0;j<child.length;j++){
						var childField = $(child[j]).attr(childAttr);
						var childVal = child[j].value;
						if(childVal == ""){
							this[field] [childField] = null;
						}
						else{
							this[field] [childField] = childVal;
						}
					}
					perVOUI [field] =this[field];
				}
				else{
					var parentVal = parent[i].value;
				
					if(parentVal == ""){
						perVOUI [field] = null;
					}
					else{
						perVOUI [field] = parentVal;
					}
					
				}
			}
			console.log(perVOUI);
			 $.ajax({
	                type: "POST",
	                url: "/Eztrac/ajax/perInsertTest",
	                data: JSON.stringify(perVOUI), 
	                dataType: "json", 
	                contentType: "application/json; charset=utf-8",
	                success :function(response) {
				       // do what ever you want with data
				    	  console.log("Response from controller");
				    	  console.log(response);
				    	  var listOfAttachments;
				    	  var listOfComments;
				    	  var listOfNotifications;
				    	  var s = response;
				    	  if(s.attachmentList!=null){
				    		  for(var i=0;i<s.attachmentList.length;i++){
				    			  listOfAttachments+= "<tr><td>"+s.attachmentList[i].url+"</td><td>"+s.attachmentList[i].createdBy+"</td><td>"+s.attachmentList[i].createdOnString+"</td></tr>";
					    	  }
		                       if(listOfAttachments != ""){
		                    	 $("#attachmentLinkUrl").val("");
	                             $("#attachmentTableBody").html(listOfAttachments);
		                       }
		                       $("#perId").val(s.perId);
				    	  }
				    	  if(s.commentList!=null){
				    		  for(var i=0;i<s.commentList.length;i++){
				    			  listOfComments+= "<tr><td>"+s.commentList[i].commentBy+"</td><td>"+s.commentList[i].commentOnString+"</td><td>"+s.commentList[i].comment+"</td></tr>";
					    	  }
		                       if(listOfComments != ""){
		                    	 $("#commentLinkComment").val("");  		
	                             $("#commentTableBody").html(listOfComments);
		                       }
		                       $("#perId").val(s.perId);
				    	  }
				    	  if(s.notificationList!=null){
				    		  for(var i=0;i<s.notificationList.length;i++){
				    			  listOfNotifications+= "<tr><td>"+s.notificationList[i].subject+"</td><td>"+s.notificationList[i].to+"</td></tr>";
					    	  }
		                       if(listOfNotifications != ""){
		                    	  $("#notificationTo").val("");
		                    	  $("#notificationCc").val("");
		                    	  $("#notificationSubject").val("");
		                    	  $("#notificationMessage").val("");
	                              $("#notificationTableBody").html(listOfNotifications);
		                       }
		                       $("#perId").val(s.perId);
				    	  }
	               }
	              });
   			}
   			else{
   				return;
   			}
       });
       
       /* START : To open and close the accordians */
       var acc = document.getElementsByClassName("accordion");
       var i;
       
       for (i = 0; i < acc.length; i++) {
              acc[i].onclick = function() {
                     this.classList.toggle("active");
                     var panel = this.nextElementSibling;
                     if (panel.style.display === "block") {
                           panel.style.display = "none";
                     } else {
                           panel.style.display = "block";
                     }
              }
       }
       
       var panel = $(".generalAccordian");
       panel.click();
       /* END : To open and close the accordians */
       
       /* START : PO related script */
       $("#addNewPo").click(function() {
    	   var poNumber = $("#poNumber").val();
           var poAmount = $("#poAmount").val();
    	   $(".parsley-newPoSaveError").text("");
    	   if(null==poNumber || ""==poNumber || null==poAmount || ""==poAmount){
        	   //$("#addNewPo").css("pointer-events", "none");
        	   $("#poNumber").trigger("focus");
        	   $("#addNewPo").attr('title', 'Kindly enter the Po details above');
    	   }
    	   else{
    		   $("#addPoDetailsDiv").show();
    	   }
       });
       
       $("#savePoDetailsButton").click(function() {
              var newPoNumber=$("#newPoNumber").val();
              var newPoAmount=$("#newPoAmount").val();
              if(""==newPoNumber || ""==newPoAmount){
            	  $(".parsley-newPoSaveError").text("");
            	  $("#newPoError").parsley().addError('newPoSaveError', {message: "Kindly enter the PO Details to save"});
            	  return;
              }
              else{
            	  $("#poNumber").val(newPoNumber);
                  $("#poAmount").val(newPoAmount);
                  $("#newPoNumber").val("");
                  $("#newPoAmount").val("");
                  $("#newPoError").text("");
                  $("#addPoDetailsDiv").hide();
              }
       });
       
       $("#cancelPoDetailsButton").click(function() {
    	   $("#newPoNumber").val("");
           $("#newPoAmount").val("");
           $("#addPoDetailsDiv").hide();
       });
       
       $("#listAllPo").click(function() {
              $("#listAllPoDiv").show();
       });
       
       $("#closePoListDiv").click(function() {
              $("#listAllPoDiv").hide();
       });
       /* END : PO related script */
       
       /* START : Picklist code for 'Managers to notify' */
       $("#addManager") .on( 'click', function() {
              var p = $("#managerPickList").find( "#managerToNotifyData option:selected");
              p.clone().appendTo("#managerToNotifyResult");
              p.remove();
              var managersToNotify =[];
              $("#managerToNotifyResult option").each(function()
              {
                    managersToNotify.push($(this).val());
        	    	$("#managersToNotify").val(managersToNotify);
              });
       });

       $("#addAllManager").on( 'click', function() {
              var p = $("#managerPickList").find("#managerToNotifyData option");
              p.clone().appendTo("#managerToNotifyResult");
              p.remove();
              var managersToNotify =[];
              $("#managerToNotifyResult option").each(function()
              {
                    managersToNotify.push($(this).val());
        	    	$("#managersToNotify").val(managersToNotify);
              });
       });

       $("#removeManager") .on( 'click',function() {
              var p = $("#managerPickList").find("#managerToNotifyResult option:selected");
              p.clone().appendTo("#managerToNotifyData");
              p.remove();
              var managersToNotify =[];
              $("#managerToNotifyResult option").each(function()
              {
                    managersToNotify.push($(this).val());
        	    	$("#managersToNotify").val(managersToNotify);
              });
       });

       $("#removeAllManager").on('click',function() {
              var p = $("#managerPickList").find("#managerToNotifyResult option");
              p.clone().appendTo("#managerToNotifyData");
              p.remove();
              $("#managersToNotify").val("");
       });
       /* END : Picklist code for 'Managers to notify' */
       
       /* START : To display list of builds table */
       $("#listOfbuildsLink").click(function() {
              $('#buildListTable').show();
       });

       $("#hideBuildListTable").click(function() {
              $('#buildListTable').hide();
       });

       /* END : To display list of builds table */
       
       /*START : Related to Modals*/
      
              // Get the button that opens the modal
              var auditTrailButton = document.getElementById("auditTrailButton");
              
              // Get the <span> element that closes the modal
              var span = document.getElementsByClassName("close")[0];

              // When the user clicks the button, open the modal 
              auditTrailButton.onclick = function() {
                     auditTrailModal.style.display = "block";
              }
             

              
              //When the user clicks on 'X' button - to close modal
              $("#auditTrailModalClose").click(function(){
                     $('#auditTrailModal').hide();
              });
              $("#attachmentModalClose").click(function(){
                     $('#attachmentModal').hide();
              });
              
              $("#commentModalClose").click(function(){
                     $('#commentModal').hide();
              });
              
              $("#notificationModalClose").click(function(){
                     $('#notificationModal').hide();
              });
              
              
              
              // When the user clicks anywhere outside of the modal, close it
              window.onclick = function(event) {
                     if (event.target == auditTrailModal) {
                           auditTrailModal.style.display = "none";
                     } 
                     if (event.target == commentModal) {
                           commentModal.style.display = "none";
                     }
                     if (event.target == notificationModal) {
                           notificationModal.style.display = "none";
                     }
                     if (event.target == attachmentModal) {
                           attachmentModal.style.display = "none";
                     }  
                     
              }
              
       /*END : Related to Modals*/
       
       function validatePerForm(){
    	   $('.error').html('');
           var successFlag = true;
           var scheduleCallDate = $('#scheduleCallDate').val();
           var cancellationDate = $('#cancellationDate').val();
           var currentScheduleStartDate = $('#currentScheduleStartDate').val();
           var currentScheduleEndDate = $('#currentScheduleEndDate').val();
           var stopDate = $('#stopDate').val();
           var restartDate = $('#restartDate').val();
           /************Schedule Dates*************/
           if(scheduleCallDate!=null && scheduleCallDate != "" && cancellationDate!=null && cancellationDate!="" && scheduleCallDate > cancellationDate){
                 $("#cancellationDateError").text('Cancellation date should be after Scheduling call date.');
                 successFlag = false;
           }
           else if(scheduleCallDate==null || scheduleCallDate == "" && cancellationDate!=null && cancellationDate!=""){
                 $("#schedulingCallDateError").text('Current scheduled start date is required.');
                 successFlag = false;
           }
           if(currentScheduleStartDate!=null && currentScheduleStartDate != "" && currentScheduleEndDate!=null && currentScheduleEndDate!="" && currentScheduleStartDate > currentScheduleEndDate){
                 $("#currentScheduleEndDateError").text('Cancellation date should be after Scheduling call date.');
                 successFlag = false;
           }
           else if(currentScheduleStartDate==null || currentScheduleStartDate == "" && currentScheduleEndDate!=null && currentScheduleEndDate!=""){
                 $("#currentScheduleStartDateError").text('Current scheduled start date is required.');
                 successFlag = false;
           }
           
           if (SCHEDULED_PHASE == $("#currentPhase").val() || PRE_KICKOFF_PHASE == $("#currentPhase").val()) {
               if ((null == currentScheduleStartDate || "" == currentScheduleStartDate) && (null == currentScheduleEndDate || "" == currentScheduleEndDate)) {
                   $("#currentScheduleStartDateError").text('Current schedule start date is required.');
                   $("#currentScheduleEndDateError").text('Current schedule end date is required.');
                   successFlag = false;
               }
               else if (null == currentScheduleEndDate || "" == currentScheduleEndDate) {
                   $("#currentScheduleEndDateError").text('Current schedule end date is required.');
                   successFlag = false;
               }
           }
           if (ONHOLD_PHASE == $("#currentPhase").val()) {
               if ((null == stopDate || "" == stopDate) && (null == restartDate || "" == restartDate)) {
                   $("#stopDateError").text('Stop date is required.');
                   $("#restartDateError").text('Restart date is required.');
                   successFlag = false;
               } else if ((stopDate == null || stopDate == "")) {
                   $("#stopDateError").text('Stop date is required.');
                   successFlag = false;
               } else if (null == restartDate || "" == restartDate) {
                   $("#restartDateError").text('Restart date is required.');
                   successFlag = false;
               }else if (stopDate != null && stopDate != "" && restartDate != null && restartDate != "" && stopDate > restartDate) {
                   $("#restartDateError").text('Restart date should be after Stop date.');
                   successFlag = false;
               }
               /*if (stopDate != null || stopDate != "") {
                   var currentDate = new Date();
                   currentDate = currentDate.getFullYear() + '-' + ("0" + (currentDate.getMonth() + 1)).slice(-2) + '-' + ("0" + currentDate.getDate()).slice(-2)
                   if (stopDate > currentDate) {
                       $("#stopDateError").text('Stop date should not be future date.');
                       successFlag = false;
                   }
               }*/
           }
           if (CANCELLED_PHASE == $("#currentPhase").val()) {
               if (null == $("#cancellationDate").val() || "" == $("#cancellationDate").val()) {
                   $("#cancellationDateError").text('Cancellation date is required.');
                   successFlag = false;
               }
           }
           
           /************PhaseTimelines Validation*************/
           var actualReqStartDate = $('#actualReqStartDate').val();
           var actualReqEndDate = $('#actualReqEndDate').val();
           var actualDesignStartDate = $('#actualDesignStartDate').val();
           var actualDesignEndDate = $('#actualDesignEndDate').val();
           var actualConStartDate = $('#actualConStartDate').val();
           var actualConEndDate = $('#actualConEndDate').val();
           var actualTestingStartDate = $('#actualTestingStartDate').val();
           var actualTestingEndDate = $('#actualTestingEndDate').val();
           var actualReleaseStartDate = $('#actualReleaseStartDate').val();
           var actualReleaseEndDate = $('#actualReleaseEndDate').val();
           
           if(actualReqStartDate!=null && actualReqStartDate != "" && actualReqEndDate!=null && actualReqEndDate!="" && actualReqStartDate > actualReqEndDate){
                 $("#actualReqEndDateError").text('Actual Requirement End Date should be after Actual Requirement Start Date.');
                 successFlag = false;
           }
           else if(actualReqStartDate==null || actualReqStartDate == "" && actualReqEndDate!=null && actualReqEndDate!=""){
                 $("#actualReqStartDateError").text('Actual Requirement Start Date is Required.');
                 successFlag = false;
           }
           if(actualDesignStartDate!=null && actualDesignStartDate != "" && actualDesignEndDate!=null && actualDesignEndDate!="" && actualDesignStartDate > actualDesignEndDate){
                 $("#actualDesignEndDateError").text('Actual Design End Date should be after Actual Design Start Date.');
                 successFlag = false;
           }
           else if(actualDesignStartDate==null || actualDesignStartDate == "" && actualDesignEndDate!=null && actualDesignEndDate!=""){
                 $("#actualDesignStartDateError").text('Actual Design Start Date is Required.');
                 successFlag = false;
           }
           if(actualConStartDate!=null && actualConStartDate != "" && actualConEndDate!=null && actualConEndDate!="" && actualConStartDate > actualConEndDate){
                 $("#actualConEndDateError").text('Actual Construction End Date should be after Actual Construction Start Date.');
                 successFlag = false;
           }
           else if(actualConStartDate==null || actualConStartDate == "" && actualConEndDate!=null && actualConEndDate!=""){
                 $("#actualConStartDateError").text('Actual Construction Start Date is Required.');
                 successFlag = false;
           }
           if(actualTestingStartDate!=null && actualTestingStartDate != "" && actualTestingEndDate!=null && actualTestingEndDate!="" && actualTestingStartDate > actualTestingEndDate){
                 $("#actualTestingEndDateError").text('Actual Testing End Date should be after Actual Testing Start Date.');
                 successFlag = false;
           }
           else if(actualTestingStartDate==null || actualTestingStartDate == "" && actualTestingEndDate!=null && actualTestingEndDate!=""){
                 $("#actualTestingStartDateError").text('Actual Testing Start Date is Required.');
                 successFlag = false;
           }
           if(actualReleaseStartDate!=null && actualReleaseStartDate != "" && actualReleaseEndDate!=null && actualReleaseEndDate!="" && actualReleaseStartDate > actualReleaseEndDate){
                 $("#actualReleaseEndDateError").text('Actual Release End Date should be after Actual Release Start Date.');
                 successFlag = false;
           }
           else if(actualReleaseStartDate==null || actualReleaseStartDate == "" && actualReleaseEndDate!=null && actualReleaseEndDate!=""){
                 $("#actualReleaseStartDateError").text('Actual Release Start Date is Required.');
                 successFlag = false;
           }
           if (successFlag) {
                 return true;
           } else {
                 return false;
           }

       }
       /* END :  Date Validation for Schedule Updates */
       
       /*Planned Phase Timelines caliculation code start
       $("#currentPhase").change(function() {
    	   if(25==$("#currentPhase").val() || 14==$("#currentPhase").val()){
    		   evaluatePlannedPhaseTimeLines();
    	   }
       });
       $("#currentScheduleEndDate").change(function() {
    	   if(25==$("#currentPhase").val() || 14==$("#currentPhase").val()){
    		   evaluatePlannedPhaseTimeLines();
    	   }
       });*/
       
       /*START : Planned Phase Timelines calculation code */
       function evaluatePlannedPhaseTimeLines() {
           if (null != $("#currentScheduleStartDate").val() && "" != $("#currentScheduleStartDate").val() && null != $("#currentScheduleEndDate").val() &&
               "" != $("#currentScheduleEndDate").val()) {
               var currentScheduleStartDate = new Date($("#currentScheduleStartDate").val());
               var currentScheduleEndDate = new Date($("#currentScheduleEndDate").val());
               var duration = (currentScheduleEndDate.getTime() - currentScheduleStartDate.getTime()) / (1000 * 60 * 60 * 24);
               alert("duration" + duration);
               if (currentScheduleStartDate.getDay() == 0) {
                   currentScheduleStartDate = currentScheduleStartDate.addDays(1);
               } else if (currentScheduleStartDate.getDay() == 6) {
                   currentScheduleStartDate = currentScheduleStartDate.addDays(2);
               } else if (currentScheduleStartDate.getDay() != 0 && currentScheduleStartDate.getDay() != 6) {
                   currentScheduleStartDate = currentScheduleStartDate.addDays(0);
               }
               if (currentScheduleEndDate.getDay() == 0) {
                   currentScheduleEndDate = currentScheduleEndDate.addDays(-2);
               } else if (currentScheduleEndDate.getDay() == 6) {
                   currentScheduleEndDate = currentScheduleEndDate.addDays(-1);
               } else if (currentScheduleEndDate.getDay() != 0 && currentScheduleEndDate.getDay() != 6) {
                   currentScheduleEndDate = currentScheduleEndDate.addDays(0);
               }
               if (duration >= 37) {
                   var plannedReleaseStartDate = new Date(new Date(currentScheduleEndDate).addDays(-7));
                   if (plannedReleaseStartDate.getDay() == 0) {
                       plannedReleaseStartDate = plannedReleaseStartDate.addDays(1);
                   } else if (plannedReleaseStartDate.getDay() == 6) {
                       plannedReleaseStartDate = plannedReleaseStartDate.addDays(2);
                   } else if (plannedReleaseStartDate.getDay() != 0 && plannedReleaseStartDate.getDay() != 6) {
                       plannedReleaseStartDate = plannedReleaseStartDate.addDays(0);
                   }
                   var plannedTestingEndDate = new Date(new Date(plannedReleaseStartDate).addDays(-1));
                   if (plannedTestingEndDate.getDay() == 0) {
                       plannedTestingEndDate = plannedTestingEndDate.addDays(-2);
                   } else if (plannedTestingEndDate.getDay() == 6) {
                       plannedTestingEndDate = plannedTestingEndDate.addDays(-1);
                   } else if (plannedTestingEndDate.getDay() != 0 && plannedTestingEndDate.getDay() != 6) {
                       plannedTestingEndDate = plannedTestingEndDate.addDays(0);
                   }
                   var plannedTestingStartDate = new Date(new Date(plannedTestingEndDate).addDays(-Math.round(duration * 0.3)));
                   if (plannedTestingStartDate.getDay() == 0) {
                       plannedTestingStartDate = plannedTestingStartDate.addDays(1);
                   } else if (plannedTestingStartDate.getDay() == 6) {
                       plannedTestingStartDate = plannedTestingStartDate.addDays(2);
                   } else if (plannedTestingStartDate.getDay() != 0 && plannedTestingStartDate.getDay() != 6) {
                       plannedTestingStartDate = plannedTestingStartDate.addDays(0);
                   }

                   var plannedConEndDate = new Date(new Date(plannedTestingStartDate).addDays(-1));
                   if (plannedConEndDate.getDay() == 0) {
                       plannedConEndDate = plannedConEndDate.addDays(-2);
                   } else if (plannedConEndDate.getDay() == 6) {
                       plannedConEndDate = plannedConEndDate.addDays(-1);
                   } else if (plannedConEndDate.getDay() != 0 && plannedConEndDate.getDay() != 6) {
                       plannedConEndDate = plannedConEndDate.addDays(0);
                   }
                   var plannedConStartDate = new Date(new Date(plannedConEndDate).addDays(-Math.round(duration * 0.2)));
                   if (plannedConStartDate.getDay() == 0) {
                       plannedConStartDate = plannedConStartDate.addDays(1);
                   } else if (plannedConStartDate.getDay() == 6) {
                       plannedConStartDate = plannedConStartDate.addDays(2);
                   } else if (plannedConStartDate.getDay() != 0 && plannedConStartDate.getDay() != 6) {
                       plannedConStartDate = plannedConStartDate.addDays(0);
                   }
                   var plannedDesignEndDate = new Date(new Date(plannedConStartDate).addDays(-1));
                   if (plannedDesignEndDate.getDay() == 0) {
                       plannedDesignEndDate = plannedDesignEndDate.addDays(-2);
                   } else if (plannedDesignEndDate.getDay() == 6) {
                       plannedDesignEndDate = plannedDesignEndDate.addDays(-1);
                   } else if (plannedDesignEndDate.getDay() != 0 && plannedDesignEndDate.getDay() != 6) {
                       plannedDesignEndDate = plannedDesignEndDate.addDays(0);
                   }
                   var plannedDesignStartDate = new Date(new Date(plannedDesignEndDate).addDays(-Math.round(duration * 0.15)));
                   if (plannedDesignStartDate.getDay() == 0) {
                       plannedDesignStartDate = plannedDesignStartDate.addDays(1);
                   } else if (plannedDesignStartDate.getDay() == 6) {
                       plannedDesignStartDate = plannedDesignStartDate.addDays(2);
                   } else if (plannedDesignStartDate.getDay() != 0 && plannedDesignStartDate.getDay() != 6) {
                       plannedDesignStartDate = plannedDesignStartDate.addDays(0);
                   }
                   var plannedReqEndDate = new Date(new Date(plannedDesignStartDate).addDays(-1));
                   if (plannedReqEndDate.getDay() == 0) {
                       plannedReqEndDate = plannedReqEndDate.addDays(-2);
                   } else if (plannedReqEndDate.getDay() == 6) {
                       plannedReqEndDate = plannedReqEndDate.addDays(-1);
                   } else if (plannedReqEndDate.getDay() != 0 && plannedReqEndDate.getDay() != 6) {
                       plannedReqEndDate = plannedReqEndDate.addDays(0);
                   }
                   $("#plannedReqStartDate").val(currentScheduleStartDate);
                   $("#plannedReleaseEndDate").val(currentScheduleEndDate);
                   $("#plannedReleaseStartDate").val(plannedReleaseStartDate);
                   $("#plannedTestingEndDate").val(plannedTestingEndDate);
                   $("#plannedTestingStartDate").val(plannedTestingStartDate);
                   $("#plannedConEndDate").val(plannedConEndDate);
                   $("#plannedConStartDate").val(plannedConStartDate);
                   $("#plannedDesignEndDate").val(plannedDesignEndDate);
                   $("#plannedDesignStartDate").val(plannedDesignStartDate);
                   $("#plannedReqEndDate").val(plannedReqEndDate);
               } else {
                   $("#plannedReqStartDate").val(currentScheduleStartDate);
                   $("#plannedReleaseEndDate").val(currentScheduleEndDate);
                   $("#plannedReleaseStartDate").val(currentScheduleStartDate);
                   $("#plannedTestingEndDate").val(currentScheduleEndDate);
                   $("#plannedTestingStartDate").val(currentScheduleStartDate);
                   $("#plannedConEndDate").val(currentScheduleEndDate);
                   $("#plannedConStartDate").val(currentScheduleStartDate);
                   $("#plannedDesignEndDate").val(currentScheduleEndDate);
                   $("#plannedDesignStartDate").val(currentScheduleStartDate);
                   $("#plannedReqEndDate").val(currentScheduleEndDate);
               }

           }
       }
       Date.prototype.addDays = function(days) {
           this.setDate(this.getDate() + parseInt(days));
           var day = ("0" + this.getDate()).slice(-2);
           var month = ("0" + (this.getMonth() + 1)).slice(-2);
           return this.getFullYear() + '-' + month + '-' + day;
       };
       /*END : Planned Phase Timelines calculation code */
       
       
       /*START : Planned Phase Timelines calculation code - on hold */
       
       $('.onHoldClass').change(function(){
       	if(($("#stopDate").val()!=null || $("#stopDate").val()!="") && ($("#restartDate").val()!=null || $("#restartDate").val()!="")){
       		evaluatePhaseTimeLinesOnHold();
       	}
       });
       
       var previousPhase = $("#currentPhase").val();
	   	var phaseMap = new Map();
	   	phaseMap.set(24, "Req");
	   	phaseMap.set(25, 'Design');
	   	phaseMap.set(26, 'Con');
	   	phaseMap.set(27, 'Testing');
	   	phaseMap.set(28, 'Release');
	   	
	   	function evaluatePhaseTimeLinesOnHold() {
			alert("CurrentPhase :::::"+$("#currentPhase").val());
			alert("stopDate :::::"+$("#stopDate").val());
			alert("restartDate :::::"+$("#restartDate").val());
			alert("currentScheduleEndDate :::::"+$("#currentScheduleEndDate").val());
			alert("currentScheduleStartDate :::::"+$("#currentScheduleStartDate").val());
			alert("1 :: "+(ONHOLD_PHASE==$("#currentPhase").val()));
			alert("2 :: "+(null!=$("#stopDate").val()));
			alert("3 :: "+($("#stopDate").val()!=""));
			alert("4 :: "+(null!=$("#restartDate").val()));
			alert("5 :: "+($("#restartDate").val()!=""));
			alert("6 :: "+($("#stopDate").val()>$("#currentScheduleStartDate").val()));
			alert("7 :: "+($("#stopDate").val()<$("#currentScheduleEndDate").val()));
			
			
			if((ONHOLD_PHASE==$("#currentPhase").val()) && (null!=$("#stopDate").val()) && (""!=$("#stopDate").val()) && ($("#stopDate").val()>$("#currentScheduleStartDate").val()) &&
			(null!=$("#restartDate").val()) && (""!=$("#restartDate").val())){
				var stopDate = new Date($("#stopDate").val());
				var restartDate = new Date($("#restartDate").val());
				var onHoldDuration = (restartDate.getTime() - stopDate.getTime()) / (1000 * 60 * 60 * 24);
				var i=previousPhase;
				var phaseTimeLineStartDateId = "planned"+phaseMap.get(parseInt(i))+"StartDate";
				var phaseTimeLineEndDateId = "planned"+phaseMap.get(parseInt(i))+"EndDate";
				if(previousPhase==PRE_KICKOFF_PHASE || previousPhase==SCHEDULED_PHASE || previousPhase==ESTIMATION_PHASE ){
					i=REQUIREMENT_PHASE;
				}
				else if(previousPhase==POST_RELEASE_PHASE || previousPhase==CANCELLED_PHASE){
					return false;
				}
				else if(stopDate>new Date($("#"+phaseTimeLineStartDateId).val()) && stopDate<=new Date($("#"+phaseTimeLineEndDateId).val())){
					i=i;
				}
				else{
					i=i++;
				}
				
				for (i;i<=RELEASE_PHASE;i++){
					phaseTimeLineStartDateId = "planned"+phaseMap.get(parseInt(i))+"StartDate";
					phaseTimeLineEndDateId = "planned"+phaseMap.get(parseInt(i))+"EndDate";
					if(stopDate>new Date($("#"+phaseTimeLineStartDateId).val()) && stopDate<=new Date($("#"+phaseTimeLineEndDateId).val())){
						var phaseTimeLineStartDate=new Date((new Date($("#"+phaseTimeLineStartDateId).val())).addDays(0));
					}else{
						var phaseTimeLineStartDate=new Date((new Date($("#"+phaseTimeLineStartDateId).val())).addDays(onHoldDuration));
					}
					var phaseTimeLineEndDate=new Date((new Date($("#"+phaseTimeLineEndDateId).val())).addDays(onHoldDuration));
					if(phaseTimeLineStartDate.getDay()==0){
						phaseTimeLineStartDate = phaseTimeLineStartDate.addDays(1);
						$("#"+phaseTimeLineStartDateId).val(phaseTimeLineStartDate);
					}
					else if(phaseTimeLineStartDate.getDay()==6){
						var phaseTimeLineStartDate = phaseTimeLineStartDate.addDays(2);
						$("#"+phaseTimeLineStartDateId).val(phaseTimeLineStartDate);
					}
					else{
						var phaseTimeLineStartDate = phaseTimeLineStartDate.addDays(0);
						$("#"+phaseTimeLineStartDateId).val(phaseTimeLineStartDate);
					}
					
					if(phaseTimeLineEndDate.getDay()==0){
						var phaseTimeLineEndDate = phaseTimeLineEndDate.addDays(-2);
						$("#"+phaseTimeLineEndDateId).val(phaseTimeLineEndDate);
					}
					else if(phaseTimeLineEndDate.getDay()==6){
						var phaseTimeLineEndDate = phaseTimeLineEndDate.addDays(-1);
						$("#"+phaseTimeLineEndDateId).val(phaseTimeLineEndDate);
					}
					else{
						var phaseTimeLineEndDate = phaseTimeLineEndDate.addDays(0);
						$("#"+phaseTimeLineEndDateId).val(phaseTimeLineEndDate);
					}
					
				}
			}
			else{
					alert("In Else");
				}

		}
       
       /*END : Planned Phase Timelines calculation code - on hold */
		
		/* START : To set statusFlag - SAVE / SUBMIT , and validations*/
		$("#perSave").click(function(){
			var form = $('#perForm');
			if(form.parsley().validate({group: 'mandate'}) && form.parsley().validate({group: 'parent'}) ){
				if(($("#poNumber").val()!="" || $("#poAmount").val()!="") && ($("#newPoNumber").val()!="" || $("#newPoAmount").val()!="")){
					$(".parsley-newPoSaveError").text("");
					$("#newPoError").parsley().addError('newPoSaveError', {message: "Kindly save or cancel the newly added PO details"});
				}
				else{
					var status = $('#statusFlag').val();
					if(status == "A"){
						$('#statusFlag').val("A");
					}
					else
					{
						$('#statusFlag').val("S");
					}
					$("#perForm").find('input').prop('disabled', false);
					$("#perForm").find('select').prop('disabled', false);
					form.off('submit.Parsley');
				}
			}
			else{
				return;
			}
			
		});
		
		$("#perSubmit").click(function(){
			
			var form = $('#perForm');
			if(form.parsley().validate({group: 'mandate'}) && form.parsley().validate({group: 'parent'}) ){
				if(($("#poNumber").val()!="" || $("#poAmount").val()!="") && ($("#newPoNumber").val()!="" || $("#newPoAmount").val()!="")){
					$(".parsley-newPoSaveError").text("");
					$("#newPoError").parsley().addError('newPoSaveError', {message: "Kindly save or cancel the newly added PO details"});
				}
				else{
					$('#statusFlag').val("A");
					$("#perForm").find('input').prop('disabled', false);
					$("#perForm").find('select').prop('disabled', false);
					form.off('submit.Parsley');
				}
			}
			else{
				return;
			}
			
		});
		
		/* START : To set statusFlag - SAVE / SUBMIT , and validations*/
		
		$("#perDelete").click(function(){
			 if (confirm("Do you want DELETE this PER ??!!")) {
				 var form = $('#perForm');
					var ele = form.find('input').prop('disabled', false);
					form.off('submit.Parsley');
			 }
			 else{
				 return false;
			 }
		});
		
		$("#perCancel").click(function(){
			 if (confirm("Do you want discard the PER changes ??!!")) {
		        var form = $("#cancelForm");
  				form.attr('action','/Eztrac/per_edit');
  				form.submit();
		    } else {
		    	return;
		    }
		});
		
		
		/*START : PerNumber AutoComplete in Perlist page*/
		
		/*var perListForSelection = [];
		$("#perNumber").keypress(function() {
			if(perListForSelection=="" || perListForSelection==null){
				perListForSelection = getPerList();
				setTimeout(function(){ 
					$("#perNumber").autocomplete(perListForSelection); 
				}, 5000);
			}
		});
		
		var getPerList = function() {
			var perList = [];
			$.ajax({
			      type: "POST",
			      url: "/Eztrac/ajax/perAutocomplete",
			      dataType: "json", 
			      contentType: "application/json; charset=utf-8",
			      success :
			      function(response) {
			    	  console.log(response);
			    	  response.forEach(function(item, i){
			    		  perList.push(item);
			    	  });
			      }
			});
			perList.push("PR1234");
			perList.push("PR4353");
			perList.push("PR676576");
			perList.push("PRASDAS");
			perList.push("PRsdfgrtf");
			
			console.log("Listtttttttttttttttttttttttttttttt"+perList);
			return perList;
		}*/
		
		/*END : PerNumber AutoComplete in Perlist page*/
		
		

});