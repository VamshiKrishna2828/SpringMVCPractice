(function() {
	$(window).on('load', function() {

		$('.loader').fadeOut();
		$('.page-loader').delay(350).fadeOut('slow');
		$('#timeSheetForm').parsley();
		$("#searchresult").hide();
		$("#timesheetenrty").hide();
		$("#tsSummary").hide();
		$("#timeperiod").trigger("change");
		//$('#timeSheetMessage').hide();
	});
	
	var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
	var weeklyTotal = 0;
	var zero = 0;
	var saveOrSubmit = "N";
	$(document).ready(function(){
		
		//Ajaxcall to populate the subsystem details based on the selected system 
		$("#system").change(function() {
			$('#timeSheetMessage').hide();
			$("#subSystem").empty();
			var defaultOption = "<option value=\"\"> -select- </option>";
			$("#subSystem").append(defaultOption);
			var systemId = $('#system').val();
			$.ajax({
			      type: "POST",
			      url: "/Eztrac/ajax/timeSheetGetSubsystemList",
			      data: JSON.stringify(systemId), 
			      dataType: "json", 
			      contentType: "application/json; charset=utf-8",
			      success :
			      function(response) {
			    	  console.log(response);
			    	  response.forEach(function(item, i){
						var option = "<option value = "+ item.subSystemID+ ">" + item.subSystemName + "</option>";
						$("#subSystem").append(option);
					});
			      }
			});
		});

		//Commented By Yamuna - System and subSystem is not mandatory 
		/*$("#perNumber").focus(function() {
			if($('#system').val() ==''){
				$("#system").trigger("change");
			}
			if($("#subSystem").val() ==''){
				$("#subSystem").trigger("change");
			}
		});*/
		
		/*//Autocompletion code of PerNumber
		$("#perNumber").keypress(function() {
			$('#timeSheetMessage').hide();
			var period = $('#timeperiod').val();
			var systemId = $('#system').val();
			var subSystemId = $("#subSystem").val();
			
			var autoCompleteFlagValue = $('#autoCompleteFlag').val();
			var autoCompleteLengthValue = $('#autoCompleteLength').val();
			if(autoCompleteFlagValue === 'Y'){
				var perNumber=$("#perNumber").val();
				console.log("Pernumber in autocompleteion field is : "+perNumber);
				//if(parseInt(perNumber.length) >= autoCompleteLengthValue){
					var perListForSelection = getPerList(systemId, subSystemId, perNumber);
					setTimeout(function(){ 
						$("#perNumber").autocomplete(perListForSelection); 
					}, 5000);
				//}
			}
		});*/
		
		//Autocompletion code of PerNumber
		var perListForSelection =[];
		$("#perNumber").keypress(function() {
			$('#timeSheetMessage').hide();
			var period = $('#timeperiod').val();
			var systemId = $('#system').val();
			var subSystemId = $("#subSystem").val();
			
			var autoCompleteFlagValue = $('#autoCompleteFlag').val();
			var autoCompleteLengthValue = $('#autoCompleteLength').val();
			if(autoCompleteFlagValue === 'Y'){
				var perNumber=$("#perNumber").val();
				if(perListForSelection.length==0){
					perListForSelection = getPerList(systemId, subSystemId, perNumber);
				}
				else{
					$("#perNumber").autocomplete(perListForSelection); 
				}
			}
		});
		
		//To find currently selected task
		var lastSel = "";
		$('#table2 tbody').on('click', '.taskSelectBoxVisible', function() {
			$('#timeSheetMessage').hide();
			lastSel = $(this).find('option:selected');
		});
		
		//To check if the user is selecting the task for which already timesheet entry is already available
		$('#table2 tbody').on('change', '.taskSelectBoxVisible', function() {
			$('#timeSheetMessage').hide();
			var this$ = $(this);
			var currentTaskId=this$.val();
			var currentBuildId=this$.attr('buildId');
			var restrictChange = "N";
			
			//iterate each tasks - to figure out if there is any dulicate entry (i.e., buildId + TaskId combination )
			$(".taskSelectBoxVisible").each(function() {
				var $this = $(this);
				if(this$.is($this)){
					 return true;
				}
				var tempBuildId = $this.attr('buildId');
				var tempTaskId = $this.val();
				if(tempBuildId == currentBuildId && tempTaskId == currentTaskId){
					alert("Please select a different task");
					lastSel.prop("selected", true);
					restrictChange = "Y";
				}
			});
			
			//when a valid task is selected
			if(restrictChange =='N'){
				var selectedRow = this$.closest('tr');
				
				selectedRow.find("i[class^=taskRequiredError]").text("");
				
				//To rename the "name" attribute with the newly selected task
				selectedRow.find('.renameOnChange').each(function() {
					var name = $(this).attr('name');
					$(this).attr('name',renameField(name, /\[(.*?)\]/g, '['+currentTaskId+']', 2));							
				});
				
				/*//To clear the hours worked
				selectedRow.find("input[name$=hoursWorked]").each(function() {
					$(this).val('0');
					$(this).trigger("change");
				});*/
			}
			
		});
		
		/* START - Building Timesheet Data when the criterias are changed */
		$("#timeperiod").change(function() {
			$('#timeSheetMessage').hide();
			if($('#insertStatus').val()!=""){
				$('#timeSheetMessage').text($('#insertStatus').val());
				$('#timeSheetMessage').show();
				$('#insertStatus').val('');
			}
			buildTimeSheetData();
		});
		$("#system").change(function() {
			$('#timeSheetMessage').hide();
			var systemId = $('#system').val();
			if(systemId){
				buildTimeSheetData();
			}
		});
		$("#subSystem").change(function() {
			$('#timeSheetMessage').hide();
			var systemId = $('#system').val();
			var subSystemId = $('#subSystem').val();
			if(systemId && subSystemId){
				buildTimeSheetData();
			}
		});
		$("#perNumber").change(function() {
			$('#timeSheetMessage').hide();
			buildTimeSheetData();
		});
		
		/* END - Building Timesheet Data when the criterias are changed */
		
		//function to build the timesheet data
		var buildTimeSheetData = function(){
			
			var systemId = $('#system').val();
			var subSystemId = $("#subSystem").val();
			var period = $('#timeperiod').val();
			var perNumber = $('#perNumber').val();
			var startDate = period.split("-")[0].trim().replace(/\//g, "-");
			var endDate = period.split("-")[1].trim().replace(/\//g, "-");
			var formattedStartDate = getDateInyyyyDDmmFormat(startDate);
			var formattedEndDate = getDateInyyyyDDmmFormat(endDate);

			$('#table2 thead tr').html("");
			$('#table2 tbody').html("");
			$('#table2 tfoot tr').html("");
			$("#tsSummary").hide();
			//$('#timeSheetMessage').hide();

			
			if(""==systemId){
				systemId=null;
			}
			if(""==subSystemId){
				subSystemId=null;
			}
			if(""==perNumber){
				perNumber=null;
			}
			
			var	timesheetVOAjax = {
					"startDate":formattedStartDate,
					"endDate":formattedEndDate,
					"systemId" : systemId,
					"subSystemId" : subSystemId,
					"perNumber" : perNumber
			}
			
			//Ajax call to fetch the timesheet details based on criteria
			$.ajax({
			      type: "POST",
			      url: "/Eztrac/ajax/getTimeSheetList",
			      data: JSON.stringify(timesheetVOAjax), 
			      dataType: "json", 
			      contentType: "application/json; charset=utf-8",
			      success :
			      function(response) {
			    	  console.log(response);
			    	  
			    	  //If der is no data available for the given criteria - display the service response description to user
			    	  if(jQuery.isEmptyObject(response.timeSheetDetailMap)){
							var resMap= response.responseMap;
							console.log(resMap)
					    	 for (var i in resMap){
					    		 var msg = resMap[i];
					    	 }
			    		  	$("#timeSheetMessage").text(msg);
			    		  	$("#timeSheetMessage").show();
						}else{
							populateTimeSheetTable(startDate, endDate, response);
						}
			      }
			});
		};
		
		//Function to populate the timesheet table with the retrieved service response
		var populateTimeSheetTable = function(startDate, endDate, data){

			var inputMap = [];
			//Fetching dates b/t start n end dates
			var dates = getDates(new Date(startDate), new Date(endDate));                                                                                                           
			
			//Populating the header and footer fields of the Timesheet table
			$('#table2 thead tr').html("");
			/*$('#table2 thead tr').append("<td hidden=\"hidden\" style=\"width:10px;\"><input type=\"checkbox\" class=\"selectall1\" value=\"\"></td><th style=\"width: 80px;\">Project</th><th style=\"width: 240px;\">Project Description</th><td style=\"width: 170px; vertical-align: bottom; text-align: left; font-weight: bold;\">Tasks</td>");*/
			$('#table2 thead tr').append("<td style=\"width:10px;\"></td><th style=\"width: 80px;\">Project</th><th style=\"width: 240px;\">Project Description</th><td style=\"width: 170px; vertical-align: bottom; text-align: left; font-weight: bold;\">Tasks</td>");
			$('#table2 tbody').html("");
			$('#table2 tfoot tr').html("");
			$('#table2 tfoot tr').append("<th colspan=\"4\" style=\"text-align: center;\">Total</th>");
			
			//Populating the dates in Timesheet table based on the timeperiod selected
			var daysCount = 0;
			dates.forEach(function(date) {
				daysCount++;
				var d = new Date(date);
				var dayName = days[d.getDay()];
				var monthNumber = d.getMonth() + +1;
				
				$('#table2 thead tr').append("<th style=\"text-align: center;\" id="+dayName+">"+dayName+"("+monthNumber+"/"+d.getDate()+")</th>"); //E.g. id=mon, value=mon(3/22)
				/*$('#table2 tfoot tr').append("<td style=\"text-align: center;\" class=\"totalCell\" id=\""+dayName+"-Total\">0</td>");*/ //E.g. id=mon-Total
				$('#table2 tfoot tr').append("<td style=\"text-align: center;\"><div class=\"totalCell\" id=\""+dayName+"-Total\">0</div><div><i class=\"limitExceedError error\"></i></div></td>");
			});
			
			$('#table2 tfoot tr').append("<td style=\"text-align: center;\" id=\"weeklyTotal\">0</td>");
			
			/************************
			  inputMap = Map<Integer,Map<integer,List<TimesheetDetails>>>
			  eg : 
			  inputMap = 
			  0 : 9610_201416_232_224 : {224 : { 0:{attributes:values} , 1:{attributes:values} ............}},
			  1 : 9610_201416_232_225 : {225 : { 0:{attributes:values} , 1:{attributes:values} ............}}, ...................................
			 
			 where key of inputMap = perid + buildId + subSystemId + taskId
			 
			 *******************************/
			inputMap = data.timeSheetDetailMap;
			
			var counter = 0;
			var timeSheetObject;
			for (var i in inputMap){
				createRow(i, counter, dates);
			        for (var j in inputMap[i]){
			        	for(var k=0; k < inputMap[i][j].length; k++) {
			        		 timeSheetObject = inputMap[i][j][k];
			        		 console.log(timeSheetObject);
			        		 var workDate = timeSheetObject.workDate;
			        		 workDate = new Date(workDate);
			        		 if(k == 0){
				        		 $('#DESC-'+i+'').text(timeSheetObject.perDesc);
				        		 if(timeSheetObject.taskId!=""){
				        			 $('#TASK-'+i+' option[value='+timeSheetObject.taskId+']').attr('selected','selected');
				        			 $('#TASK-'+i).attr("disabled", true);
				        		 }
				        		 /*$('#TASK-'+i+' option[value='+timeSheetObject.taskId+']').attr('selected','selected');*/
				        		 $('#TASK-'+i+'').attr('name','timeSheetInsertionMap[\''+timeSheetObject.buildId+'\'][\''+timeSheetObject.taskId+'\']');
				        		 $('#TASK-'+i+'').attr('buildId',timeSheetObject.buildId);
				        		 $('#CHECKBOX-'+i+'').val(timeSheetObject.buildId);
				        		 $('#CHECKBOX-'+i+'').attr('name', 'timeSheetInsertionMap[\''+timeSheetObject.buildId+'\']');
			        		 }
			        		 if(timeSheetObject.subSystemName){
			        			 $('#PER-'+i+'').text(timeSheetObject.perNumber +" - "+ timeSheetObject.subSystemName);
			        		 }
			        		 if(timeSheetObject.readOnlyFlag === 'Y'){
			        			 $('#ROW-'+i+'HOURS-'+days[workDate.getDay()]+'').prop('disabled', true);
			        			 $('#ROW-'+i+'HOURS-'+days[workDate.getDay()]+'').prop('title', 'Invoice Date is crossed, Kindly contact HelpDesk to edit details');
			        			 $('#ROW-'+i+'HOURS-'+days[workDate.getDay()]+'').addClass("disableInput");
			        		 }
			        		 
			        		 $('#TSID-'+i+'COL-'+days[workDate.getDay()]+'').val(timeSheetObject.timeSheetId);
			        		 if(timeSheetObject.hoursWorked!="" || timeSheetObject.hoursWorked>0){
			        			 $('#ROW-'+i+'HOURS-'+days[workDate.getDay()]+'').val(timeSheetObject.hoursWorked);
			        			 if(timeSheetObject.statusCode=="S"){
			        				 $('#ROW-'+i+'HOURS-'+days[workDate.getDay()]+'').addClass("yellowBgColor");
			        			 }
			        			 else if(timeSheetObject.statusCode=="A" && timeSheetObject.readOnlyFlag != 'Y'){
			        				 $('#ROW-'+i+'HOURS-'+days[workDate.getDay()]+'').addClass("orangeBgColor");
			        			 }
			        		 }
			        		 /*$('#ROW-'+i+'HOURS-'+days[workDate.getDay()]+'').val(timeSheetObject.hoursWorked);*/
			        		 $('#READONLYFLAG-'+i+'COL-'+days[workDate.getDay()]+'').val(timeSheetObject.readOnlyFlag);
			        	}
			        	$("input[id^=ROW-"+i+"HOURS-]").each(function(){
					    	var cell = $(this);
					    	cell.attr('name','timeSheetInsertionMap[\''+timeSheetObject.buildId+'\'][\''+timeSheetObject.taskId+'\']' + cell.attr('name'));
						});
			        	$("input[id^=TSID-"+i+"COL-]").each(function(){
					    	var cell = $(this);
					    	cell.attr('name','timeSheetInsertionMap[\''+timeSheetObject.buildId+'\'][\''+timeSheetObject.taskId+'\']' + cell.attr('name'));
						});
			        	$("input[id^=DATE-"+i+"COL-]").each(function(){
					    	var cell = $(this);
					    	cell.attr('name','timeSheetInsertionMap[\''+timeSheetObject.buildId+'\'][\''+timeSheetObject.taskId+'\']' + cell.attr('name'));
						});
			        	$("input[id^=UpdateFlag-"+i+"COL-]").each(function(){
					    	var cell = $(this);
					    	cell.attr('name','timeSheetInsertionMap[\''+timeSheetObject.buildId+'\'][\''+timeSheetObject.taskId+'\']' + cell.attr('name'));
						});
			        	$("input[id^=READONLYFLAG-"+i+"COL-]").each(function(){
					    	var cell = $(this);
					    	cell.attr('name','timeSheetInsertionMap[\''+timeSheetObject.buildId+'\'][\''+timeSheetObject.taskId+'\']' + cell.attr('name'));
						});
					}
				counter++;
			}
			populateTotalValues();
			$('#perNumber').val("");
			$("#tsSummary").show();
		};
		
		//Function to create a row for the entered timesheet
		var createRow = function(rowIdentifier, counter, datesList) { //rowIdentifier = InputMap's key
			
			$('#table2 tbody').append("<tr id=\"ROW"+rowIdentifier+"\">" +
					/*"<td hidden=\"hidden\" style=\"width: 10px;\"><input id=\"CHECKBOX-"+rowIdentifier+"\" type=\"checkbox\" class=\"select\"></td>" +*/
					"<td style=\"width: 10px;\"><input id=\"CHECKBOX-"+rowIdentifier+"\" type=\"checkbox\" class=\"select\"></td>" +
					"<td id=\"PER-"+rowIdentifier+"\" style=\"text-align:left;\"></td>" +
					"<td id=\"DESC-"+rowIdentifier+"\" style=\"text-align:left;\"></td>");
			
			var taskListDropDown = $('#taskListDropDown').clone(true);
			taskListDropDown.attr('id',"TASK-"+rowIdentifier);
			taskListDropDown.addClass("taskSelectBoxVisible");
			//taskListDropDown.attr("disabled", true);
			$('#table2 tbody tr:last').append("<td id=\"taskTd\"><span style=\"float:left;\"></span></td>");
			$('#table2 tbody tr:last').find("td[id='taskTd']").find("span").append(taskListDropDown);
			$('#table2 tbody tr:last').find("td[id='taskTd']").find("span").append("<i class=\"taskRequiredError error\"> </i>");
			$('#table2 tbody tr:last').find("td[id='taskTd']").append("<span style=\"float:right;\"><span class=\"fa-stack fillAll\" title=\"Click here fill 8hrs for all days\"style=\"cursor: pointer;\"><span class=\"fa fa-circle-o fa-stack-2x\"></span><strong class=\"fa-stack-1x\">8</strong></span></span>");
			
			var dayCounter = 0;
			var day;
			var month;
			var formattedDate;
			datesList.forEach(function(date) {
				month = date.getMonth()+1;
				formattedDate = date.getFullYear()+"-"+month+"-"+date.getDate();
				day = days[date.getDay()];
				/*$('#table2 tbody tr:last').append("<td style=\"text-align: center;\">" +
						"<input class=\"nullifyOnDuplication renameOnChange\" type=\"hidden\" name=\"["+dayCounter+"].timeSheetId\" id=\"TSID-"+rowIdentifier+"COL-"+day+"\" />" +
						"<input class=\"nullifyOnDuplication renameOnChange\" value=\"N\" type=\"hidden\" name=\"["+dayCounter+"].readOnlyFlag\" id=\"READONLYFLAG-"+rowIdentifier+"COL-"+day+"\" />" +
						"<input class=\"renameOnChange\" type=\"hidden\" value=\""+formattedDate+"\" name=\"["+dayCounter+"].workDate\" id=\"DATE-"+rowIdentifier+"COL-"+day+"\" />" +
						"<input class=\"renameOnChange\" type=\"hidden\" value=\"N\" name=\"["+dayCounter+"].updateFlag\" id=\"UpdateFlag-"+rowIdentifier+"COL-"+day+"\" />" +
						"<input class=\"nullifyOnDuplication renameOnChange updateDaytotal\" name=\"["+dayCounter+"].hoursWorked\" value=\"0\" id=\"ROW-"+rowIdentifier+"HOURS-"+day+"\" style=\"width: 40px;\" " +
						"type=\"number\" value=\"0\" min=\"0\" max=\"24\" data-parsley-group=\"mandate\" data-parsley-trigger=\"change\"/></td>");*/
				$('#table2 tbody tr:last').append("<td style=\"text-align: center;\">" +
						"<input class=\"nullifyOnDuplication renameOnChange\" type=\"hidden\" name=\"["+dayCounter+"].timeSheetId\" id=\"TSID-"+rowIdentifier+"COL-"+day+"\" />" +
						"<input class=\"nullifyOnDuplication renameOnChange\" value=\"N\" type=\"hidden\" name=\"["+dayCounter+"].readOnlyFlag\" id=\"READONLYFLAG-"+rowIdentifier+"COL-"+day+"\" />" +
						"<input class=\"renameOnChange\" type=\"hidden\" value=\""+formattedDate+"\" name=\"["+dayCounter+"].workDate\" id=\"DATE-"+rowIdentifier+"COL-"+day+"\" />" +
						"<input class=\"renameOnChange\" type=\"hidden\" value=\"Y\" name=\"["+dayCounter+"].updateFlag\" id=\"UpdateFlag-"+rowIdentifier+"COL-"+day+"\" />" +
						"<input class=\"nullifyOnDuplication renameOnChange updateDaytotal\" name=\"["+dayCounter+"].hoursWorked\" value=\"0\" id=\"ROW-"+rowIdentifier+"HOURS-"+day+"\" style=\"width: 40px;\" " +
						"type=\"number\" value=\"0\" min=\"0\" max=\"24\" data-parsley-group=\"mandate\" data-parsley-trigger=\"change\"/></td>");
				dayCounter++;
			});
			$('#table2 tbody tr:last').append("<td><a href=\"#\"><i style=\"color: #D3D3D3;\" class=\"glyphicon glyphicon-plus-sign copyTask\"></i></a></td><td><a href=\"#\"><i style=\"color: #D3D3D3;\" class=\"glyphicon glyphicon-minus-sign deleteTask\"></i></a></button></td></tr>");
		};
					
		var populateTotalValues = function() {
			weeklyTotal = 0;
			$("tfoot tr .totalCell").each(function() {
			    var id = $(this).attr("id");
			    var totalDayName = id.split("-Total", 1);
			    var totalDayValue = 0;
			    $("input[id$=HOURS-"+totalDayName+"]").each(function(){
			    	var colValue = $(this).val();
				    totalDayValue = +totalDayValue + +colValue;
				});
			    $('#'+id+'').text(totalDayValue);
			    weeklyTotal = weeklyTotal + +totalDayValue;
			});
			$("#weeklyTotal").text(weeklyTotal);
		};
       
		//to fill all the fields values as 8
		$('#timeSheetForm').on('click', '.fillAll', function() {
			$('#timeSheetMessage').hide();
			var selectedRow = $(this).closest('tr');
			selectedRow.find("input[name$=hoursWorked]").each(function() {
				var readOnlyFlag = $(this).closest('td').find("[id^=READONLYFLAG-]").val();
				if(readOnlyFlag == 'N' || readOnlyFlag == ''){
					$(this).val('8');			    
					$(this).trigger("change");
				}
			});
		});
		
		/*//To calculate the total value when the entries are changed AND to set the updateFlag
		$('#timeSheetForm').on('change', '.updateDaytotal', function() {
			$('#timeSheetMessage').hide();
			var form = $('#timeSheetForm');
			if (form.parsley().validate({group: 'mandate'})) {
				var updatedDayName = this.id.split("HOURS-")[1];
				var updateFlagVariableName = this.name.split(".hoursWorked")[0]+".updateFlag";
				var totalCellId = updatedDayName+"-Total";
				var updatedTotalDayValue = 0;
				var dayTotalGreaterThan24 = 'N';
				if($(this).val() > 0){
					$(this).prev("[id^=UpdateFlag-]").val('Y');
				}else{
					$(this).prev("[id^=UpdateFlag-]").val('N');
				}
				$("input[id$=HOURS-"+updatedDayName+"]").each(function(){
			    	var colValue = $(this).val();
			    	updatedTotalDayValue = +updatedTotalDayValue + +colValue;
				});
				$('#'+totalCellId+'').text(updatedTotalDayValue);
				
				weeklyTotal = 0;
				$("tfoot tr .totalCell").each(function() {
				    var totalValue = this.textContent;
				    weeklyTotal = weeklyTotal + +totalValue;
				    if(totalValue > 24){
			    		dayTotalGreaterThan24 = 'Y';
			    	}
				});
				
				if(dayTotalGreaterThan24 == 'Y'){
					$("#timeSheetMessage").text(" hours");
					$('#timeSheetMessage').show();
					$('#saveButton').addClass("disableButton");
					$('#saveButton').prop('disabled', true);
					$('#submitButton').addClass("disableButton");
					$('#submitButton').prop('disabled', true);
				}else{
					$("#timeSheetMessage").text("");
					$('#timeSheetMessage').hide();
					$('#saveButton').removeClass("disableButton");
					$('#saveButton').prop('disabled', false);
					$('#submitButton').removeClass("disableButton");
					$('#submitButton').prop('disabled', false);
				}
				
				$("#weeklyTotal").text(weeklyTotal);
			}
		});*/
		
		//To calculate the total value when the entries are changed AND to set the updateFlag
		$('#timeSheetForm').on('change', '.updateDaytotal', function() {
			$('#timeSheetMessage').hide();
			var form = $('#timeSheetForm');
			if (form.parsley().validate({group: 'mandate'})) {
				var updatedDayName = this.id.split("HOURS-")[1];
				var updateFlagVariableName = this.name.split(".hoursWorked")[0]+".updateFlag";
				var totalCellId = updatedDayName+"-Total";
				var updatedTotalDayValue = 0;
				var dayTotalGreaterThan24 = 'N';
				$("input[id$=HOURS-"+updatedDayName+"]").each(function(){
			    	var colValue = $(this).val();
			    	updatedTotalDayValue = +updatedTotalDayValue + +colValue;
				});
				$('#'+totalCellId+'').text(updatedTotalDayValue);
				
				weeklyTotal = 0;
				$("tfoot tr .totalCell").each(function() {
				    var totalValue = this.textContent;
				    weeklyTotal = weeklyTotal + +totalValue;
				    var totalElement = $(this).closest('td');
				    if(totalValue > 24){
			    		dayTotalGreaterThan24 = 'Y';
			    		totalElement.find("i[class^=limitExceedError]").text("Day Limit Exceeded");
			    	}
				    else{
				    	totalElement.find("i[class^=limitExceedError]").text("");
				    }
				});
				
				if(dayTotalGreaterThan24 == 'Y'){
					$("#timeSheetMessage").text("Day limit exceeded!! (Max = 24 hrs)");
					$('#timeSheetMessage').show();
					$('#saveButton').addClass("disableButton");
					$('#saveButton').prop('disabled', true);
					$('#submitButton').addClass("disableButton");
					$('#submitButton').prop('disabled', true);
				}else{
					$("#timeSheetMessage").text("");
					$('#timeSheetMessage').hide();
					$('#saveButton').removeClass("disableButton");
					$('#saveButton').prop('disabled', false);
					$('#submitButton').removeClass("disableButton");
					$('#submitButton').prop('disabled', false);
				}
				
				$("#weeklyTotal").text(weeklyTotal);
			}
		});
		
		function calculateTotal(){
			for(var d=0;d<days.length;d++){
				var updatedDayName =days[d];
				var totalCellId = updatedDayName+"-Total";
				var updatedTotalDayValue = 0;
				var dayTotalGreaterThan24 = 'N';
				$("input[id$=HOURS-"+updatedDayName+"]").each(function(){
			    	var colValue = $(this).val();
			    	updatedTotalDayValue = +updatedTotalDayValue + +colValue;
				});
				$('#'+totalCellId+'').text(updatedTotalDayValue);
				
				weeklyTotal = 0;
				$("tfoot tr .totalCell").each(function() {
				    var totalValue = this.textContent;
				    weeklyTotal = weeklyTotal + +totalValue;
				    var totalElement = $(this).closest('td');
				    if(totalValue > 24){
			    		dayTotalGreaterThan24 = 'Y';
			    		totalElement.find("i[class^=limitExceedError]").text("Day Limit Exceeded");
			    	}
				    else{
				    	totalElement.find("i[class^=limitExceedError]").text("");
				    }
				});
				
				if(dayTotalGreaterThan24 == 'Y'){
					$("#timeSheetMessage").text("Day limit exceeded!! (Max = 24 hrs)");
					$('#timeSheetMessage').show();
					$('#saveButton').addClass("disableButton");
					$('#saveButton').prop('disabled', true);
					$('#submitButton').addClass("disableButton");
					$('#submitButton').prop('disabled', true);
				}else{
					$("#timeSheetMessage").text("");
					$('#timeSheetMessage').hide();
					$('#saveButton').removeClass("disableButton");
					$('#saveButton').prop('disabled', false);
					$('#submitButton').removeClass("disableButton");
					$('#submitButton').prop('disabled', false);
				}
				
				$("#weeklyTotal").text(weeklyTotal);
			}
		}
		var isSelected = "N";
		$("#saveButton").click(function() {
			if (confirm("Do you want SAVE the changes ??!!")) {
				saveOrSubmit = "Y";
				
				//var isSelected = "N";
				$('#timeSheetForm').find("input[class^=select]").each(function(){
					 if (this.checked) {
						 isSelected = "Y";
						 return false;
					 }
				});
				if(isSelected == "Y"){
					alert("selected");
					$('#timeSheetForm').find("input[class^=select]").each(function(){
						var row = $(this).closest('tr');
					    if (this.checked) {
					    	row.find("input[id^=UpdateFlag-]").each(function(){
								var readOnlyVal = $(this).closest('td').find("[id^=READONLYFLAG-]").val();
								if(readOnlyVal=="Y"){
									$(this).val("N");
								}
								else{
									$(this).val("Y");
								}
								//alert("readOnly====="+readOnlyVal+"\nUpdateValue====="+$(this).val());
					    	});
					    }
					    else{
					    	row.find("input[id^=UpdateFlag-]").each(function(){
					    		$(this).val("N");
					    	});
					    }
					});
				}
				else{
					alert("not selected");
					var tasks = $("select[id^=TASK-]");
					for(var t=0;t<tasks.length;t++){
						var row = $(tasks[t]).closest('tr');
						row.find("input[id^=UpdateFlag-]").each(function(){
							var readOnlyVal = $(this).closest('td').find("[id^=READONLYFLAG-]").val();
							if(readOnlyVal=="Y"){
								$(this).val("N");
							}
							else{
								$(this).val("Y");
							}
							//alert("readOnly====="+readOnlyVal+"\nUpdateValue====="+$(this).val());
				    	});
					}
				}
			}
			else{
				saveOrSubmit = "N";
			}
		});
		
		$("#submitButton").click(function() {
			if (confirm("Do you want SUBMIT the changes ??!!")) {
				saveOrSubmit = "Y";
				
				//var isSelected = "N";
				$('#timeSheetForm').find("input[class^=select]").each(function(){
					 if (this.checked) {
						 isSelected = "Y";
						 return false;
					 }
				});
				if(isSelected == "Y"){
					alert("selected");
					$('#timeSheetForm').find("input[class^=select]").each(function(){
						var row = $(this).closest('tr');
					    if (this.checked) {
					    	row.find("input[id^=UpdateFlag-]").each(function(){
								var readOnlyVal = $(this).closest('td').find("[id^=READONLYFLAG-]").val();
								if(readOnlyVal=="Y"){
									$(this).val("N");
								}
								else{
									$(this).val("Y");
								}
								//alert("readOnly====="+readOnlyVal+"\nUpdateValue====="+$(this).val());
					    	});
					    }
					    else{
					    	row.find("input[id^=UpdateFlag-]").each(function(){
					    		$(this).val("N");
					    	});
					    }
					});
				}
				else{
					alert("not selected");
					var tasks = $("select[id^=TASK-]");
					for(var t=0;t<tasks.length;t++){
						var row = $(tasks[t]).closest('tr');
						row.find("input[id^=UpdateFlag-]").each(function(){
							var readOnlyVal = $(this).closest('td').find("[id^=READONLYFLAG-]").val();
							if(readOnlyVal=="Y"){
								$(this).val("N");
							}
							else{
								$(this).val("Y");
							}
							//alert("readOnly====="+readOnlyVal+"\nUpdateValue====="+$(this).val());
				    	});
					}
				}
			}
			else{
				saveOrSubmit = "N";
			}
		});
		
		$("#timeSheetForm").on('submit',function(e) {
			var taskRequired = "N"; 
			if(saveOrSubmit == "Y"){
				$('#timeSheetForm').find("input[class^=select]").each(function(){
					 if (this.checked) {
						 isSelected = "Y";
						 return false;
					 }
				});
				if(isSelected == "Y"){
					$('#timeSheetForm').find("input[class^=select]").each(function(){
						var row = $(this).closest('tr');
					    if (this.checked) {
					    	row.find("select[id^=TASK-]").each(function(){
					    		if(""==$(this).val()){
					    			taskRequired = "Y";
					    			row.find("i[class^=taskRequiredError]").text("Task is required");
									return false;
					    		}
					    	});
					    }
					});
				}
				else{
					alert("not selecteddddddddddddddddddddddddddd");
					var tasks = $("select[id^=TASK-]");
					for(var t=0;t<tasks.length;t++){
						if(""==$(tasks[t]).val()){
							alert("task empty........."+t);
							var curRow = $(tasks[t]).closest('tr');
							curRow.find("input[id^=ROW-]").each(function(){
								if(""!=$(this).val() && zero!=$(this).val()){
									alert("its not zerooooooooooooooo");
									taskRequired = "Y";
									curRow.find("i[class^=taskRequiredError]").text("Task is required");
									return false;
								}
							});
						}
					}
				}
				if(taskRequired=="N"){
					alert("nottttttttttt requieredddddddddddddd");
					return;
				}
				else{
					alert("requireddddddddddddddddddddd");
					return false;
				}
			}
			else{
				return false;
			}
			
		});
		
		$("#deleteButton").click(function() {
			$('#timeSheetMessage').hide();
			if(confirm("Do you want DELETE all the timesheets entered for this week ??!!")){
				var timesheetIds = [];
				var deleteFlag;
				$("input[id^=CHECKBOX-]").each(function(){
					var currentRow = $(this).parent().parent();
					var canDelete;
					currentRow.find("input[id^=READONLYFLAG-]").each(function(){
						if($(this).val() == "Y"){
							canDelete="N";
							return false;
						}
						else{
							canDelete="Y";
						}
					});
					if(canDelete=="Y"){
						var timeSheetId; 
						currentRow.find("input[name$=timeSheetId]").each(function() {
							timeSheetId = $(this).val();
						    if(timeSheetId){  
						    	timesheetIds.push(parseInt(timeSheetId));
						    }
						});
						currentRow.remove();
					}
					else{
						deleteFlag = "N";
						return false;
					}
				});
				if(deleteFlag == "N"){
					alert("cannot delete");
					$("#timeSheetMessage").text("Invoice Date is crossed, Kindly contact Helpdesk to Delete the records !!");
					$("#timeSheetMessage").show();
				}
				else{
					$.ajax({
						   type: "POST",
						   url: "/Eztrac/ajax/deleteTimeSheet",
						   data: JSON.stringify(timesheetIds),
						   dataType: "json", 
						   contentType: "application/json; charset=utf-8",
						   success: function(response){
							   var resMap= response.responseMap;
							   console.log(resMap)
							    console.log("success from list");
							   if(null!=resMap && ""!=resMap){
								   $("#timeSheetMessage").text("The records are sucessfully deleted");
								   $("#timeSheetMessage").show();
							   }
							   else{
								   $("#timeSheetMessage").text("Could not delete the records.....Please try later");
								   $("#timeSheetMessage").show();
							   }
						   }
					});
					populateTotalValues();
				}
			}
			else{
				return false;
			}
			
		});
		
		$('#table2 tbody').on('click', '.deleteTask', function() {
			$('#timeSheetMessage').hide();
			if(confirm("Do you want DELETE this timesheet entry ??!!")){
				var timesheetIds = [];
				var currentRow = $(this).closest('tr');
				var timeSheetId; 
				var canDelete;
				var newlyAdded;
				currentRow.find("input[id^=TSID-]").each(function(){
					if($(this).val()==null || $(this).val()==""){
						newlyAdded = "Y";
					}
					else{
						newlyAdded = "N";
						return false;
					}
				});
				if(newlyAdded == "Y"){
					for(day=0;day<days.length;day++){
						currentRow.find("input[id$=HOURS-"+days[day]+"]").val('');
					}
					calculateTotal();
					currentRow.remove();
				}
				else{
					currentRow.find("input[id^=READONLYFLAG-]").each(function(){
						if($(this).val() == "Y"){
							canDelete="N";
							return false;
						}
						else{
							canDelete="Y";
						}
					});
					if(canDelete=="Y"){
						alert("can delete");
						currentRow.find("input[name$=timeSheetId]").each(function() {
							timeSheetId = $(this).val();
						    if(timeSheetId){  
						    	timesheetIds.push(parseInt(timeSheetId));
						    }
						});
						currentRow.remove();
						$.ajax({
							   type: "POST",
							   url: "/Eztrac/ajax/deleteTimeSheet",
							   data: JSON.stringify(timesheetIds),
							   dataType: "json", 
							   contentType: "application/json; charset=utf-8",
							   success: function(response){
								   var resMap= response.responseMap;
								   console.log(resMap)
								   if(null!=resMap && ""!=resMap){
									   $("#timeSheetMessage").text("The record is sucessfully deleted");
									   $("#timeSheetMessage").show();
								   }
								   else{
									   $("#timeSheetMessage").text("Could not delete the record.....Please try later");
									   $("#timeSheetMessage").show();
								   }
							   }
						});
						populateTotalValues();
					}
					else{
						alert("cannot delete");
						$("#timeSheetMessage").text("Invoice Date is crossed, Kindly contact Helpdesk to this Delete record!!");
						$("#timeSheetMessage").show();
					}
				}
			}
			else{
				return false;
			}
		});

		//on click of cancel button
		$("#can").click(function() {
			$('#timeSheetMessage').hide();
			if(confirm("Unsaved data will be lost!!!!\n Do you want to cancel ??")){
				buildTimeSheetData();
			}
			else{
				return false;
			}
		});
		
		//Function to return all dates between the provided arguments(i.e., startDate and endDate)
		var getDates = function(startDate, endDate) {
			
			  var dates = [],
			      currentDate = startDate,
			      addDays = function(days) {
			        var date = new Date(this.valueOf());
			        date.setDate(date.getDate() + days);
			        return date;
			      };
			  while (currentDate <= endDate) {
			    dates.push(currentDate);
			    currentDate = addDays.call(currentDate, 1);
			  }
			  return dates;
		};
		
		//Function to get Date in a yyyy-DD-mm format
		var getDateInyyyyDDmmFormat = function(inputDate) {
			
			var convertedDate = new Date(inputDate);
			var month = convertedDate.getMonth()+1;
			var formattedDate = convertedDate.getFullYear()+"-"+month+"-"+convertedDate.getDate();
			return formattedDate;
		};
		
		//Ajax call to fetch the list of Pernumbers
		var getPerList = function(systemId, subSystemId, perNumber) {
			var perList = [];
			if(""==systemId){
				systemId=null;
			}
			if(""==subSystemId){
				subSystemId=null;
			}
			if(""==perNumber){
				perNumber=null;
			}
			var	timesheetVOAjax = {
					"systemId" : systemId,
					"subSystemId" : subSystemId,
					"perNumber" : perNumber
			}
			$.ajax({
			      type: "POST",
			      url: "/Eztrac/ajax/getPerListForAutoComplete",
			      data: JSON.stringify(timesheetVOAjax), 
			      dataType: "json", 
			      contentType: "application/json; charset=utf-8",
			      async: false,
			      success :
			      function(response) {
			    	  console.log(response);
			    	  response.forEach(function(item, i){
			    		  perList.push(item);
			    	  });
			      }
			});
			console.log("Listtttttttttttttttttttttttttttttt"+perList);
			return perList;
		}
			
		//To add a new entry in timesheet table
		$('#table2 tbody').on('click', '.copyTask', function() {
			$('#timeSheetMessage').hide();
			var rowToCopy = $(this).closest('tr').clone(true);
			rowToCopy.find("input.nullifyOnDuplication").val('');
			rowToCopy.find('select').find('option:selected').removeAttr('selected');
			rowToCopy.find('select').val('');
			rowToCopy.find('select').attr("disabled", false);
			rowToCopy.find("input[id^=ROW-]").each(function(){
				$(this).attr("disabled", false);
				$(this).removeClass("disableInput");
				$(this).removeAttr( "title");
				$(this).removeClass("yellowBgColor");
				$(this).removeClass("orangeBgColor");
				
			});
			rowToCopy.find('.renameOnChange').each(function() {
				var name = $(this).attr('name');
				$(this).attr('name',renameField(name, /\[(.*?)\]/g, '[0]', 2));
			});
			rowToCopy.find("i[class^=taskRequiredError]").text("");
			rowToCopy.find("input[name$=hoursWorked]").each(function() {
				$(this).val('0');
				//$(this).trigger("change");
			});
			rowToCopy.find("input[name$=readOnlyFlag]").each(function() {
				$(this).val('N');
			});
			$('#table2 tbody').append(rowToCopy);
		});
		
		function renameField(source, pattern, replacement, n) {
			  var substr = '';
			  while (substr = pattern.exec(source)) {
			    if (--n === 0) {
			      source = source.slice(0, substr.index) + replacement + source.slice(pattern.lastIndex);
			      break;
			    }
			  }
			  return source;
		}			
	});
	
})(jQuery);