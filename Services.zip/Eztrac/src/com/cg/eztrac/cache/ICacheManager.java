package com.cg.eztrac.cache;

import net.sf.ehcache.Element;

public interface ICacheManager {
	public boolean addDataToCache(Element element,String cacheName);
	public Element getDataFromCache(String objectValueName,String cacheName);
}
