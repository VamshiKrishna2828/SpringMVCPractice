package com.cg.eztrac.securityconfig;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.servlet.ServletContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.AuthDO;
import com.cg.eztrac.domain.RolePermissionDO;
import com.cg.eztrac.domain.SectionDetailDO;
import com.cg.eztrac.handler.OnLoadHandler;
import com.cg.eztrac.vo.SectionVO;
import com.cg.eztrac.vo.SubSectionVO;

@Configuration
@EnableWebSecurity
@ComponentScan("com.cg.eztrac")
@PropertySource("classpath:appurlcontroller.properties")
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	private static String CLASS_NAME = SecurityConfig.class.getName();

	@Autowired
	public ServletContext servletcontext;

	@Autowired
	private CustomAuthenticationProvider authProvider;

	@Autowired
	OnLoadHandler onLoadHandler;

	@Autowired
	public Environment env;

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authProvider);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		String methodName = "configure";

		if (env.getProperty("eztrack.security.enableflag").equalsIgnoreCase(ICommonConstants.Y_STRING)) {

			LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
					"Spring Security is ON Start");

			if (allRoleMenuAccebiltiy()) {

				Map<Integer, Map<Integer, List<SectionVO>>> allAuthObjs = (Map<Integer, Map<Integer, List<SectionVO>>>) servletcontext
						.getAttribute(ICommonConstants.All_AUTH_OBJS_ACCESS_CONTEXT);

				// Roles and their Sections from GetAllRolePermission &
				// GetAllSectionDetails
				// Service calls are updated to a single List of AUTHDO objects.
				List<AuthDO> authObjs = getAllAuthDOObjects(allAuthObjs);

				// Read all from appurlcontroller.properties
				Map<String, Object> urlMap = getAllUrlProperties(ICommonConstants.APP_URL_PROP_FILE_NAME,
						servletcontext);

				// Process all URL and their permission in a map like URL as key
				// and roles as
				// values from unformatted appurlcontroller.properties
				Map<String, String> finalProp = processUrlAndRoles(urlMap, authObjs);

				if (null == finalProp || finalProp.isEmpty()) {
					Exception exe = new Exception("Error in Processing Url and Roles from Service vs Property File");
					LoggerManager.writeErrorLog(CLASS_NAME, methodName, "Processing error for URL & Roles", exe,
							exe.getMessage());
					throw exe;
				}

				// @formatter:off
				LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
						"Allow Generic Asset URL START");
				
				http.authorizeRequests().antMatchers(env.getProperty("eztrack.generic.asset.url")).permitAll();
				http.authorizeRequests().antMatchers(env.getProperty("eztrack.prelogin.default.url")).permitAll();
				
				LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
						"Allow Generic Asset URL END");

				for (Entry<String, String> entry : finalProp.entrySet()) {
					String url = entry.getKey().trim();
					String roles = entry.getValue().trim();

					http.authorizeRequests().and().authorizeRequests().antMatchers(url).access(roles);
					LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
							"Setting Role for " + url + "-->" + roles);
				}
				
				http.authorizeRequests()
						.antMatchers(env.getProperty("eztrack.postlogin.home.url")).authenticated()
						.antMatchers(env.getProperty("eztrack.postlogin.ajax.prefix.url")).authenticated()
					.and()
							.formLogin()
							.loginPage(env.getProperty("eztrack.prelogin.login.url")).permitAll()
							.failureUrl(env.getProperty("eztrack.prelogin.login.failureUrl")).permitAll()
							.successForwardUrl(env.getProperty("eztrack.postlogin.home.url"))
							//.successHandler(authenticationSuccessHandler())
				    .and()
					    	.logout()
					    	.logoutUrl(env.getProperty("eztrack.postlogin.logout.url")).permitAll()
					    	.invalidateHttpSession(true)
					    	.clearAuthentication(true)
					    	.logoutSuccessUrl(env.getProperty("eztrack.prelogin.login.url")).permitAll()
				    .and()
							.exceptionHandling().accessDeniedPage(env.getProperty("eztrack.postlogin.accessdenied.url"))
					.and()
							.sessionManagement().maximumSessions(Integer.parseInt(env.getProperty("eztrack.security.maximumSessions")))
							.expiredUrl(env.getProperty("eztrack.postlogin.sessionexpiry.url")).and()
					.and()
							.authorizeRequests().anyRequest().denyAll();

				LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
						"Login,Exception,Session Management is SET in Security");

				http.csrf().disable();
				// @formatter:on

			} else {
				Exception exe = new Exception("Could Not load Role Permissions to Context");
				LoggerManager.writeErrorLog(CLASS_NAME, methodName,
						"Exception becasue allRoleMenuAccebiltiy() is false", exe, exe.getMessage());
				throw exe;
			}

			LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
					"Spring Security Configure END");
		} else {

			LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
					"Spring Security is OFF START");

			http.authorizeRequests().antMatchers(env.getProperty("eztrack.generic.all.url")).permitAll();
			http.csrf().disable();

			LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
					"Spring Security is OFF END");
		}
	}

	public Map<String, String> processUrlAndRoles(Map<String, Object> urlMap, List<AuthDO> authObjs) {
		String methodName = "processUrlAndRoles";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
				"Processing URL & Roles START");

		Map<String, String> processedProp = new HashMap<String, String>();
		for (Map.Entry<String, Object> entry : urlMap.entrySet()) {
			String roles = "";
			String sectionNameFromProp = ((String) entry.getValue()).trim();
			// String urlFromProp = ((String) entry.getValue()).trim();
			String url = entry.getKey().trim();
			String sectionName = "";
			String subsectionName = "";
			boolean isSubMenu = false;

			if (sectionNameFromProp.contains(ICommonConstants.ONE_DOLLAR_STRING)) {
				String splitChar = "\\" + ICommonConstants.ONE_DOLLAR_STRING;
				String[] temp = sectionNameFromProp.split(splitChar);
				if (null != temp && temp.length == 2) {
					// url = temp[1].trim();
					sectionName = temp[0].trim();
					subsectionName = temp[1].trim();
					;
					isSubMenu = true;
				} else {
					System.out.println("temp[0].trim()" + temp[0].trim());
				}
			} else {
				// url = urlFromProp;
				sectionName = sectionNameFromProp.trim();
			}
			// System.out.println("urlFromProp - " + urlFromProp);
			System.out.println("URL - " + url);
			for (AuthDO authDO : authObjs) {

				if (!isSubMenu && authDO.isElligbleFlag() && authDO.getSectionType().intValue() == 1
						&& sectionName.equalsIgnoreCase(authDO.getSectionName().trim())
						&& !authDO.getRoleName().isEmpty()) {

					roles = addRoleString(roles, authDO.getRoleName().trim());
					/*
					 * System.out.println("         Role - " +
					 * authDO.getRoleName() + " getSectionName - " +
					 * authDO.getSectionName() + " getSectionType - " +
					 * authDO.getSectionType() + " isElligbleFlag - " +
					 * authDO.isElligbleFlag());
					 */
				} else if (isSubMenu && authDO.isElligbleFlag() && authDO.getSectionType().intValue() == 1
						&& sectionName.equalsIgnoreCase(authDO.getSectionName().trim())
						/*&& null != authDO.getSubSectionName() && authDO.getSubSectionType().intValue() == 3*/
						&& null != authDO.getSubSectionName() && authDO.getSubSectionType().intValue() == 4
						&& subsectionName.equalsIgnoreCase(authDO.getSubSectionName().trim())
						&& !authDO.getRoleName().isEmpty()) {

					roles = addRoleString(roles, authDO.getRoleName().trim());
					/*
					 * System.out.println("         Role - " +
					 * authDO.getRoleName() + " getSectionName - " +
					 * authDO.getSectionName() + " getSectionType - " +
					 * authDO.getSectionType() + " getSubSectionName - " +
					 * authDO.getSubSectionName() + " getSubSectionType - " +
					 * authDO.getSubSectionType() + " isElligbleFlag - " +
					 * authDO.isElligbleFlag());
					 */
				} else if (isSubMenu && authDO.isElligbleFlag() && authDO.getSectionType() == 2
						&& sectionName.equalsIgnoreCase(authDO.getSectionName().trim())
						&& null != authDO.getSubSectionName()
						&& subsectionName.equalsIgnoreCase(authDO.getSubSectionName().trim())) {
					roles = addRoleString(roles, authDO.getRoleName().trim());
					/*
					 * System.out.println("         Role - " +
					 * authDO.getRoleName() + " getSectionName - " +
					 * authDO.getSectionName() + " getSectionType - " +
					 * authDO.getSectionType() + " getSubSectionName - " +
					 * authDO.getSubSectionName() + " getSubSectionType - " +
					 * authDO.getSubSectionType() + " isElligbleFlag - " +
					 * authDO.isElligbleFlag());
					 */
				}

			}
			if (!roles.isEmpty()) {
				processedProp.put(url, roles);
			} else {
				LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
						"Processing " + url + "<<<<<Not Set in DB>>>>");
			}

		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
				"Processing URL & Roles END");
		return processedProp;
	}

	public List<AuthDO> getAllAuthDOObjects(Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy) {
		String methodName = "getAllAuthDOObjects";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
				"Converting Sections & SubSections into Auth DO's START");
		List<AuthDO> authObjs = new ArrayList<>();

		for (Entry<Integer, Map<Integer, List<SectionVO>>> roleMap : allRoleMenuAccebiltiy.entrySet()) {
			Integer roleKey = roleMap.getKey();
			String rolename = setRoleName(roleKey);
			Map<Integer, List<SectionVO>> sectionsMap = roleMap.getValue();

			for (Entry<Integer, List<SectionVO>> sectionMap : sectionsMap.entrySet()) {

				List<SectionVO> sectionsVO = sectionMap.getValue();
				for (SectionVO sectionVO : sectionsVO) {
					authObjs.add(new AuthDO(roleKey, rolename, sectionVO.getSectionId(), sectionVO.getSectionName(),
							sectionVO.getSectionType(), null, null, null, sectionVO.isElligbleFlag(),
							ICommonConstants.EMPTY_URL_STRING));

					for (SubSectionVO subSectionVO : sectionVO.getSubSectionVO()) {
						authObjs.add(new AuthDO(roleKey, rolename, sectionVO.getSectionId(), sectionVO.getSectionName(),
								sectionVO.getSectionType(), subSectionVO.getSubSectionId(),
								subSectionVO.getSubSectionName(), subSectionVO.getSubSectionType(),
								subSectionVO.isElligbleFlag(), ICommonConstants.EMPTY_URL_STRING));
					}
				}
			}
		}

		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
				"Converting Sections & SubSections into Auth DO's END");
		return authObjs;
	}

	/*@Bean
	AuthenticationSuccessHandler authenticationSuccessHandler() {
		return new AuthenticationSuccessHandler() {
			@Override
			public void onAuthenticationSuccess(HttpServletRequest req, HttpServletResponse res, Authentication auth)
					throws IOException, ServletException {
				res.sendRedirect(req.getContextPath() + env.getProperty("eztrack.postlogin.home.url"));
			}
		};
	}*/

	public String addRoleString(String source, String roleToAppend) {
		String addOrStr = ICommonConstants.OR_STRING_WITH_SPACE_BEFORE_AFTER;
		String proRoleToAppend = ICommonConstants.SPRING_HAS_ROLE_START + roleToAppend
				+ ICommonConstants.SPRING_HAS_ROLE_END;

		if (source.isEmpty() && source.length() < 1) {
			source = source.concat(proRoleToAppend);
		} else {
			String[] strs = source.split(ICommonConstants.OR_STRING_WITH_SPACE_BEFORE_AFTER.trim());
			boolean val = false;
			for (String str : strs) {
				if (str.trim().equalsIgnoreCase(proRoleToAppend)) {
					val = true;
					break;
				}
			}
			if (!val) {
				source = source.concat(addOrStr);
				source = source.concat(proRoleToAppend);
			}
		}
		return source;
	}

	public static Map<String, Object> getAllUrlProperties(String pathUrl, ServletContext servletcontext)
			throws Exception {
		String methodName = "getAllUrlProperties";

		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
				"Get url from propert file as per Authorization Req START");
		Properties properties = null;

		if (null != servletcontext && null != servletcontext.getAttribute(ICommonConstants.APP_URL_PROPS)) {
			properties = (Properties) servletcontext.getAttribute(ICommonConstants.APP_URL_PROPS);
		}

		if (null == properties) {
			properties = new Properties();

			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			InputStream is = classloader.getResourceAsStream(ICommonConstants.APP_URL_PROP_FILE_NAME);

			properties.load(is);
			is.close();
			servletcontext.setAttribute(ICommonConstants.APP_URL_PROPS, properties);
		}

		Map<String, Object> map = new HashMap<>();

		for (String key : properties.stringPropertyNames()) {
			String value = properties.getProperty(key);
			String[] arg = value.split(",");
			if (arg != null && arg.length == 2) {
				map.put(arg[0], arg[1]);
			} else if (arg != null && arg.length == 3) {
				map.put(arg[0], arg[1] + ICommonConstants.ONE_DOLLAR_STRING + arg[2]);
			}
		}

		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.SPRING_FILTER_LOG_KEY,
				"Get url from propert file as per Authorization Req END");
		return map;
	}

	public String setRoleName(Integer roleKey) {
		String roleName = "";
		if (roleKey.equals(ICommonConstants.ADMIN_ROLE_ID)) {
			roleName = ICommonConstants.ADMIN_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.PMO_ROLE_ID)) {
			roleName = ICommonConstants.PMO_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.PM_ROLE_ID)) {
			roleName = ICommonConstants.PM_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.PL_ROLE_ID)) {
			roleName = ICommonConstants.PL_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.TM_ROLE_ID)) {
			roleName = ICommonConstants.TM_ROLE_NAME;
		} else if (roleKey.equals(ICommonConstants.SYFITPM_ROLE_ID)) {
			roleName = ICommonConstants.SYFITPM_ROLE_NAME;
		}
		return roleName;
	}

	public boolean allRoleMenuAccebiltiy() throws Exception {
		String methodName = "allRoleMenuAccebiltiy";
		boolean status = false;
		loadSectionDetailsIntoContext();
		loadRolePermissionDetailsIntoContext();
		Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = CommonUtility.getUserRoleAccebiltiyObj(
				servletcontext.getAttribute(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT),
				servletcontext.getAttribute(ICommonConstants.ALL_SEC_DETAILS_CONTEXT), false);

		Map<Integer, Map<Integer, List<SectionVO>>> allAuthObjs = CommonUtility.getUserRoleAccebiltiyObj(
				servletcontext.getAttribute(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT),
				servletcontext.getAttribute(ICommonConstants.ALL_SEC_DETAILS_CONTEXT), true);

		if (null != allRoleMenuAccebiltiy && !allRoleMenuAccebiltiy.isEmpty() && null != allAuthObjs
				&& !allAuthObjs.isEmpty()) {
			servletcontext.setAttribute(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT, allRoleMenuAccebiltiy);
			servletcontext.setAttribute(ICommonConstants.All_AUTH_OBJS_ACCESS_CONTEXT, allAuthObjs);
			status = true;
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"All role menu accessbility data structure is created and data is added to servlet context");

		return status;
	}

	public void loadSectionDetailsIntoContext() throws Exception {
		String methodName = "loadSectionDetailsIntoContext";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + "In application context",
				"Before calling the loadSectionDetails() from Application context");
		List<SectionDetailDO> loadSectionDetails = onLoadHandler.loadSectionDetails();
		if (null != loadSectionDetails && !loadSectionDetails.isEmpty()) {
			servletcontext.setAttribute(ICommonConstants.ALL_SEC_DETAILS_CONTEXT, loadSectionDetails);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"loadSectionDetails() is called and data is added to servlet context");
	}

	public void loadRolePermissionDetailsIntoContext() throws Exception {
		String methodName = "loadRolePermissionDetailsIntoContext";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"Before calling the loadRolePermissionDetails() from Application context");
		List<RolePermissionDO> loadRolePermissionDetails = onLoadHandler.loadRolePermissionDetails();
		if (null != loadRolePermissionDetails && !loadRolePermissionDetails.isEmpty()) {
			servletcontext.setAttribute(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT, loadRolePermissionDetails);
		}
		LoggerManager.writeInfoLog(CLASS_NAME, methodName,
				ICommonConstants.SPRING_FILTER_LOG_KEY + " Application context",
				"loadRolePermissionDetails() is called and data is added to servlet context");
	}

}