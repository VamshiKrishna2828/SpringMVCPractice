package com.cg.eztrac.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.vo.MenuVO;

public class CommonInterceptor extends HandlerInterceptorAdapter {
	String className = CommonInterceptor.class.getSimpleName();
	/*
	 * @Override public boolean preHandle(HttpServletRequest request,
	 * HttpServletResponse response, Object handler) throws Exception { String
	 * methodName="preHandle";
	 * LoggerManager.writeInfoLog(className,methodName,ICommonConstants.
	 * LOGIN_SERVICE_LOG_KEY+" token generation",
	 * "Before token generation and adding it to the session"); HttpSession session
	 * = request.getSession(); session.setAttribute(ICommonConstants.TOKEN_ID_STR,
	 * CommonUtility.getTokenId());
	 * LoggerManager.writeInfoLog(className,methodName,ICommonConstants.
	 * LOGIN_SERVICE_LOG_KEY+" token generation",
	 * "After token generation and adding it to the session"); return true; }
	 */

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws CustomException {
		HttpSession session = request.getSession();
		UserDO userDO = (UserDO) session.getAttribute(ICommonConstants.USER_DETAILS);
		if (null != userDO && null != modelAndView) {
			MenuVO menuVO = new MenuVO();
			/**
			 * get role_based_menu from userDO and PUT it into menuVO and SEND it to home
			 * page
			 */
			CommonUtility.copyBeanProperties(userDO.getMenuDO(), menuVO);
			modelAndView.getModel().put("menuVO", menuVO);
		} else if (null != userDO && null == modelAndView) {
			MenuVO menuVO = new MenuVO();
			System.out.println(request.getRequestURI());
			System.out.println(request.getRequestURL());
			if (("/per_delete").contains(request.getRequestURI())) {
				modelAndView = new ModelAndView("");
			}else{
				modelAndView = new ModelAndView("per_list");
			}
			/**
			 * get role_based_menu from userDO and PUT it into menuVO and SEND it to home
			 * page
			 */
			CommonUtility.copyBeanProperties(userDO.getMenuDO(), menuVO);
			modelAndView.getModel().put("menuVO", menuVO);
		}
		try {
			super.postHandle(request, response, handler, modelAndView);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new CustomException("", e.getMessage());
		}
	}
}
