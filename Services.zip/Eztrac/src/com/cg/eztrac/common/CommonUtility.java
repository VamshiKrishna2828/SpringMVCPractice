package com.cg.eztrac.common;

import java.io.IOException;
import java.io.InputStream;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.servlet.ServletContext;

import org.dozer.DozerBeanMapper;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.eztrac.domain.InvoiceDO;
import com.cg.eztrac.domain.PMDetailsDO;
import com.cg.eztrac.domain.PMODetailsDO;
import com.cg.eztrac.domain.ResourceDetailsDO;
import com.cg.eztrac.domain.RolePermissionDO;
import com.cg.eztrac.domain.SectionDetailDO;
import com.cg.eztrac.domain.SectionSubSectionDetailsDO;
import com.cg.eztrac.domain.SubSectionDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.domainobject.SystemDetailsDO;
import com.cg.eztrac.vo.PMDetailsVO;
import com.cg.eztrac.vo.PMODetailsVO;
import com.cg.eztrac.vo.ParamVO;
import com.cg.eztrac.vo.ResourceDetailsVO;
import com.cg.eztrac.vo.SectionVO;
import com.cg.eztrac.vo.SubSectionVO;
import com.cg.eztrac.vo.SystemDetailsVO;

public abstract class CommonUtility {
	
	private static final String CLASS_NAME = CommonUtility.class.getSimpleName();
	
	private static ServletContext servletContext;
	
	public static ServletContext getServletContext() {
		return servletContext;
	}
	
	public static void setServletContext(ServletContext servletContext) {
		CommonUtility.servletContext = servletContext;
	}
	
	public static DozerBeanMapper getDozerBeanMapper() {
		DozerBeanMapper dozerBeanMapper;
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		dozerBeanMapper = (DozerBeanMapper) applicationContext.getBean("dozerBeanMapper");
		applicationContext.close();
		return dozerBeanMapper;
	}
	
	public static void copyBeanProperties(Object source, Object target) {
		getDozerBeanMapper().map(source, target);
	}

	final static String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	
	public static String formatMessage(String className, String methodName, String message,
			String additionalLogDetails) {
				StringBuffer sb = new StringBuffer();
				sb.append(ICommonConstants.PIPE_SEPARATOR);
				sb.append("class=");
				sb.append(className);
				sb.append(ICommonConstants.PIPE_SEPARATOR);
				sb.append("Method=");
				sb.append(methodName);
				if (additionalLogDetails != null) {
					sb.append(ICommonConstants.PIPE_SEPARATOR);
					sb.append(additionalLogDetails);
				}
				sb.append(ICommonConstants.PIPE_SEPARATOR);
				sb.append(message);
				return sb.toString();
			}
	
	public static String formatServiceMessage(String serviceURL, String tokenId, String beforeTimeStamp,
			String afterTimeStamp, String status) {
		StringBuffer sb = new StringBuffer();
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" SERVICE: ");
		sb.append(serviceURL);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" - TOKENID: ");
		sb.append(tokenId);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" - TIMESTAMP BEFORE CALLING SERVICE: ");
		sb.append(beforeTimeStamp);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" - TIMESTAMP AFTER CALLING SERVICE: ");
		sb.append(afterTimeStamp);
		sb.append(ICommonConstants.PIPE_SEPARATOR);
		sb.append(" - SERVICE RESPONSE STATUS: ");
		sb.append(status);
		return sb.toString();
	}
	
	
	public static List<Date> formDate(List<InvoiceDO> invoiceDOList) {
		
		InvoiceDO invoiceDO=new InvoiceDO();
		List<String> date = new ArrayList<String>();
		List<Date> dateList = new ArrayList<Date>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(null!=invoiceDOList) {
			for (int i=0;i<invoiceDOList.size();i++){
				invoiceDO=invoiceDOList.get(i);
				date.add(String.valueOf(invoiceDO.getInvoiceYear())+"-"+String.valueOf(invoiceDO.getInvoiceMonth())+"-"+String.valueOf(invoiceDO.getInvoiceDt()));
			}
			for(int i=0;i<date.size();i++)
			{
				System.out.println("###########################################");
				System.out.println(date.get(i));
				try {
					dateList.add(sdf.parse(date.get(i)));
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
				Collections.sort(dateList);
				Collections.reverse(dateList);
				
				// Print out each Date in the list after ordering.
				for(Date dateObj : dateList)
				{
					System.out.println("#####################AFTER SORTING######################");
					System.out.println(sdf.format(dateObj));
				}
		}
		
		return dateList;
	}
	

	
	//Token id generation
	public static String getTokenId() {
		String methodName="getTokenId";
		String className=CommonUtility.class.getSimpleName();
		int len=10;
		StringBuilder sb = new StringBuilder(len);
		SecureRandom rnd = new SecureRandom();
		try {
			rnd = SecureRandom.getInstance("SHA1PRNG");
			for (int i = 0; i < len; i++)
				sb.append(AB.charAt(rnd.nextInt(AB.length())));
		} catch (NoSuchAlgorithmException e) {
			LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while generating the token_id");
			sb =null;
		}
		return sb.toString();
	}
	
	public static Date getDateFromString(String dateString, String dateFormat) {
		try {
			return new SimpleDateFormat(dateFormat).parse(dateString);
		} catch (ParseException e) {
			return null;
		}
	}
	//Converting Date To String
		public static String getStringFromDate(Date date,String format){
			return new SimpleDateFormat(format).format(date);
		}

	@SuppressWarnings("unchecked")
	public static Map<Integer, Map<Integer, List<SectionVO>>> getUserRoleAccebiltiyObj(Object rolePermission,
			Object sectionDetails, boolean isForAllAuthObject) {
		List<RolePermissionDO> contextRolePerDetails = (List<RolePermissionDO>) rolePermission;
		List<SectionDetailDO> contextSectionDetails = (List<SectionDetailDO>) sectionDetails;
		contextRolePerDetails = populateMenuRoleDetailsFromContext(contextRolePerDetails);
		// contextSectionDetails =
		// populateMenuSectionDetailsFromContext(contextSectionDetails);
		String methodName = "getUserMenuAccebiltiy ";
		Map<Integer, Map<Integer, List<SectionVO>>> menuRoleMap = new HashMap<Integer, Map<Integer, List<SectionVO>>>();
		Map<Integer, List<SectionVO>> menuMap = new TreeMap<Integer, List<SectionVO>>();
		Map<Integer, List<Integer>> singleRoleMap = new HashMap<Integer, List<Integer>>();

		try {
			if (isForAllAuthObject) {
				for (RolePermissionDO rolePersmissionDO : contextRolePerDetails) {
					singleRoleMap.clear();
					menuMap = new TreeMap<Integer, List<SectionVO>>();
					if (null != rolePersmissionDO.getSections() && !rolePersmissionDO.getSections().isEmpty()) {
						for (SectionDetailDO sectionDetailDO : rolePersmissionDO.getSections()) {
							List<Integer> roleSubSectionIDs = new ArrayList<Integer>();
							for (SubSectionDO subSectionDO : sectionDetailDO.getSubSection()) {
								roleSubSectionIDs.add(subSectionDO.getSubSectionID());
							}
							Collections.sort(roleSubSectionIDs);
							singleRoleMap.put(sectionDetailDO.getSectionID(), roleSubSectionIDs);
						}
					}
					List<SectionVO> sectionVOs = new ArrayList<SectionVO>();

					for (SectionDetailDO sectionDetailDO : contextSectionDetails) {
						List<Integer> roleSubSectionIds = singleRoleMap.get(sectionDetailDO.getSectionID());
						SectionVO sectionVO = new SectionVO();
						sectionVOs = new ArrayList<SectionVO>();
						sectionVO = new SectionVO();

						sectionVO.setSectionId(sectionDetailDO.getSectionID());
						sectionVO.setSectionName(sectionDetailDO.getSectionName());
						sectionVO.setSectionType(sectionDetailDO.getSectionType());

						List<SubSectionVO> subSectionVOs = new ArrayList<SubSectionVO>();
						for (SubSectionDO subSectionDO : sectionDetailDO.getSubSection()) {
							SubSectionVO subSectionVO = new SubSectionVO();
							if (null != roleSubSectionIds && !rolePersmissionDO.getSections().isEmpty()
									&& roleSubSectionIds.contains(subSectionDO.getSubSectionID())) {
								subSectionVO.setElligbleFlag(false);
							}
							subSectionVO.setSubSectionId(subSectionDO.getSubSectionID());
							subSectionVO.setSubSectionName(subSectionDO.getSubSectionName());
							subSectionVO.setSubSectionType(subSectionDO.getSubSectionType());

							subSectionVOs.add(subSectionVO);
						}
						sectionVO.setSubSectionVO(subSectionVOs);
						sectionVOs.add(sectionVO);
						menuMap.put(sectionVO.getSectionId(), sectionVOs);
						// }
					}
					menuRoleMap.put(rolePersmissionDO.getRoleId(), menuMap);
				}

			} else {

				for (RolePermissionDO rolePersmissionDO : contextRolePerDetails) {
					singleRoleMap.clear();
					menuMap = new TreeMap<Integer, List<SectionVO>>();
					if (null != rolePersmissionDO.getSections() && !rolePersmissionDO.getSections().isEmpty()) {
						for (SectionDetailDO sectionDetailDO : rolePersmissionDO.getSections()) {
							List<Integer> roleSubSectionIDs = new ArrayList<Integer>();
							for (SubSectionDO subSectionDO : sectionDetailDO.getSubSection()) {
								roleSubSectionIDs.add(subSectionDO.getSubSectionID());
							}
							Collections.sort(roleSubSectionIDs);
							singleRoleMap.put(sectionDetailDO.getSectionID(), roleSubSectionIDs);
						}
					}
					List<SectionVO> sectionVOs = new ArrayList<SectionVO>();

					for (SectionDetailDO sectionDetailDO : contextSectionDetails) {
						if ((sectionDetailDO.getSectionType()) != 2) {
							List<Integer> roleSubSectionIds = singleRoleMap.get(sectionDetailDO.getSectionID());
							SectionVO sectionVO = new SectionVO();
							sectionVOs = new ArrayList<SectionVO>();
							sectionVO = new SectionVO();

							sectionVO.setSectionId(sectionDetailDO.getSectionID());
							sectionVO.setSectionName(sectionDetailDO.getSectionName());
							sectionVO.setSectionType(sectionDetailDO.getSectionType());

							/*
							 * System.out.println(
							 * "-----------sectionVO.getSectionId()" +
							 * sectionVO.getSectionId() +
							 * " sectionVO.getSectionName()" +
							 * sectionVO.getSectionName() +
							 * " sectionVO.isElligbleFlag()" +
							 * sectionVO.isElligbleFlag() +
							 * " sectionVO.getSectionType()" +
							 * sectionVO.getSectionType());
							 */
							List<SubSectionVO> subSectionVOs = new ArrayList<SubSectionVO>();
							for (SubSectionDO subSectionDO : sectionDetailDO.getSubSection()) {
								SubSectionVO subSectionVO = new SubSectionVO();
								if (null != roleSubSectionIds && !rolePersmissionDO.getSections().isEmpty()
										&& roleSubSectionIds.contains(subSectionDO.getSubSectionID())) {
									subSectionVO.setElligbleFlag(false);
								}
								subSectionVO.setSubSectionId(subSectionDO.getSubSectionID());
								subSectionVO.setSubSectionName(subSectionDO.getSubSectionName());
								subSectionVO.setSubSectionType(subSectionDO.getSubSectionType());

								/*
								 * System.out.println(
								 * "+++++++++++++++subSectionVO.getSubSectionID()"
								 * + subSectionVO.getSubSectionId() +
								 * " subSectionVO.getSubSectionName()" +
								 * subSectionVO.getSubSectionName() +
								 * " subSectionVO.isElligbleFlag()" +
								 * subSectionVO.isElligbleFlag() +
								 * " subSectionVO.getSubSectionType()" +
								 * subSectionVO.getSubSectionType());
								 */

								subSectionVOs.add(subSectionVO);
							}
							sectionVO.setSubSectionVO(subSectionVOs);
							sectionVOs.add(sectionVO);
							menuMap.put(sectionVO.getSectionId(), sectionVOs);
						}
					}
					menuRoleMap.put(rolePersmissionDO.getRoleId(), menuMap);
				}

			}

		} catch (CustomException e) {
			LoggerManager.writeErrorLog(CLASS_NAME, methodName, e.getMessage(), e,
					"exception while making the map for getUserMenuAccebiltiy");
			menuRoleMap = null;
		}
		return menuRoleMap;
	}
	
	public static String getValFrmAppUrlProp(String key) throws CustomException {
		String result = null;
		String methodName = "getValFrmAppUrlProp";

		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.READ_VAL_FRM_PROP,
				"Get Service URL from Property File START");
		Properties properties = null;
		properties = (Properties) servletContext.getAttribute(ICommonConstants.APP_URL_PROPS);

		if (null == properties && null != servletContext) {
			properties = new Properties();

			ClassLoader classloader = Thread.currentThread().getContextClassLoader();
			InputStream is = classloader.getResourceAsStream(ICommonConstants.APP_URL_PROP_FILE_NAME);

			try {
				properties.load(is);
				is.close();
				servletContext.setAttribute(ICommonConstants.APP_URL_PROPS, properties);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				throw new CustomException("","");
			}
			
		}

		if (null != properties && !properties.getProperty(key).isEmpty()) {
			result = properties.getProperty(key).trim();
		} else {
			throw new CustomException("","Could not find Service URL in Property File");
		}

		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.READ_VAL_FRM_PROP,
				"Get Service URL from Property File END");
		return result;

	}
	
	private static List<RolePermissionDO> populateMenuRoleDetailsFromContext(
			List<RolePermissionDO> rolePermissionDOsSource) {
		List<SectionSubSectionDetailsDO> sectionSubSectionDOs = new ArrayList<SectionSubSectionDetailsDO>();
		SubSectionDO subSectionDO;
		List<SubSectionDO> subSectionDOs;
		List<SectionDetailDO> sectionDetailDOs;
		List<RolePermissionDO> rolePermissionDOsTarget = new ArrayList<RolePermissionDO>();
		RolePermissionDO rolePermissionDO;
		for (RolePermissionDO rolePermission : rolePermissionDOsSource) {
			SectionDetailDO sectionDetailDO = null;
			rolePermissionDO = new RolePermissionDO();
			sectionDetailDOs = new ArrayList<SectionDetailDO>();
			subSectionDOs = new ArrayList<SubSectionDO>();
			sectionSubSectionDOs = rolePermission.getSubSections();
			for (SectionSubSectionDetailsDO sectionSubSectionDO1 : sectionSubSectionDOs) {
				if (sectionSubSectionDO1.getSectionType() != 2) {
					sectionDetailDO = new SectionDetailDO();
					sectionDetailDO.setSectionID(sectionSubSectionDO1.getSectionID());
					sectionDetailDO.setSectionName(sectionSubSectionDO1.getSectionName());
					sectionDetailDO.setSectionType(sectionSubSectionDO1.getSectionType());

					subSectionDOs = new ArrayList<SubSectionDO>();
					for (SectionSubSectionDetailsDO sectionSubSectionDO2 : sectionSubSectionDOs) {
						if (sectionSubSectionDO1.getSectionName().equals(sectionSubSectionDO2.getSectionName())) {
							subSectionDO = new SubSectionDO();
							subSectionDO.setSubSectionID(sectionSubSectionDO2.getSubSectionID());
							subSectionDO.setSubSectionName(sectionSubSectionDO2.getSubSectionName());
							subSectionDO.setSubSectionType(sectionSubSectionDO2.getSubSectionType());
							subSectionDOs.add(subSectionDO);
						}
					}
					sectionDetailDO.setSubSection(subSectionDOs);
					sectionDetailDOs.add(sectionDetailDO);
				}

			}
			
			rolePermissionDO.setChannelId(rolePermission.getChannelId());
			rolePermissionDO.setResponseCode(rolePermission.getResponseCode());
			rolePermissionDO.setResponseDescription(rolePermission.getResponseDescription());
			rolePermissionDO.setRoleDesc(rolePermission.getRoleDesc());
			rolePermissionDO.setRoleId(rolePermission.getRoleId());
			rolePermissionDO.setRoleName(rolePermission.getRoleName());
			rolePermissionDO.setSections(sectionDetailDOs);
			rolePermissionDO.setTokenId(rolePermission.getTokenId());
			rolePermissionDOsTarget.add(rolePermissionDO);
		}
		
		return rolePermissionDOsTarget;
	}
	
	
	
	/*private static List<RolePermissionDO> populateMenuRoleDetailsFromContext(List<RolePermissionDO> rolePermissionDOList){
		List<SectionSubSectionDetailsDO> sectionSubSectionDOList=new ArrayList<SectionSubSectionDetailsDO>();
		List<SubSectionDO> subSectionDOList;
		List<SectionDetailDO> sectionDetailDOList;
		List<RolePermissionDO> rolePermissionDOListNew=new ArrayList<RolePermissionDO>();
		RolePermissionDO rolePermissionDO;
		SectionDetailDO sectionDetailDO;
		SubSectionDO subSectionDO;
		for(RolePermissionDO rolePermission : rolePermissionDOList){
			rolePermissionDO=new RolePermissionDO();
			sectionDetailDOList = new ArrayList<SectionDetailDO>();
			subSectionDOList = new ArrayList<SubSectionDO>();
			int sectionID=0;
			sectionSubSectionDOList=rolePermission.getSubSections();
			for(SectionSubSectionDetailsDO sectionSubSection:sectionSubSectionDOList){
				if(sectionSubSection.getSectionType()!=2){
						sectionDetailDO=new SectionDetailDO();
						subSectionDO = new SubSectionDO();
						if(sectionID==0 || sectionID!=sectionSubSection.getSectionID()){
							subSectionDOList = new ArrayList<SubSectionDO>();
							sectionDetailDO.setSectionID(sectionSubSection.getSectionID());
							sectionDetailDO.setSectionName(sectionSubSection.getSectionName());
							sectionDetailDO.setSectionType(sectionSubSection.getSectionType());
							sectionDetailDOList.add(sectionDetailDO);
							sectionID=sectionSubSection.getSectionID();
						}
						subSectionDO.setSubSectionID(sectionSubSection.getSubSectionID());
						subSectionDO.setSubSectionName(sectionSubSection.getSubSectionName());
						subSectionDO.setSubSectionType(sectionSubSection.getSubSectionType());
						subSectionDOList.add(subSectionDO);
						sectionDetailDO.setSubSection(subSectionDOList);
				}	
			}
			rolePermissionDO.setChannelId(rolePermission.getChannelId());
			rolePermissionDO.setResponseCode(rolePermission.getResponseCode());
			rolePermissionDO.setResponseDescription(rolePermission.getResponseDescription());
			rolePermissionDO.setRoleDesc(rolePermission.getRoleDesc());
			rolePermissionDO.setRoleId(rolePermission.getRoleId());
			rolePermissionDO.setRoleName(rolePermission.getRoleName());
			rolePermissionDO.setSections(sectionDetailDOList);
			rolePermissionDO.setTokenId(rolePermission.getTokenId());
			rolePermissionDOListNew.add(rolePermissionDO);
 		}
		return rolePermissionDOListNew;
	}
	*/
	
	
	// Retrieve Dropdown data from Servlet Context
	public static Map<String, List<ParamVO>> getParamDetailsMap() {
		Map<String, List<ParamVO>> mapOfParamVOList = (Map<String, List<ParamVO>>) servletContext.getAttribute(ICommonConstants.ALL_PARAM_DETAILS_CONTEXT);
		return mapOfParamVOList;
	}
	
	public static List<SystemDetailsVO> getSystemDetailsList(){
		List<SystemDetailsDO> systemDetailsDOList = new ArrayList<SystemDetailsDO>();
		List<SystemDetailsVO> systemDetailsVOList = new ArrayList<SystemDetailsVO>();
		try {
			systemDetailsDOList=(List<SystemDetailsDO>)servletContext.getAttribute(ICommonConstants.SYSTEM_SUBSYSTEM_DETAILS_CONTEXT);
			SystemDetailsVO systemDetailsVO = null;
			for(SystemDetailsDO systemDetailsDO: systemDetailsDOList){
				systemDetailsVO = new SystemDetailsVO();
				CommonUtility.copyBeanProperties(systemDetailsDO, systemDetailsVO);
				systemDetailsVOList.add(systemDetailsVO);
			}
		} catch (CustomException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return systemDetailsVOList;
	}
	
	public static List<SystemDetailsDO> getSystemDetailsDOList(){
		List<SystemDetailsDO> systemDetailsDOList = new ArrayList<SystemDetailsDO>();
		try {
			systemDetailsDOList=(List<SystemDetailsDO>)servletContext.getAttribute(ICommonConstants.SYSTEM_SUBSYSTEM_DETAILS_CONTEXT);
		} catch (CustomException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return systemDetailsDOList;
	}
	
	// Form RoleRestrictionMatrix data
	public static void formRoleRestrictionMatrix(int roleId) {
		final String METHOD_NAME = "formRoleRestrictionMatrix";
		Map<String, String> roleRestrictionMatrixMap = new HashMap<String, String>();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "roleId  --->" + roleId, "");
		List<RolePermissionDO> rolePermissionDOList = (List<RolePermissionDO>) servletContext.getAttribute(ICommonConstants.ALL_ROLE_DETAILS_CONTEXT);
		for(RolePermissionDO rolePermissionDO : rolePermissionDOList) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "roleId  --->" + roleId + "  rolePermissionDO.getRoleId()  --->" + rolePermissionDO.getRoleId(), "");
			if(roleId == rolePermissionDO.getRoleId()) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "roleId  --->" + roleId + "  rolePermissionDO.getRoleId()  --->" + rolePermissionDO.getRoleId() + " ROLE MATCHING --> FETCH ROLE NAME --> " + rolePermissionDO.getRoleName(), "");
				for(SectionSubSectionDetailsDO sectionSubSectionDetailsDO : rolePermissionDO.getSubSections()) {
					LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "  sectionSubSectionDetailsDO.getSectionID()   --->" + sectionSubSectionDetailsDO.getSectionID() + "" + " sectionSubSectionDetailsDO.getSectionName()   --->" + sectionSubSectionDetailsDO.getSectionName() + " sectionSubSectionDetailsDO.getSubSectionID()  --->" + sectionSubSectionDetailsDO.getSubSectionID() + " FETCH SUB-SECTION NAME --> " + sectionSubSectionDetailsDO.getSubSectionName(), "");
					// Form RoleMatrix for All Sections
					String sectionName = sectionSubSectionDetailsDO.getSectionName();
					String delimiter = ICommonConstants.RESTRICTION_PATTERN_DELIMITER;
					String subSectionName = sectionSubSectionDetailsDO.getSubSectionName();
					roleRestrictionMatrixMap.put(sectionName + delimiter + subSectionName, ICommonConstants.STRING_TRUE);
				}
			}
		}
		servletContext.setAttribute(ICommonConstants.ALL_ROLE_RESTRICTION_MATRIX_CONTEXT, roleRestrictionMatrixMap);
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "roleRestrictionMatrixMap --->" + roleRestrictionMatrixMap, "");
	}
	
	// Retrieve RoleRestrictionMatrix data from Servlet Context
	public static Map<String, String> getRoleRestrictionMatrixMap() {
		Map<String, String> roleRestrictionMatrixMap = (Map<String, String>) servletContext.getAttribute(ICommonConstants.ALL_ROLE_RESTRICTION_MATRIX_CONTEXT);
		return roleRestrictionMatrixMap;
	}

	public static List<PMODetailsVO> getPMODetailsList() {
		List<PMODetailsDO> pmoDetailsDOList = new ArrayList<PMODetailsDO>();
		List<PMODetailsVO> pmoDetailsVOList = new ArrayList<PMODetailsVO>();
		try {
			pmoDetailsDOList=(List<PMODetailsDO>)servletContext.getAttribute(ICommonConstants.PMO_DETAILS_CONTEXT);
			PMODetailsVO pmoDetailsVO = null;
			for(PMODetailsDO pmoDetailsDO: pmoDetailsDOList){
				pmoDetailsVO = new PMODetailsVO();
				CommonUtility.copyBeanProperties(pmoDetailsDO, pmoDetailsVO);
				pmoDetailsVOList.add(pmoDetailsVO);
			}
		} catch (CustomException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pmoDetailsVOList;
	}

	public static List<PMDetailsVO> getPMDetailsList() {
		List<PMDetailsDO> pmDetailsDOList = new ArrayList<PMDetailsDO>();
		List<PMDetailsVO> pmDetailsVOList = new ArrayList<PMDetailsVO>();
		try {
			pmDetailsDOList=(List<PMDetailsDO>)servletContext.getAttribute(ICommonConstants.PM_DETAILS_CONTEXT);
			PMDetailsVO pmDetailsVO = null;
			for(PMDetailsDO pmDetailsDO: pmDetailsDOList){
				pmDetailsVO = new PMDetailsVO();
				CommonUtility.copyBeanProperties(pmDetailsDO, pmDetailsVO);
				pmDetailsVOList.add(pmDetailsVO);
			}
		} catch (CustomException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pmDetailsVOList;
	}

	public static List<ResourceDetailsVO> getResourceDetailsList() {
		List<ResourceDetailsDO> resourceDetailsDOList = new ArrayList<ResourceDetailsDO>();
		List<ResourceDetailsVO> resourceDetailsVOList = new ArrayList<ResourceDetailsVO>();
		try {
			resourceDetailsDOList=(List<ResourceDetailsDO>)servletContext.getAttribute(ICommonConstants.ALL_RESOURCE_DETAILS_CONTEXT);
			ResourceDetailsVO resourceDetailsVO = null;
			for(ResourceDetailsDO resourceDetailsDO: resourceDetailsDOList){
				resourceDetailsVO = new ResourceDetailsVO();
				CommonUtility.copyBeanProperties(resourceDetailsDO, resourceDetailsVO);
				resourceDetailsVOList.add(resourceDetailsVO);
			}
		} catch (CustomException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resourceDetailsVOList;
	}

	

	
	
}
