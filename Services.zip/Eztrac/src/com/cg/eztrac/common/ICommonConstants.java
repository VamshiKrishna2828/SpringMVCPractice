package com.cg.eztrac.common;

public interface ICommonConstants {

	public static final String STRING_TRUE = "true";
	public static final String STRING_FALSE = "false";
	public static final String APP_URL_PROP_FILE_NAME = "appurlcontroller.properties";
	public static final String APP_URL_PROPS = "APP_URL_PROPS";
	
	//TODO - It is supposed to be coming as 2 for sectionType
	public static final String STRING_TWO = "2.0";
	
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String DATE_FORMAT_MM_DD_YY = "MM/dd/yy";
	
	public static final String PIPE_SEPARATOR = "|";
	
	public static final String loginService = "loginWS_URL";
	public static final String USERDETAILS = "UserDetails";
	public static final String LOGIN = "login";
	public static final String ROLEPERMISSION = "RolePermission";
	public static final String ALL_SUB_SEC_DETAILS_STR = "AllSubSectionDetails";
	public static final String ALL_SEC_DETAILS_STR = "allSectionDetails";
	public static final String ALL_PARAM_DETAILS_CONTEXT = "ALL_PARAM_DETAILS_SERVICE";
	public static final String ALL_SEC_DETAILS_CONTEXT = "ALL_SEC_DETAILS_SERVICE";
	public static final String ALL_ROLE_DETAILS_CONTEXT = "ALL_ROLE_DETAILS_SERVICE";
	public static final String ALL_ROLE_RESTRICTION_MATRIX_CONTEXT = "ALL_ROLE_RESTRICTION_MATRIX";
	public static final String All_ROLE_MENU_ACCESS_CONTEXT = "All_ROLE_MENU_ACCESSIBILITY";
	public static final String All_AUTH_OBJS_ACCESS_CONTEXT = "All_AUTH_OBJS_ACCESSIBILITY";
	public static final String USER_DETAILS="USER_DETAILS";
	public static final String INVOICELIST="INVOICE_LIST";
	public static final String USER_ROLEID="USER_ROLEID";
	public static final String CURRENT_ROLE="CURRENT_ROLE";
	
	
	public static final String DISABLE_STR = "DISABLE";
	public static final String ENABLE_STR = "ENABLE";
	
	public static final String App = " - LOGINFLOW - ";
	public static final String sec = " - LOGINFLOW - ";
	public static final String role = " - LOGINFLOW - ";
	
	public static final String LOGIN_SERVICE_LOG_KEY = " - LOGINFLOW - ";
	public static final String BUILD_SERVICE_LOG_KEY = "BUILDFLOW";
	public static final String PER_SERVICE_LOG_KEY = "PERFLOW";
	public static final String SPRING_FILTER_LOG_KEY = " - AUTHFILTER FLOW -  ";
	public static final String READ_VAL_FRM_PROP = " - READ PROP FLOW -  ";
	public static final String AUTHORITIES_OBJS = "AUTHORITIES_OBJECT";
	public static final String APPLICATION_CONTEXT = " - APPLICATIONCONTEXT - ";
	public static final String SECTION_DETAILS_SERVICES_FLOW = " - SECTION_DETAILS_SERVICES - ";
	public static final String ROLE_PERMISSION_SERVICES_FLOW = " - ROLE_PERMISSION_SERVICES - ";
	public static final String BINDING_RESULT_KEY = 	"BindingResult";
	
	public static final String MODULE_PER = "Per";
	public static final String SUB_MODULE_NEW = "New";
	public static final String SUB_MODULE_EDIT = "Edit";
	public static final String SUB_MODULE_CC_EDIT = "CCEdit";
	public static final String MODULE_BUILD = "Build";
	public static final String RESTRICTION_PATTERN_DELIMITER = "~";
	public static final String PER_NEW_RESTRICTION_PATTERN = MODULE_PER + PIPE_SEPARATOR + SUB_MODULE_NEW + RESTRICTION_PATTERN_DELIMITER;
	public static final String PER_EDIT_RESTRICTION_PATTERN = MODULE_PER + PIPE_SEPARATOR + SUB_MODULE_EDIT + RESTRICTION_PATTERN_DELIMITER;
	public static final String PER_CCEDIT_RESTRICTION_PATTERN = MODULE_PER + PIPE_SEPARATOR + SUB_MODULE_CC_EDIT + RESTRICTION_PATTERN_DELIMITER;
	public static final String BUILD_NEW_RESTRICTION_PATTERN = MODULE_BUILD + PIPE_SEPARATOR + SUB_MODULE_NEW + RESTRICTION_PATTERN_DELIMITER;
	public static final String BUILD_EDIT_RESTRICTION_PATTERN = MODULE_BUILD + PIPE_SEPARATOR + SUB_MODULE_EDIT + RESTRICTION_PATTERN_DELIMITER;
	public static final String BUILD_CCEDIT_RESTRICTION_PATTERN = MODULE_BUILD + PIPE_SEPARATOR + SUB_MODULE_CC_EDIT + RESTRICTION_PATTERN_DELIMITER;
	
	public static final String TOKEN_ID_STR = "TOKEN_ID";
	public static final String PERMISSIABLE_ROLEID_SESSION = "ROLEPERMISSION_USER_ROLES";
	public static final int SUB_ACCOUN_ID = 1;
	public static final String SERVICE_UNAVAIL_ERROR_DESC = "SYSTEM DOWN. PLEASE TRY AFTER SOMETIME";
	public static final String SERVICE_UNAVAIL_ERROR_CD = "111";
	
	public static final String DROPDOWN_CURRENT_PHASE = "SDLC_PHASE";
	public static final String DROPDOWN_PROJECT_TYPE = "PROJECT_TYPE";
	public static final String DROPDOWN_HEALTH_OF_PROJECT = "PROJECT_HEALTH";
	public static final String DROPDOWN_LOCATION_CD = "LOCATION";
	public static final String DROPDOWN_SUB_SECTION_TYPE = "SUB_SECTION_TYPE";
	public static final String DROPDOWN_SECTION_TYPE = "SECTION_TYPE";
	public static final String DROPDOWN_CC_CATEGORY_ID = "CHANGE_CONTROL_CATEGORY";
	public static final String DROPDOWN_CC_CURRENT_PHASE = "CHANGE_CONTROL_STATUS";
	public static final String DROPDOWN_STAKEHOLDER_TYPE_ID = "STAKEHOLDER_TYPE";
	public static final String DROPDOWN_TASK = "TASK";
	public static final String BUILD_DETAILS = "BuildDODetails";
	public static final String BUILD_LIST = "buildListDO";
	public static final String PER_LIST = "perListDO";
	

	public static final String INSERT_REQUEST_ACTION = "INSERTACTION";
	public static final String DETAILS_REQUEST_ACTION = "DETAILSACTION";
	public static final String LIST_REQUEST_ACTION = "LISTACTION";
	public static final String DELETE_REQUEST_ACTION = "DELETEACTION";
	public static final String PER_CC_INSERT_REQUEST_ACTION = "PERCCINSERTACTION";
	
	
	public static final String TS_AUTOCOMPLETE_LENGTH = "TIMESHEET_AUTOCOMPLETE_TRIGGERLENGTH";
	public static final String TS_AUTOCOMPLETE_ENABLE_FLAG = "TIMESHEET_AUTOCOMPLETE_TRIGGER_FLAG";
	
	public static final Integer ADMIN_ROLE_ID = 1;
	public static final Integer PMO_ROLE_ID = 2;
	public static final Integer PM_ROLE_ID = 3;
	public static final Integer PL_ROLE_ID = 4;
	public static final Integer TM_ROLE_ID = 5;
	public static final Integer SYFITPM_ROLE_ID = 6;
	
	public static final String EMPTY_URL_STRING = "";
	
	
	public static final String SPRING_HAS_ROLE_START = "hasRole('";
	public static final String SPRING_HAS_ROLE_END = "')";
	
	public static final String ADMIN_ROLE_NAME = "ADMIN";
	public static final String PMO_ROLE_NAME = "PMO";
	public static final String PM_ROLE_NAME = "PM";
	public static final String PL_ROLE_NAME = "PL";
	public static final String TM_ROLE_NAME = "TM";
	public static final String SYFITPM_ROLE_NAME = "SYFITPM";

	public static final String SUCCESS_LOGIN_RESPONSE_CODE = "100";
	public static final String OR_STRING_WITH_SPACE_BEFORE_AFTER = " or ";
	public static final String ROLE_UNDER_STRING = "ROLE_";
	public static final String ADMIN_STRING = "ADMIN";
	public static final String PMO_STRING = "PMO";
	public static final String PM_STRING = "PM";
	public static final String PL_STRING = "PL";
	public static final String TM_STRING = "TM";
	public static final String SYFITPM_STRING = "SYFITPM";
	public static final String Y_STRING = "Y";
	public static final String N_STRING = "N";
	
	public static final String SYSTEM_SUBSYSTEM_DETAILS_CONTEXT = "SYSTEM_SUBSYSTEM_DETAILS";
	public static final String PMO_DETAILS_CONTEXT = "PMO_DETAILS";
	public static final String PM_DETAILS_CONTEXT = "PM_DETAILS";
	public static final String ALL_RESOURCE_DETAILS_CONTEXT = "ALL_RESOURCE_DETAILS";
	public static final String SYSTEM_SERVICE_LOG_KEY = " - SYSTEM_SERVICE_FLOW - ";
	public static final String PMO_DETAILS_SERVICE_LOG_KEY = " - PMO_DETAILS_SERVICE_FLOW - ";
	public static final String PM_DETAILS_SERVICE_LOG_KEY = " - PM_DETAILS_SERVICE_FLOW - ";
	public static final String ALL_RESOURCE_DETAILS_SERVICE_LOG_KEY = " - ALL_RESOURCE_DETAILS_SERVICE_FLOW - ";
	public static final String SYSTEM_SERVICE = "systemWS_url";
	public static final String TIME_SHEET_SERVICE = "systemWS_url";
	public static final String TIMESHEET_TYPE_SAVE = "S";
	public static final String TIMESHEET_TYPE_SUBMIT = "A";
	public static final String INVALID_PASSWORD_CODE="SL1001";
	public static final String INVALID_USERNAME_CODE="SL1001";
	public static final String LOGIN_SUCCESS_CODE="SL1000";
	public static final String ONE_DOLLAR_STRING = "$";
	public static final String SYSTEM_DETAILS = "SYSTEM_DETAILS";
	public static final String TIMESHEET_SUBMIT_STATUS = "A";
	public static final String LATESTINVOICEDATE = "LATEST_INVOICE_DATE";
	public static final String INVOICEDATESLIST = "INVOICE_DATE_LIST";
	public static final String LATESTINVOICEDATEINDATEFORMATE = "LATEST_INVOICE_DATE_IN_DATE_FORMATE";
	public static final String INVOICEDATELIST = "INVOICEDATELIST";
	public static final String EXCEEDING_24_HRS = "Please enter hours not more than 24 hours";
	
	//Exception handling codes
	public static final String REASON_PHRASE = "Reason-Phrase";
	public static final String HTTPSTATUS_200 = "200";
	public static final String HTTPSTATUS_204 = "204";
	public static final String HTTPSTATUS_400 = "400";
	public static final String HTTPSTATUS_404 = "404";
	public static final String HTTPSTATUS_405 = "405";
	public static final String HTTPSTATUS_409 = "409";
	public static final String HTTPSTATUS_500 = "500";
	public static final String HTTPSTATUS_502 = "502";
	public static final String HTTPSTATUS_503 = "503";
	
	//Per Service Status Codes
	public static final String SERVICESTATUS_SP1000 = "SP1000";
	public static final String SERVICESTATUS_SP1001 = "SP1001";
	public static final String SERVICESTATUS_SP1002 = "SP1002";
	public static final String SERVICESTATUS_WP1001 = "WP1001";
	public static final String SERVICESTATUS_WP1002 = "WP1002";
	public static final String SERVICESTATUS_WP1003 = "WP1003";
	public static final String SERVICESTATUS_WP1004 = "WP1004";
	public static final String SERVICESTATUS_FP1000 = "FP1000";
	public static final String SERVICESTATUS_FP1001 = "FP1001";
	
	//Build Service Status Codes
	public static final String SERVICESTATUS_SB1000 = "SB1000";
	public static final String SERVICESTATUS_SB1001 = "SB1001";
	public static final String SERVICESTATUS_SB1002 = "SB1002";
	public static final String SERVICESTATUS_WB1001 = "WB1001";
	public static final String SERVICESTATUS_WB1002 = "WB1002";
	public static final String SERVICESTATUS_WB1003 = "WB1003";
	public static final String SERVICESTATUS_FB1000 = "FB1000";
	public static final String SERVICESTATUS_FB1001 = "FB1001";
	
	//Login Service Status Codes
	public static final String SERVICESTATUS_FL1000 = "FL1000";
	public static final String SERVICESTATUS_FL1001 = "FL1001";
	public static final String SERVICESTATUS_SL1000 = "SL1000";
	public static final String SERVICESTATUS_SL1001 = "SL1001";
	
	//CommonServices Status Codes
	public static final String SERVICESTATUS_FC1000 = "FC1000";
	public static final String SERVICESTATUS_FC1001 = "FC1001";
	public static final String SERVICESTATUS_WC1001 = "WC1001";
	public static final String SERVICESTATUS_SC1000 = "SC1000";
	public static final String SERVICESTATUS_SC1002 = "SC1002";
	
	//Timesheet Status Codes
	public static final String SERVICESTATUS_FT1000 = "FT1000";
	public static final String SERVICESTATUS_FT1001 = "FT1001";
	public static final String SERVICESTATUS_WT1001 = "WT1001";
	public static final String SERVICESTATUS_ST1000 = "ST1000";
	public static final String SERVICESTATUS_ST1001 = "ST1001";
	
	public static final String NO_RECORDS_FOUND = "No Records Found for the provided search criteria";
	public static final String INSERT_SUCCESS = "The Record is succesfully Inserted / Updated";
	public static final String INSERT_PARTIAL_SUCCESS = "Record is inserted succesfully, but could not fetch the response";
	public static final String DELETE_SUCCESS = "The Record is successfully Deleted";
	public static final String PER_DELETE_FAILURE = "Cannot delete PER as Timesheets are entered for corresponding build! Please delete the Timesheets and try again!";
	public static final String BUILD_DELETE_FAILURE = "Cannot delete BUILD as Timesheets are entered for it!! Please delete the Timesheets and try again!";
	public static final String COMMON_SERVICES_DATA_ERROR = "No Data from the common services";
	
	
}
