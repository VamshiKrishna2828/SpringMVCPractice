package com.cg.eztrac.encryption;

import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class AESEncryption {
	
    
    private static final String ALGO = "AES";
    private static final byte[] keyValue = new byte[] { 'E', 'Z', 'T', 'R', 'A', 'C', 'T','e', 's', 't','1','2', '3', '4', '5', '6' };
//    private static final byte[] keyValue = new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };

public static String encrypt(String Data) throws CustomException {
        Key key;
        String encryptedValue;
		try {
			key = generateKey();
			 Cipher c = Cipher.getInstance(ALGO);
		     c.init(Cipher.ENCRYPT_MODE, key);
		     byte[] encVal = c.doFinal(Data.getBytes());
		     encryptedValue = new BASE64Encoder().encode(encVal);
		     
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new CustomException("", "");
		}
		return encryptedValue;
        
    }

    public static String decrypt(String encryptedData) throws CustomException {
        Key key;
        String decryptedValue;
		try {
			key = generateKey();
			Cipher c = Cipher.getInstance(ALGO);
	        c.init(Cipher.DECRYPT_MODE, key);
	        byte[] decordedValue = new BASE64Decoder().decodeBuffer(encryptedData);
	        byte[] decValue = c.doFinal(decordedValue);
	        decryptedValue = new String(decValue);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new CustomException("", "");
		}
        
        return decryptedValue;
    }
    
    private static Key generateKey() throws Exception {
        Key key = new SecretKeySpec(keyValue, ALGO);
        return key;
}
	public static void main(String[] args) {
		String className=AESEncryption.class.getSimpleName();
		String methodName="main";
		try {
			System.out.println(encrypt("psiddhu"));
		} catch (CustomException e) {
			LoggerManager.writeErrorLog(className, methodName, e.getMessage(),e , " Exception while encripting the password");
			e.printStackTrace();
		}
	}
}

