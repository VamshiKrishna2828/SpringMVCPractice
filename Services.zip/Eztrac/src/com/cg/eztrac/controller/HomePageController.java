package com.cg.eztrac.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.domain.RoleDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.handler.HomePageHandler;
import com.cg.eztrac.vo.InvoiceVO;
import com.cg.eztrac.vo.MenuVO;

@Controller
public class HomePageController {
	@Autowired HttpSession httpSession;
	@Autowired private ServletContextImpl servletContextImpl;
	@RequestMapping(value = {"/switchRole" }, method = RequestMethod.POST)
	public ModelAndView buildRoleBasedHome(ModelAndView mv,@ModelAttribute MenuVO menuVO, Model model) {
		HomePageHandler homePageHandler = new HomePageHandler();
		InvoiceVO invoiceVO = homePageHandler.switchRoleMenuHandler(httpSession, menuVO, servletContextImpl);
		// During switch role, formRoleRestrictionMatrix for the new role
		httpSession.setAttribute(ICommonConstants.USER_ROLEID, menuVO.getRoleId());
		UserDO userDO = (UserDO)httpSession.getAttribute(ICommonConstants.USER_DETAILS);
		List<RoleDO> roleDOList = userDO.getRoles();
		for(RoleDO currentRoleDO:roleDOList){
			if(currentRoleDO.getRoleId()==menuVO.getRoleId()){
				userDO.setCurrentRoleDO(currentRoleDO);
			}
		}
		httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
		CommonUtility.formRoleRestrictionMatrix(menuVO.getRoleId());
		System.out.println(menuVO.getRoleId());
		mv = new ModelAndView("home");
		model.addAttribute(invoiceVO);
		return mv;
	}
	
}
