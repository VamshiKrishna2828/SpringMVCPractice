package com.cg.eztrac.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.handler.TimeSheetHandler;
import com.cg.eztrac.service.impl.TimeSheetServiceImpl;
import com.cg.eztrac.validator.DateCalculation;
import com.cg.eztrac.validator.DateRange;
import com.cg.eztrac.vo.SubSystemVO;
import com.cg.eztrac.vo.SystemDetailsVO;
import com.cg.eztrac.vo.TimeSheetVO;

@Controller
@PropertySource("classpath:appurlcontroller.properties")
public class TimesheetController {

	private static final String CLASS_NAME = "TimesheetController";
	
	@Autowired
	HttpSession session;

	@Autowired
	TimeSheetHandler timeSheetHandler;
	
	/*@Autowired
	DateRange dateRange;*/

	@Autowired
	TimeSheetServiceImpl timeSheetService;

	/*@Autowired
	DateCalculation dateCalculation;*/
	
	/*@Autowired*/
	SystemDetailsVO systemDetailsVO;
	
	TimeSheetVO timeSheetVO;
	
	public TimesheetController() {
	}

	private List<SystemDetailsVO> systemList;
	private List<String> projectList;

	@RequestMapping(value = "${eztrack.postlogin.timesheet.url}", method = RequestMethod.POST)
	public ModelAndView timesheetGet(@ModelAttribute("timeSheetVO") TimeSheetVO timeSheetVO, ModelMap model) {
		final String METHOD_NAME = "timesheetGet";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered TimesheetController", "Start");
		
		ModelAndView mav = null;
		timeSheetVO = new TimeSheetVO();
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching SystemList", "");
			systemList = timeSheetVO.getSystemDetailsDropdown();
			timeSheetVO.setSystemList(systemList);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Current Week Date Range", "");
			DateRange dateRange = new DateRange();
			timeSheetVO.setCurrentWeek(dateRange.getCurrentDate());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Timeperiod List", "");
			DateCalculation dateCalculation = new DateCalculation();
			timeSheetVO.setTimePeriodList(dateCalculation.generateDateList());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting userDetails", "");
			timeSheetVO.setResourceName(((UserDO) session.getAttribute(ICommonConstants.USER_DETAILS)).getUsername());
			
		} 
		catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "Timesheet StartUp Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from TimesheetController", "End");
		mav = new ModelAndView("timesheet", "timeSheetVO", timeSheetVO);
		return mav;
	}

	@RequestMapping(value = "${eztrack.postlogin.timesheet.subSystem.url}", method=RequestMethod.POST)
	public @ResponseBody List<SubSystemVO> getSubsystemList(@RequestBody int systemIdString) {
		final String METHOD_NAME="getSubsystemList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered Timesheet - getSubsystemList Controller Method", "getSubsystemList - Start");
		
		TimeSheetVO timeSheetVO = new TimeSheetVO();
		List<SubSystemVO> subSystemList = new ArrayList<>();
		try {
			for (SystemDetailsVO systemDetailsVO : timeSheetVO.getSystemDetailsDropdown()) {
				if (systemDetailsVO.getSystemID() == systemIdString) {
					return systemDetailsVO.getSubsystemDetails();
				}
			}
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Could not fetch the subsystem details", e, "");
			throw new CustomException("","Error occured during Subsystem Fetching");
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning the SubsystemList", "getSubsystemList - End");
		return subSystemList;
	}
	
	@RequestMapping(value =  "${eztrack.postlogin.timesheet.ajaxGetTimeSheetList.url}", method=RequestMethod.POST)
    public @ResponseBody TimeSheetVO getTimeSheetList(@RequestBody TimeSheetVO timesheetVOAjax,ModelMap model) {
		final String METHOD_NAME="getTimeSheetList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered getTimeSheetList Controller method", "getTimeSheetList - Start");
		
		TimeSheetVO timeSheetVO = new TimeSheetVO();
		try {
			
			System.out.println("StartDate ---> "+timesheetVOAjax.getStartDate());
			System.out.println("EndDate ---> "+timesheetVOAjax.getEndDate());
			System.out.println("SystemId ---> "+timesheetVOAjax.getSystemId());
			System.out.println("SubSystemId ---> "+timesheetVOAjax.getSubSystemId());
			System.out.println("PerNumber ---> "+timesheetVOAjax.getPerNumber());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetHandler.getTimeSheetList()", "");
			timeSheetVO = timeSheetHandler.getTimeSheetList(session,timesheetVOAjax);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetHandler.getTimeSheetList()", "");
			
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "getTimeSheetList response exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from getTimeSheetList Controller method", "getTimeSheetList - End");
		return timeSheetVO;
	}
	
	@RequestMapping(value =  "${eztrack.postlogin.timesheet.ajaxGetPerList.url}", method=RequestMethod.POST)
    public @ResponseBody ArrayList<String>  getPerListForAutoComplete(@RequestBody TimeSheetVO timesheetVOAjax,ModelMap model) {
		final String METHOD_NAME="getPerListForAutoComplete";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered getPerListForAutoComplete Controller method", "getPerListForAutoComplete - Start");
		
		ArrayList<String> perList = new ArrayList<String>();
		try {
			
			System.out.println("Autocomplete - PerNumber ---> "+timesheetVOAjax.getProjectName());
			System.out.println("Autocomplete - SystemId ---> "+timesheetVOAjax.getSystemId());
			System.out.println("Autocomplete - SubSystemId ---> "+timesheetVOAjax.getSubSystemId());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetHandler.getPerList()", "");
			perList.addAll(timeSheetHandler.getPerList(session,timesheetVOAjax));
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetHandler.getPerList()", "");
			
			model.addAttribute("projectList", perList);
			
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Could not fetch the Perlist", e, "");
			throw new CustomException("","Error occured during Perlist Fetching");
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning perlist", "getPerListForAutoComplete - End");
		return perList;
	}
	
	@RequestMapping(value = { "${eztrack.postlogin.timesheet.save.url}" }, method = RequestMethod.POST)
	public ModelAndView saveTimeSheet(@ModelAttribute("timeSheetVO") TimeSheetVO timeSheetVO, BindingResult result, ModelMap model) {
		final String METHOD_NAME="getPerListForAutoComplete";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered saveTimeSheet Controller method", "saveTimeSheet - Start");
		
		ModelAndView mav = null;
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting the Timesheet status to save", "");
			timeSheetVO.setInsertType(ICommonConstants.TIMESHEET_TYPE_SAVE);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetHandler.getTimeSheetList()", "");
			timeSheetVO = timeSheetHandler.insertTimeSheet(timeSheetVO,session);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetHandler.getTimeSheetList()", "");
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching SystemList", "");
			systemList = timeSheetVO.getSystemDetailsDropdown();
			timeSheetVO.setSystemList(systemList);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Timeperiod List", "");
			DateCalculation dateCalculation = new DateCalculation();
			timeSheetVO.setTimePeriodList(dateCalculation.generateDateList());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting userDetails", "");
			timeSheetVO.setResourceName(((UserDO) session.getAttribute(ICommonConstants.USER_DETAILS)).getUsername());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting the Model and View object", "");
			mav = new ModelAndView("timesheet", "timeSheetVO", timeSheetVO);
			
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "saveTimeSheet response exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from saveTimeSheet Controller method", "saveTimeSheet - End");
		return mav;
	}

	@RequestMapping(value = { "${eztrack.postlogin.timesheet.submit.url}" }, method = RequestMethod.POST)
	public ModelAndView submitTimeSheet(@ModelAttribute("timeSheetVO") TimeSheetVO timeSheetVO,BindingResult result, ModelMap model) {
		final String METHOD_NAME="getPerListForAutoComplete";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered saveTimeSheet Controller method", "saveTimeSheet - Start");
		
		ModelAndView mav = null;
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting the Timesheet status to Submit", "");
			timeSheetVO.setInsertType(ICommonConstants.TIMESHEET_TYPE_SUBMIT);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetHandler.getTimeSheetList()", "");
			timeSheetVO = timeSheetHandler.insertTimeSheet(timeSheetVO,session);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetHandler.getTimeSheetList()", "");
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Forming Timeperiod List", "");
			DateCalculation dateCalculation = new DateCalculation();
			timeSheetVO.setTimePeriodList(dateCalculation.generateDateList());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Fetching SystemList", "");
			systemList = timeSheetVO.getSystemDetailsDropdown();
			timeSheetVO.setSystemList(systemList);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting userDetails", "");
			timeSheetVO.setResourceName(((UserDO) session.getAttribute(ICommonConstants.USER_DETAILS)).getUsername());
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting the Model and View object", "");
			mav = new ModelAndView("timesheet", "timeSheetVO", timeSheetVO);
			
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "saveTimeSheet response exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning from saveTimeSheet Controller method", "saveTimeSheet - End");
		return mav;
	}
	
	@RequestMapping(value = { "${eztrack.postlogin.timesheet.delete.url}" }, method = RequestMethod.POST)
	public @ResponseBody TimeSheetVO deleteTimeSheet(@RequestBody List<Integer> timeSheetIdList) {
		final String METHOD_NAME="deleteTimeSheet";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered deleteTimeSheet Controller method", "deleteTimeSheet - Start");
		
		System.out.println("TimeSheet Delete List ------");
		for (Integer integer : timeSheetIdList) {
			System.out.println(integer);
		}
		timeSheetVO=new TimeSheetVO();
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Setting the timesheetId's to be deleted to timesheetVO", "");
			timeSheetVO.setTimeSheetIdList(timeSheetIdList);
			
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before calling timeSheetHandler.deleteTimeSheet()", "");
			timeSheetHandler.deleteTimeSheet(timeSheetVO, session);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from timeSheetHandler.deleteTimeSheet()", "");
			
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME,METHOD_NAME, "Timesheet Delete Exception", e, "Redirecting to custom exception");
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning deleteTimeSheet Status", "deleteTimeSheet - End");
		return timeSheetVO;
	}

	public List<String> getProjectList() {
		return projectList;
	}

	public void setProjectList(List<String> projectList) {
		this.projectList = projectList;
	}

	public List<SystemDetailsVO> getSystemList() {
		return systemList;
	}

	public void setSystemList(List<SystemDetailsVO> systemList) {
		this.systemList = systemList;
	}

	public SystemDetailsVO getSystemDetailsVO() {
		return systemDetailsVO;
	}

	public void setSystemDetailsVO(SystemDetailsVO systemDetailsVO) {
		this.systemDetailsVO = systemDetailsVO;
	}
	
	public TimeSheetVO getTimeSheetVO() {
		return timeSheetVO;
	}

	public void setTimeSheetVO(TimeSheetVO timeSheetVO) {
		this.timeSheetVO = timeSheetVO;
	}

}