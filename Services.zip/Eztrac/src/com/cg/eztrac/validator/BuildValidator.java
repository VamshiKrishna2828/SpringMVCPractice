package com.cg.eztrac.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cg.eztrac.util.EztracValidationUtil;
import com.cg.eztrac.vo.BuildVO;

@Component(value="buildValidator")
public class BuildValidator implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		return false;
	}

	@Override
	public void validate(Object build, Errors errors) {
		
		BuildVO buildVO = (BuildVO) build;
		
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "perId", "error.build.perNumber.required");
		/*if(null == buildVO.getPerId()) {
			EztracValidationUtil.rejectValue(errors, "perId", "PERID cannot be empty");
		}*/
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "systemId", "error.build.system.required");
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "subSystemId", "error.build.subSystem.required");
		EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "currentBuildPhase", "error.build.currentBuildPhase.required");
		if(buildVO.getBuildLoe().getExecutionLOEReq()!=null) {
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoe.executionLOEReq","error.build.loe.value" , buildVO.getBuildLoe().getExecutionLOEReq(), 0, 500);
		}
		if(buildVO.getBuildLoe().getExecutionLOEDesign()!=null) {
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoe.executionLOEDesign","error.build.loe.value" , buildVO.getBuildLoe().getExecutionLOEDesign(), 0, 500);
		}
		if(buildVO.getBuildLoe().getExecutionLOECons()!=null) {
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoe.executionLOECons","error.build.loe.value" , buildVO.getBuildLoe().getExecutionLOECons(), 0, 500);
		}
		if(buildVO.getBuildLoe().getExecutionLOETest()!=null) {
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoe.executionLOETest","error.build.loe.value" , buildVO.getBuildLoe().getExecutionLOETest(), 0, 500);
		}
		if(buildVO.getBuildLoe().getExecutionLOETest()!=null) {
			EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildLoe.executionLOERelease","error.build.loe.value" , buildVO.getBuildLoe().getExecutionLOETest(), 0, 500);
		}
		//EztracValidationUtil.rejectIfEmptyOrWhitespace(errors, "buildChangeControlVO.ccNumber", "error.build.ccNumber.required");
		//EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCReqLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCReqLoe(), 0, 500);
		//EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCDesignLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCDesignLoe(), 0, 500);
		//EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCConLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCConLoe(), 0, 500);
		//EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCTestingLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCTestingLoe(), 0, 500);
		//EztracValidationUtil.rejectIfMinMaxLengthMismatch(errors, "buildChangeControlVO.buildCCReleaseLoe","error.build.loe.value" , buildVO.getBuildChangeControlVO().getBuildCCReleaseLoe(), 0, 500);

	}
}

