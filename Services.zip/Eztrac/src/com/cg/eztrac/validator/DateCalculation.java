package com.cg.eztrac.validator;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.LoggerManager;

@Component(value = "dateCalculation")
public class DateCalculation {

	private static final String CLASS_NAME = "TimesheetController";
	
	Map<Integer, String> dateMap = new LinkedHashMap<Integer, String>();
	int k = 0;
	DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
	List<String> dateList = new ArrayList<String>();
	
	public List<String> generateDateList() {
		
		final String METHOD_NAME = "generateDateList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Entered generateDateList() to calculate the timePeriodList", "Start");
		
		int[] month = { -1, 0, 1, 2 };

		for (int j = 0; j < 4; j++) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH, month[j]);//
			int maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

			for (int i = 1; i <= maxDay; i++) {
				k++;
				cal.set(Calendar.DAY_OF_MONTH, i);

				if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
					if (i == 1) {
						dateMap.put(k, sdf.format(cal.getTime()) + "-");
					}
					k++;
					dateMap.put(k, sdf.format(cal.getTime()) + "#");
				}

				if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
					dateMap.put(k, sdf.format(cal.getTime()) + "-");
					if (i == maxDay) {
						k++;
						dateMap.put(k, sdf.format(cal.getTime()));
					}
				}

				if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.TUESDAY) {
					if (i == 1) {
						dateMap.put(k, sdf.format(cal.getTime()) + "-");
					}

					if (i == maxDay) {
						dateMap.put(k, sdf.format(cal.getTime()) + "#");
					}
				}

				if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.WEDNESDAY) {
					if (i == 1) {
						dateMap.put(k, sdf.format(cal.getTime()) + "-");
					}

					if (i == maxDay) {
						dateMap.put(k, sdf.format(cal.getTime()) + "#");
					}
				}

				if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.THURSDAY) {
					if (i == 1) {
						dateMap.put(k, sdf.format(cal.getTime()) + "-");
					}

					if (i == maxDay) {
						dateMap.put(k, sdf.format(cal.getTime()) + "#");
					}
				}

				if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {
					if (i == 1) {
						dateMap.put(k, sdf.format(cal.getTime()) + "-");
					}
					if (i == maxDay) {
						dateMap.put(k, sdf.format(cal.getTime()) + "#");
					}
				}

				if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
					if (i == 1) {
						dateMap.put(k, sdf.format(cal.getTime()) + "-");
					}
					if (i == maxDay) {
						dateMap.put(k, sdf.format(cal.getTime()) + "#");
					}
				}
			}
		}
		String dateRange = "";
		Set<Entry<Integer, String>> entires = dateMap.entrySet();
		int i = 1;
		for (Entry<Integer, String> ent : entires) {
			i++;
			dateRange = dateRange + ent.getValue();
			if ((i % 2) != 0) {
				dateRange = dateRange.replaceAll("#", "");
				dateList.add(dateRange);
				dateRange = "";
			}

		}
		
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Returning timePeriodList from generateDateList() ", "End");
		return dateList;
	}

	public static void main(String[] args) {

		DateCalculation dateCalculation = new DateCalculation();
		dateCalculation.generateDateList();
	}
}