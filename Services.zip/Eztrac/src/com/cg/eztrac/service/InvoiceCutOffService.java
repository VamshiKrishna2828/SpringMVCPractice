package com.cg.eztrac.service;

import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.request.InvoiceCutOffRequest;
import com.cg.eztrac.service.response.InvoiceCutOffResponse;

public interface InvoiceCutOffService {
	
	public InvoiceCutOffResponse  invoiceService(InvoiceCutOffRequest invoiceCutOffRequest)  throws CustomException;
}
