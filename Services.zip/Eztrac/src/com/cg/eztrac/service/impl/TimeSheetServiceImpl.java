package com.cg.eztrac.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.IServiceMandates;
import com.cg.eztrac.service.domainobject.TimeSheetDO;
import com.cg.eztrac.service.request.DeleteTimeSheetRequest;
import com.cg.eztrac.service.request.DeleteTimeSheetRequest.TimeSheetDelete;
import com.cg.eztrac.service.request.InsertTimeSheetRequest;
import com.cg.eztrac.service.request.TimeSheetRequest;
import com.cg.eztrac.service.response.DeleteTimeSheetResponse;
import com.cg.eztrac.service.response.InsertTimeSheetResponse;
import com.cg.eztrac.service.response.TimeSheetResponse;

@Component(value = "timeSheetService")
public class TimeSheetServiceImpl implements IServiceMandates {

	private static final String CLASS_NAME = "TimeSheetServiceImpl";

	@Override
	public Object serviceProcessor(Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "serviceProcessor";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Timesheet serviceProcessor method", "");
		
		Object responseObject =null;
		try {
			if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside TimeSheetServiceImpl.serviceProcessor:","Timesheet GetList");
				TimeSheetDO timeSheetDO = (TimeSheetDO)doObject;
				TimeSheetRequest timeSheetListRequest = (TimeSheetRequest) populateRequest(timeSheetDO,action);
				TimeSheetResponse timeSheetListResponse = (TimeSheetResponse) invokeService(timeSheetListRequest,action);
				responseObject = populateResponse(timeSheetListResponse, timeSheetDO,action);
			}
			else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside TimeSheetServiceImpl.serviceProcessor:","Timesheet Insertion");
				InsertTimeSheetRequest insertTimeSheetRequest = (InsertTimeSheetRequest) doObject;
				InsertTimeSheetResponse insertTimeSheetResponse = (InsertTimeSheetResponse) invokeService(insertTimeSheetRequest,action);
				TimeSheetDO timeSheetDO =new TimeSheetDO();
				responseObject = populateResponse(insertTimeSheetResponse, timeSheetDO,action);
			}
			else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside TimeSheetServiceImpl.serviceProcessor:","Timesheet Delete");
				TimeSheetDO timeSheetDO = (TimeSheetDO)doObject;
				DeleteTimeSheetRequest deleteTimeSheetRequest = (DeleteTimeSheetRequest) populateRequest(timeSheetDO,action);
				DeleteTimeSheetResponse deleteTimeSheetResponse = (DeleteTimeSheetResponse) invokeService(deleteTimeSheetRequest,action);
				responseObject = populateResponse(deleteTimeSheetResponse, timeSheetDO,action);
			}
			else{
				throw new CustomException("400", "Invalid Request");
			}
		}
		catch (CustomException e) {
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		return responseObject;
	}

	@Override
	public Object populateRequest(Object requestObject, String action) throws CustomException {
		final String METHOD_NAME = "populateRequest";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Timesheet populateRequest method", "");
		
		if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateTimeSheetListRequest","TimeSheetList");
			TimeSheetDO timeSheetDO = (TimeSheetDO)requestObject;
			TimeSheetRequest timeSheetListRequest = new TimeSheetRequest();
			
			timeSheetListRequest.setUserId(timeSheetDO.getUserId());
			timeSheetListRequest.setSystemId(timeSheetDO.getSystemId());
			timeSheetListRequest.setSybSytemId(timeSheetDO.getSubSystemId());
			timeSheetListRequest.setStartDate(timeSheetDO.getStartDate());
			timeSheetListRequest.setEndDate(timeSheetDO.getEndDate());
			timeSheetListRequest.setPerNumber(timeSheetDO.getPerNumber());
			timeSheetListRequest.setTokenId(timeSheetDO.getTokenId());
			timeSheetListRequest.setChannelId("TestChannel");
			
			return timeSheetListRequest;
		}
		/*else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateTimeSheetInsertRequest","Timesheet Insertion");
			TimeSheetDO timeSheetDO = (TimeSheetDO)requestObject;
			InsertTimeSheetRequest insertTimeSheetRequest = new InsertTimeSheetRequest();
		}*/
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateTimeSheetDeleteRequest","Timesheet Delete");
			TimeSheetDO timeSheetDO = (TimeSheetDO)requestObject;
			DeleteTimeSheetRequest deleteTimeSheetRequest = new DeleteTimeSheetRequest();
			
			List<TimeSheetDelete> timeSheetDeleteList = new ArrayList<TimeSheetDelete>();
			for(int timeSheetId : timeSheetDO.getTimeSheetIdList()){
				TimeSheetDelete timeSheetDelete = new TimeSheetDelete();
				timeSheetDelete.setTimeSheetId(timeSheetId);
				timeSheetDeleteList.add(timeSheetDelete);
			}
			deleteTimeSheetRequest.setTsDelete(timeSheetDeleteList);
			deleteTimeSheetRequest.setTokenId(timeSheetDO.getTokenId());
			deleteTimeSheetRequest.setChannelId("EZ");
			
			return deleteTimeSheetRequest;
		}
		else{
			throw new CustomException("400", "Invalid Request");
		}
	}

	@Override
	public Object invokeService(Object requestObject, String action) throws CustomException {
		final String METHOD_NAME = "invokeService";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Timesheet invoke service method", "");
		
		if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			TimeSheetRequest timeSheetListRequest = (TimeSheetRequest) requestObject;
			TimeSheetResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,"Timesheet Get", "Before calling rest service invocation");
				response = (TimeSheetResponse) EztracRestClient.invokeRestService(timeSheetListRequest,CommonUtility.getValFrmAppUrlProp("ez.service.getTimesheet.url"), TimeSheetResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,"Timesheet Get", "After rest service invocation");
			} catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FT1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FT1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			InsertTimeSheetRequest insertTimeSheetRequest = (InsertTimeSheetRequest) requestObject;
			InsertTimeSheetResponse insertTimeSheetResponse = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,"Timesheet Insertion", "Before calling rest service invocation");
				insertTimeSheetResponse = (InsertTimeSheetResponse) EztracRestClient.invokeRestService(insertTimeSheetRequest, "http://localhost:8095/insertTimeSheetDetails", InsertTimeSheetResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,"Timesheet Insertion", "After rest service invocation");
			} catch (CustomException e) {
				if(null!=insertTimeSheetResponse) {
					if(insertTimeSheetResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FT1000) || insertTimeSheetResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FT1001)) {
						throw new CustomException(insertTimeSheetResponse.getResponseCode(),insertTimeSheetResponse.getResponseDescription());
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return insertTimeSheetResponse;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			DeleteTimeSheetRequest deleteTimeSheetRequest = (DeleteTimeSheetRequest) requestObject;
			DeleteTimeSheetResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,"Timesheet Delete", "Before calling rest service invocation");
				response = (DeleteTimeSheetResponse) EztracRestClient.invokeRestService(deleteTimeSheetRequest, CommonUtility.getValFrmAppUrlProp("ez.service.deleteTimeSheetDetails.url"), DeleteTimeSheetResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME,"Timesheet Delete", "After rest service invocation");
			} catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FT1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FT1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else {
			throw new CustomException("400", "Invalid Request");
		}
	}

	@Override
	public Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "populateResponse";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Timesheet populateResponse method", "");
		
		if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateTimeSheetListResponse","Timesheet Get");
			TimeSheetResponse timeSheetListResponse= (TimeSheetResponse) responseObject;
			TimeSheetDO timeSheetDO = (TimeSheetDO)doObject;
			if(null!=timeSheetListResponse) {
				String listResponseCode = timeSheetListResponse.getResponseCode();
				if(listResponseCode.equals(ICommonConstants.SERVICESTATUS_ST1000) && null!=timeSheetListResponse.getTimeSheetList()) {
					timeSheetDO.setTimeSheetList(timeSheetListResponse.getTimeSheetList());
				}
				else if (listResponseCode.equals(ICommonConstants.SERVICESTATUS_ST1001)) {
					Map<String, String> responseCodeMap=new HashMap<String, String>();
					responseCodeMap.put(listResponseCode, ICommonConstants.NO_RECORDS_FOUND);
					timeSheetDO.setResponseMap(responseCodeMap);
				}
			}
			timeSheetDO.setTokenId(timeSheetListResponse.getTokenId());
			return timeSheetDO;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateTimeSheetInsertResponse","Timesheet Delete");
			InsertTimeSheetResponse insertTimeSheetResponse= (InsertTimeSheetResponse) responseObject;
			TimeSheetDO timeSheetDO = (TimeSheetDO)doObject;
			String insertResponseCode = insertTimeSheetResponse.getResponseCode();
			if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_ST1000)) {
				Map<String, String> responseCodeMap=new HashMap<String, String>();
				responseCodeMap.put(insertResponseCode, ICommonConstants.INSERT_SUCCESS);
				timeSheetDO.setResponseMap(responseCodeMap);
			}
			timeSheetDO.setTokenId(insertTimeSheetResponse.getTokenId());
			return timeSheetDO;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateTimeSheetDeleteResponse","Timesheet Delete");
			DeleteTimeSheetResponse deleteTimeSheetResponse= (DeleteTimeSheetResponse) responseObject;
			TimeSheetDO timeSheetDO = (TimeSheetDO)doObject;
			String deleteResponseCode = deleteTimeSheetResponse.getResponseCode();
			if(deleteResponseCode.equals(ICommonConstants.SERVICESTATUS_ST1000)) {
				Map<String, String> responseCodeMap=new HashMap<String, String>();
				responseCodeMap.put(deleteResponseCode, ICommonConstants.DELETE_SUCCESS);
				timeSheetDO.setResponseMap(responseCodeMap);
			}
			timeSheetDO.setTokenId(deleteTimeSheetResponse.getTokenId());
			return timeSheetDO;
		}
		else {
			throw new CustomException("400", "Invalid Request");
		}
		
	}

}
