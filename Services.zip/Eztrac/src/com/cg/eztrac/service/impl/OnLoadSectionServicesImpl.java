package com.cg.eztrac.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.SectionDetailDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.IServiceMandates;
import com.cg.eztrac.service.request.SectionDetailRequest;
import com.cg.eztrac.service.response.SectionDetail;
import com.cg.eztrac.service.response.SectionsRes;
import com.google.gson.Gson;

@Service
public class OnLoadSectionServicesImpl  implements IServiceMandates {
	String className =OnLoadSectionServicesImpl.class.getName();
	
	
	@Override
	public Object serviceProcessor(Object doObject, String action) throws CustomException {
		List<SectionDetailDO> sectionDetails =null;
		SectionDetailDO sectionDetailDO = (SectionDetailDO)doObject;
		SectionDetailRequest sectionDetailRequest = (SectionDetailRequest) populateRequest(sectionDetailDO,null);
		SectionsRes sectionDetailsResponse = (SectionsRes)invokeService(sectionDetailRequest,null);
		List<SectionDetail> sectionDetailResponseList = sectionDetailsResponse.getSectionDetails();
		sectionDetails = (List<SectionDetailDO>) populateResponse(sectionDetailResponseList, sectionDetails,null);
		return sectionDetails;
		
	}

	@Override
	public Object populateRequest(Object requestObject, String action) throws CustomException {
	
		String methodName="populateRequest";
		SectionDetailRequest sectionDetailRequest = new SectionDetailRequest();
	/*	sectionDetailRequest.setSubAccountId(sectionDetailDO.getSubAccounId());*/
		sectionDetailRequest.setSubAccountId(1);
		sectionDetailRequest.setTokenId(CommonUtility.getTokenId());
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In sectionDetailDO", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+"Setting SectionDetail Request from SectionDetailDO");
		return sectionDetailRequest;
	}

	@Override
	public Object invokeService(Object requestObject, String action) throws CustomException {
		String methodName="invokeService";
		SectionDetailRequest sectionDetailRequest = (SectionDetailRequest) requestObject;
		SectionsRes sectionDetailsResponse = null;
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "Before calling rest service invocation");
		try {
			sectionDetailsResponse = (SectionsRes) EztracRestClient.invokeRestService(sectionDetailRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getAllSectionDetails.url"), SectionsRes.class.getName());
		}catch (CustomException e) {
			// TODO: handle exception
			throw new CustomException("", "");
		}
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "After rest service invocation");
		return sectionDetailsResponse;
	}

	@Override
	public Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException {
		List<SectionDetail> sectionDetailResponseList = (List<SectionDetail>)responseObject;
		List<SectionDetailDO> sectionDetails = (List<SectionDetailDO>) doObject ;
		String methodName="populateResponse";
		sectionDetails = new ArrayList<SectionDetailDO>(sectionDetailResponseList.size());
		try {
			SectionDetailDO sectionDetailDO = null;
			Gson gson = new Gson();
			for (int i=0;i<sectionDetailResponseList.size();i++){
				sectionDetailDO = new SectionDetailDO();
				String sectionDetailDOJson = gson.toJson( sectionDetailResponseList.get(i));
				sectionDetailDO = gson.fromJson(sectionDetailDOJson, SectionDetailDO.class);
				sectionDetails.add(sectionDetailDO);
			}
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In sectionDetailDO", ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+"Setting SectionDetailDo from SectoinDetailResponse");
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while populating the sectionDetailResponse to SectionDetailDO");
		}
		return sectionDetails;
	}

}
