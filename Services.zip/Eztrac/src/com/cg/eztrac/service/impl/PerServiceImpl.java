package com.cg.eztrac.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.domain.PerListDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.IServiceMandates;
import com.cg.eztrac.service.request.PerDeleteRequest;
import com.cg.eztrac.service.request.PerDeleteResponse;
import com.cg.eztrac.service.request.PerDetailsRequest;
import com.cg.eztrac.service.request.PerInsertRequest;
import com.cg.eztrac.service.request.PerListRequest;
import com.cg.eztrac.service.response.PerDetailsResponse;
import com.cg.eztrac.service.response.PerInsertResponse;
import com.cg.eztrac.service.response.PerListResponse;

@Component(value="perServiceImpl")
public class PerServiceImpl implements IServiceMandates {
	
	private static final String CLASS_NAME = PerServiceImpl.class.getSimpleName();
	
	@Override
	public Object serviceProcessor(Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "serviceProcessor";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Per serviceProcessor method", "");
		
		Object responseObject =null;
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerServiceImpl.serviceProcessor:","Per Details");
			PerDO perDO = (PerDO)doObject;
			PerDetailsRequest perDetailsRequest = (PerDetailsRequest) populateRequest(perDO,action);
			PerDetailsResponse perDetailsResponse = (PerDetailsResponse) invokeService(perDetailsRequest,action);
			responseObject = populateResponse(perDetailsResponse, perDO,action);
		}
		else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerServiceImpl.serviceProcessor:","Per List");
			PerListDO perListDO = (PerListDO)doObject;
			PerListRequest perListRequest = (PerListRequest) populateRequest(perListDO, action);
			PerListResponse perListResponse = (PerListResponse) invokeService(perListRequest,action);
			responseObject = populateResponse(perListResponse, perListDO,action);
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerServiceImpl.serviceProcessor:","Per Insert");
			PerDO perDO = (PerDO)doObject;
			PerInsertRequest perInsertRequest = (PerInsertRequest) populateRequest(perDO, action);
			PerInsertResponse perInsertResponse = (PerInsertResponse) invokeService(perInsertRequest,action);
			responseObject = populateResponse(perInsertResponse, perDO,action);
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerServiceImpl.serviceProcessor:","Per Delete");
			PerDO perDO = (PerDO)doObject;
			PerDeleteRequest perDeleteRequest = (PerDeleteRequest) populateRequest(perDO,action);
			PerDeleteResponse perDeleteResponse = (PerDeleteResponse) invokeService(perDeleteRequest,action);
			responseObject = populateResponse(perDeleteResponse, perDO,action);
		}
		return responseObject;
	}

	@Override
	public Object populateRequest(Object requestObject, String action) throws CustomException {
		final String METHOD_NAME = "populateRequest";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Per populateRequest method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerDetailRequest","Per Details");
			PerDO perDO = (PerDO)requestObject;
			PerDetailsRequest perDetailsRequest = new PerDetailsRequest();
			perDetailsRequest.setPerId(perDO.getPerId());
			perDetailsRequest.setTokenId(perDO.getTokenId());
			perDetailsRequest.setChannelId("CN");
			return perDetailsRequest;
		}
		else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerListRequest","Per List");
			PerListDO perListDO = (PerListDO)requestObject;
			PerListRequest perListRequest = new PerListRequest();
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying perListDO.getPer() to perListRequest","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(perListDO.getPer(), perListRequest);
			perListRequest.setTokenId(perListDO.getTokenId());
			perListRequest.setChannel("EZ");
			perListRequest.setSubAccountId(1);
			return perListRequest;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerInsertRequest","Per Insert");
			PerDO perDO = (PerDO)requestObject;
			PerInsertRequest perInsertRequest = new PerInsertRequest();
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying perDO to perInsertRequest","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(perDO, perInsertRequest);
			perInsertRequest.setChannelId("EZ");
			perInsertRequest.setSubAccountId(1);
			return perInsertRequest;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerDeleteRequest","Per Delete");
			PerDO perDO = (PerDO)requestObject;
			PerDeleteRequest perDeleteRequest = new PerDeleteRequest();
			perDeleteRequest.setPerId(perDO.getPerId());
			perDeleteRequest.setTokenId(perDO.getTokenId());
			perDeleteRequest.setChannelId("CN");
			return perDeleteRequest;
		}
		else{
			throw new CustomException("400", "Invalid Request");
		}
		
	}

	@Override
	public Object invokeService(Object requestObject, String action) throws CustomException {
		final String METHOD_NAME = "invokeService";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Per invoke service method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			PerDetailsRequest perDetailsRequest = (PerDetailsRequest) requestObject;
			PerDetailsResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.PER_SERVICE_LOG_KEY+"Per Details", "Before calling rest service invocation");
				response = (PerDetailsResponse) EztracRestClient.invokeRestService(perDetailsRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getPerDetail.url"), PerDetailsResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.PER_SERVICE_LOG_KEY+"Per Details", "After rest service invocation");
			} catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FP1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FP1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			PerListRequest perListRequest = (PerListRequest) requestObject;
			PerListResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.PER_SERVICE_LOG_KEY+"Per List", "Before calling rest service invocation");
				response = (PerListResponse) EztracRestClient.invokeRestService(perListRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getPerDetailsList.url"), PerListResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.PER_SERVICE_LOG_KEY+"Per List", "After rest service invocation");
			} catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FP1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FP1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			
			return response;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			PerInsertRequest perInsertRequest = (PerInsertRequest) requestObject;
			PerInsertResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.PER_SERVICE_LOG_KEY+"Per Insert", "Before rest service invocation");
				response = (PerInsertResponse) EztracRestClient.invokeRestService(perInsertRequest, CommonUtility.getValFrmAppUrlProp("ez.service.insertPerDetails.url"), PerInsertResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.PER_SERVICE_LOG_KEY+"Per Insert", "After rest service invocation");
			} catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FP1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FP1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WP1001) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WP1002)
							|| response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WP1004))
					{
						return response;
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			
			return response;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			PerDeleteRequest perDeleteRequest = (PerDeleteRequest) requestObject;
			PerDeleteResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.PER_SERVICE_LOG_KEY+"Per Delete", "Before calling rest service invocation");
				response = (PerDeleteResponse) EztracRestClient.invokeRestService(perDeleteRequest, CommonUtility.getValFrmAppUrlProp("ez.service.deletePerDetails.url"), PerDeleteResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.PER_SERVICE_LOG_KEY+"Per Delete", "After rest service invocation");
			} catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FP1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FP1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WP1003)) 
					{
						return response;
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else {
			throw new CustomException("400", "Invalid Request");
		}
	}

	@Override
	public Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "populateResponse";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Per populateResponse method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerDetailsRespoonse","Per Details");
			PerDetailsResponse perDetailsResponse= (PerDetailsResponse) responseObject;
			PerDO perDO = (PerDO)doObject;
			perDO = perDetailsResponse.getPer();
			perDO.setTokenId(perDetailsResponse.getTokenId());
			return perDO;
		}
		else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerDeleteResponse","Per List");
			PerListResponse perListResponse= (PerListResponse) responseObject;
			PerListDO perListDO = (PerListDO)doObject;
			if(perListResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_SP1000) && null!=perListResponse.getPerDetail()) {
				perListDO.setPerList(perListResponse.getPerDetail());
			}
			if(perListResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_SP1001)) {
				Map<String, String> responseCodeMap=new HashMap<String, String>();
				responseCodeMap.put(perListResponse.getResponseCode(), ICommonConstants.NO_RECORDS_FOUND);
				perListDO.setResponseMap(responseCodeMap);
			}
			return perListDO;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerInsertRespoonse","Per Insert");
			PerInsertResponse perInsertResponse= (PerInsertResponse) responseObject;
			PerDO perDO = (PerDO)doObject;
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			String insertResponseCode = perInsertResponse.getResponseCode();
			if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_SP1000)) {
				perDO = new PerDO();
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying perInsertResponse to perDO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(perInsertResponse, perDO);
				responseCodeMap.put(insertResponseCode, ICommonConstants.INSERT_SUCCESS);
			}
			else if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_SP1002)) {
				perDO = new PerDO();
				responseCodeMap.put(insertResponseCode, ICommonConstants.INSERT_PARTIAL_SUCCESS);
			}
			else if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_WP1001) ||  insertResponseCode.equals(ICommonConstants.SERVICESTATUS_WP1002) || 
					insertResponseCode.equals(ICommonConstants.SERVICESTATUS_WP1004)) 
			{
				responseCodeMap.put(insertResponseCode,perInsertResponse.getResponseDescription());
			}
			perDO.setResponseMap(responseCodeMap);
			return perDO;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerDeleteRespoonse","Per Delete");
			PerDeleteResponse perDeleteResponse= (PerDeleteResponse) responseObject;
			PerDO perDO = (PerDO)doObject;
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			String deleteResponseCode = perDeleteResponse.getResponseCode();
			
			if(deleteResponseCode.equals(ICommonConstants.SERVICESTATUS_SP1000)) {
				perDO = new PerDO();
				responseCodeMap.put(deleteResponseCode, ICommonConstants.DELETE_SUCCESS);
			}
			else if(deleteResponseCode.equals(ICommonConstants.SERVICESTATUS_WP1003)) {
				responseCodeMap.put(deleteResponseCode, ICommonConstants.PER_DELETE_FAILURE);
			}
			
			perDO.setResponseMap(responseCodeMap);
			perDO.setTokenId(perDeleteResponse.getTokenId());
			return perDO;
		}
		else {
			throw new CustomException("400", "Invalid Request");
		}
	}
	
	/*@Override
	public Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "populateResponse";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Per populateResponse method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerDetailsRespoonse","Per Details");
			PerDetailsResponse perDetailsResponse= (PerDetailsResponse) responseObject;
			PerDO perDO = (PerDO)doObject;
			perDO = perDetailsResponse.getPer();
			perDO.setTokenId(perDetailsResponse.getTokenId());
			return perDO;
		}
		else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerDeleteRespoonse","Per List");
			PerListResponse perListResponse= (PerListResponse) responseObject;
			PerListDO perListDO = (PerListDO)doObject;
			if(null!=perListResponse.getPerDetail()) {
				perListDO.setPerList(perListResponse.getPerDetail());
			}
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			responseCodeMap.put(perListResponse.getResponseCode(), perListResponse.getResponseDescription());
			perListDO.setResponseMap(responseCodeMap);
			return perListDO;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerDeleteRespoonse","Per Insert");
			PerInsertResponse perInsertResponse= (PerInsertResponse) responseObject;
			PerDO perDO = (PerDO)doObject;
			if(null!=perInsertResponse) {
				perDO = new PerDO();
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying perInsertResponse to perDO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(perInsertResponse, perDO);
			}
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			responseCodeMap.put(perInsertResponse.getResponseCode(), perInsertResponse.getResponseDescription());
			perDO.setResponseMap(responseCodeMap);
			return perDO;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populatePerDeleteRespoonse","Per Delete");
			PerDeleteResponse perDeleteResponse= (PerDeleteResponse) responseObject;
			if(null!=responseObject) {
				Map<String, String> responseCodeMap=new HashMap<String, String>();
				responseCodeMap.put(perDeleteResponse.getResponseCode(), perDeleteResponse.getResponseDescription());
				if(perDeleteResponse.getResponseCode().equals("200")) {
					PerDO newPerDO = new PerDO();
					newPerDO.setResponseMap(responseCodeMap);
					newPerDO.setTokenId(perDeleteResponse.getTokenId());
					return newPerDO;
				}
				else {
					PerDO perDO = (PerDO)doObject;
					perDO.setResponseMap(responseCodeMap);
					perDO.setTokenId(perDeleteResponse.getTokenId());
					return perDO;
				}
			}
			else {
				return null;
			}
		}
		else {
			throw new CustomException("", "Invalid Request");
		}
	}*/
	
}
