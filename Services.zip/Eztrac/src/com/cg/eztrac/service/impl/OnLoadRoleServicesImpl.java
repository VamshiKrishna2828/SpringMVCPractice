package com.cg.eztrac.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.RolePermissionDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.IServiceMandates;
import com.cg.eztrac.service.request.RolePermissionRequest;
import com.cg.eztrac.service.response.RolePermissionDetails;
import com.cg.eztrac.service.response.RolePermissionRes;
import com.google.gson.Gson;

@Service
public class OnLoadRoleServicesImpl implements  IServiceMandates {
	String className=OnLoadRoleServicesImpl.class.getSimpleName();
	
	@Override
	public Object serviceProcessor(Object doObject, String action) throws CustomException {
		List<RolePermissionDO> roleResponseDOList =null;
		RolePermissionRequest rolePermissionRequest = (RolePermissionRequest) populateRequest(null,null);
		RolePermissionRes rolePermission = (RolePermissionRes)invokeService(rolePermissionRequest,null);
		List<RolePermissionDetails> rolePermissionList = rolePermission.getRolePerm();
		 roleResponseDOList = (List<RolePermissionDO>) populateResponse(rolePermissionList, roleResponseDOList,null);
		return roleResponseDOList;
	}

	@Override
	public Object populateRequest(Object requestObject, String action) throws CustomException {
		String methodName="populateRoleRequestFromDO";
		RolePermissionRequest rolePermissionRequest = new RolePermissionRequest();
		rolePermissionRequest.setSubAccountId(ICommonConstants.SUB_ACCOUN_ID);
		rolePermissionRequest.setTokenId(CommonUtility.getTokenId());
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In RolePermissionDO",ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+ " RolePermissionRequest populated from DO");
		return rolePermissionRequest;
	}

	@Override
	public Object invokeService(Object requestObject, String action) throws CustomException {
		String methodName="invokeService";
		RolePermissionRequest rolePermissionRequest =(RolePermissionRequest) requestObject;
		RolePermissionRes roleDetailsResponse = null;
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "Before calling rest service invocation");
		try {
			roleDetailsResponse = (RolePermissionRes) EztracRestClient.invokeRestService(rolePermissionRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getAllRolePermission.url"), RolePermissionRes.class.getName());
		}catch (CustomException e) {
			// TODO: handle exception
			throw new CustomException("", "");
		}
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "After rest service invocation");
		return roleDetailsResponse;
	}

	@Override
	public Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException {
		List<RolePermissionDetails> rolePermissionResponseList =  (List<RolePermissionDetails>)responseObject;
		List<RolePermissionDO> rolePermissionDOList = (List<RolePermissionDO>) doObject ;
		String methodName="populateResponse";
		 rolePermissionDOList = new ArrayList<RolePermissionDO>(rolePermissionResponseList.size());
		RolePermissionDO rolePermissionDO = new RolePermissionDO();
		Gson gson = new Gson();
		//** Since response from Rest Service is in "gson" form  *//*
		//** so converting "gson" to "object" *//*
		for (int i=0;i<rolePermissionResponseList.size();i++){
			rolePermissionDO = new RolePermissionDO();
			String rolePermissionJson = gson.toJson( rolePermissionResponseList.get(i));
			rolePermissionDO = gson.fromJson(rolePermissionJson, RolePermissionDO.class);
			rolePermissionDOList.add(rolePermissionDO);
		}
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.APPLICATION_CONTEXT+"In RolePermissionDO",ICommonConstants.ROLE_PERMISSION_SERVICES_FLOW+ "RolePermissionResponse populated to DO");
		return rolePermissionDOList;
	}
	
	

}
