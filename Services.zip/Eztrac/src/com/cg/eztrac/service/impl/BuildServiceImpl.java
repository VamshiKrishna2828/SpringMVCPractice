package com.cg.eztrac.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.BuildDO;
import com.cg.eztrac.domain.BuildListDO;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.IServiceMandates;
import com.cg.eztrac.service.request.BuildDeleteRequest;
import com.cg.eztrac.service.request.BuildDeleteResponse;
import com.cg.eztrac.service.request.BuildDetailsRequest;
import com.cg.eztrac.service.request.BuildInsertRequest;
import com.cg.eztrac.service.request.BuildListRequest;
import com.cg.eztrac.service.response.BuildDetailsResponse;
import com.cg.eztrac.service.response.BuildInsertResponse;
import com.cg.eztrac.service.response.BuildListResponse;

@Component(value="buildServiceImpl")
public class BuildServiceImpl implements IServiceMandates {
	
	private static final String CLASS_NAME = BuildServiceImpl.class.getName();

	@Override
	public Object serviceProcessor(Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "serviceProcessor";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build serviceProcessor method", "");
		
		Object responseObject =null;
		try {
			if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build Details");
				BuildDO buildDO = (BuildDO)doObject;
				BuildDetailsRequest buildDetailsRequest = (BuildDetailsRequest) populateRequest(buildDO,action);
				BuildDetailsResponse buildDetailsResponse = (BuildDetailsResponse) invokeService(buildDetailsRequest,action);
				responseObject = populateResponse(buildDetailsResponse, buildDO,action);
			}
			else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)){
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build List");
				BuildListDO buildListDO = (BuildListDO)doObject;
				BuildListRequest buildListRequest = (BuildListRequest) populateRequest(buildListDO, action);
				BuildListResponse buildListResponse = (BuildListResponse) invokeService(buildListRequest,action);
				responseObject = populateResponse(buildListResponse, buildListDO,action);
			}
			else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)){
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build Insert");
				BuildDO buildDO = (BuildDO)doObject;
				BuildInsertRequest buildInsertRequest = (BuildInsertRequest) populateRequest(buildDO, action);
				BuildInsertResponse buildInsertResponse = (BuildInsertResponse) invokeService(buildInsertRequest,action);
				responseObject = populateResponse(buildInsertResponse, buildDO,action);
			}
			else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)){
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside BuildServiceImpl.serviceProcessor:","Build Delete");
				BuildDO buildDO = (BuildDO)doObject;
				BuildDeleteRequest buildDeleteRequest = (BuildDeleteRequest) populateRequest(buildDO, action);
				BuildDeleteResponse buildDeleteResponse = (BuildDeleteResponse) invokeService(buildDeleteRequest,action);
				responseObject = populateResponse(buildDeleteResponse, buildDO,action);
			}
		}
		catch (CustomException e) {
			throw new CustomException(e.getErrCode(), e.getErrMsg());
		}
		return responseObject;
	}

	@Override
	public Object populateRequest(Object requestObject, String action) throws CustomException {
		String METHOD_NAME = "populateRequest";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build populateRequest method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDetailRequest","Build Details");
			BuildDO buildDO = (BuildDO)requestObject;
			BuildDetailsRequest buildDetailsRequest = new BuildDetailsRequest();
			buildDetailsRequest.setBuildId(buildDO.getBuildId());
			buildDetailsRequest.setTokenId(buildDO.getTokenId());
			buildDetailsRequest.setChannelId("EZ");
			return buildDetailsRequest;
		}
		else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildListRequest","Build List");
			BuildListDO buildListDO = (BuildListDO)requestObject;
			BuildListRequest buildListRequest = new BuildListRequest();
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildListDO.getBuild() to buildListRequest","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(buildListDO.getBuild(), buildListRequest);
			buildListRequest.setTokenId(buildListDO.getTokenId());
			buildListRequest.setChannelId("EZ");
			return buildListRequest;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)){
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildInsertRequest","Build Insert");
			BuildDO buildDO = (BuildDO)requestObject;
			BuildInsertRequest buildInsertRequest = new BuildInsertRequest();
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildDO to buildInsertRequest","Dozer Bean Copy");
			CommonUtility.copyBeanProperties(buildDO, buildInsertRequest);
			buildInsertRequest.setChannelId("EZ");
			return buildInsertRequest;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDeleteRequest","Build Delete");
			BuildDO buildDO = (BuildDO)requestObject;
			BuildDeleteRequest buildDeleteRequest = new BuildDeleteRequest();
			buildDeleteRequest.setBuildId(buildDO.getBuildId());
			buildDeleteRequest.setTokenId(buildDO.getTokenId());
			buildDeleteRequest.setChannelId("CN");
			return buildDeleteRequest;
		}
		else{
			throw new CustomException("400", "Invalid Request");
		}
	}

	@Override
	public Object invokeService(Object requestObject, String action) throws CustomException {
		final String METHOD_NAME = "invokeService";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build invoke service method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			BuildDetailsRequest buildDetailsRequest = (BuildDetailsRequest) requestObject;
			BuildDetailsResponse response = null; 
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Details", "Before calling rest service invocation");
				response= (BuildDetailsResponse) EztracRestClient.invokeRestService(buildDetailsRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getBuildDetails.url"), BuildDetailsResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Details", "After rest service invocation");
			}
			catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else if(action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			BuildListRequest buildListRequest = (BuildListRequest) requestObject;
			BuildListResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build List", "Before calling rest service invocation");
				response= (BuildListResponse) EztracRestClient.invokeRestService(buildListRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getBuildList.url"), BuildListResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build List", "After rest service invocation");
			}
			catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_SB1001))
					{
						return response;
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			BuildInsertRequest buildInsertRequest = (BuildInsertRequest) requestObject;
			BuildInsertResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Insert", "Before calling rest service invocation");
				response = (BuildInsertResponse) EztracRestClient.invokeRestService(buildInsertRequest, CommonUtility.getValFrmAppUrlProp("ez.service.insertBuildDetails.url"), BuildInsertResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Insert", "After rest service invocation");
			}
			catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WB1001) || 
							response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WB1003) )
					{
						return response;
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			BuildDeleteRequest buildDeleteRequest = (BuildDeleteRequest) requestObject;
			BuildDeleteResponse response = null;
			try {
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Delete", "Before calling rest service invocation");
				response = (BuildDeleteResponse) EztracRestClient.invokeRestService(buildDeleteRequest, CommonUtility.getValFrmAppUrlProp("ez.service.deleteBuildDetails.url"), BuildDeleteResponse.class.getName());
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, ICommonConstants.BUILD_SERVICE_LOG_KEY+"Build Delete", "After rest service invocation");
			} catch (CustomException e) {
				if(null!=response) {
					if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FB1001)) {
						throw new CustomException(response.getResponseCode(),response.getResponseDescription());
					}
					else if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_WB1002)) 
					{
						return response;
					}
					else {
						throw new CustomException(e.getErrCode(),e.getErrMsg());
					}
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			return response;
		}
		else {
			throw new CustomException("400", "Invalid Request");
		}
	}
	
	@Override
	public Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "populateResponse";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build populateResponse method", "");
		
		if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDetailsResponse","Build Details");
			BuildDetailsResponse buildDetailsResponse= (BuildDetailsResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			buildDO = buildDetailsResponse.getBuild();
			buildDO.setTokenId(buildDetailsResponse.getTokenId());
			return buildDO;
		}
		
		else if (action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildListResponse","Build List");
			BuildListResponse buildListResponse = (BuildListResponse) responseObject;
			BuildListDO buildListDO = (BuildListDO)doObject;
			if(buildListResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_SB1000) && null!=buildListResponse.getBuildDetails()) {
				buildListDO.setBuildList(buildListResponse.getBuildDetails());
			}
			if(buildListResponse.getResponseCode().equals(ICommonConstants.SERVICESTATUS_SB1001)) {
				Map<String, String> responseCodeMap=new HashMap<String, String>();
				responseCodeMap.put(buildListResponse.getResponseCode(), ICommonConstants.NO_RECORDS_FOUND);
				buildListDO.setResponseMap(responseCodeMap);
			}
			return buildListDO;
		}
		
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildInsertResponse","Build Insert");
			BuildInsertResponse buildInsertResponse= (BuildInsertResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			String insertResponseCode = buildInsertResponse.getResponseCode();
			if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_SB1000)) {
				buildDO = new BuildDO();
				LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Copying buildInsertResponse.getBuild() to buildDO","Dozer Bean Copy");
				CommonUtility.copyBeanProperties(buildInsertResponse.getBuild(), buildDO);
				responseCodeMap.put(insertResponseCode, ICommonConstants.INSERT_SUCCESS);
			}
			else if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_SB1002)) {
				buildDO = new BuildDO();
				responseCodeMap.put(insertResponseCode, ICommonConstants.INSERT_PARTIAL_SUCCESS);
			}
			else if(insertResponseCode.equals(ICommonConstants.SERVICESTATUS_WB1001) ||  insertResponseCode.equals(ICommonConstants.SERVICESTATUS_WB1003) ) 
			{
				responseCodeMap.put(insertResponseCode,buildInsertResponse.getResponseDescription());
			}
			buildDO.setResponseMap(responseCodeMap);
			return buildDO;
		}
		
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDeleteResponse","Build Delete");
			BuildDeleteResponse buildDeleteResponse= (BuildDeleteResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			String deleteResponseCode = buildDeleteResponse.getResponseCode();
			
			if(deleteResponseCode.equals(ICommonConstants.SERVICESTATUS_SB1000)) {
				buildDO = new BuildDO();
				responseCodeMap.put(deleteResponseCode, ICommonConstants.DELETE_SUCCESS);
			}
			else if(deleteResponseCode.equals(ICommonConstants.SERVICESTATUS_WB1002)) {
				responseCodeMap.put(deleteResponseCode, ICommonConstants.BUILD_DELETE_FAILURE);
			}
			
			buildDO.setResponseMap(responseCodeMap);
			buildDO.setTokenId(buildDeleteResponse.getTokenId());
			return buildDO;
		}
		else {
			throw new CustomException("400", "Invalid Request");
		}
	}

	/*@Override
	public Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException {
		final String METHOD_NAME = "populateResponse";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside Build populateResponse method", "");
		
		if (action.equals(ICommonConstants.LIST_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildListResponse","Build List");
			BuildListResponse buildListResponse = (BuildListResponse) responseObject;
			BuildListDO buildListDO = (BuildListDO)doObject;
			if(null!=buildListResponse.getBuildDetails()) {
				buildListDO.setBuildList(buildListResponse.getBuildDetails());
			}
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			responseCodeMap.put(buildListResponse.getResponseCode(), buildListResponse.getResponseDescription());
			buildListDO.setResponseMap(responseCodeMap);
			return buildListDO;
		}
		
		else if(action.equals(ICommonConstants.DETAILS_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDetailsResponse","Build Details");
			BuildDetailsResponse buildDetailsResponse= (BuildDetailsResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			buildDO = buildDetailsResponse.getBuild();
			buildDO.setTokenId(buildDetailsResponse.getTokenId());
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			responseCodeMap.put(buildDetailsResponse.getResponseCode(), buildDetailsResponse.getResponseDescription());
			buildDO.setResponseMap(responseCodeMap);
			return buildDO;
		}
		
		else if(action.equals(ICommonConstants.INSERT_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildInsertResponse","Build Insert");
			BuildInsertResponse buildInsertResponse= (BuildInsertResponse) responseObject;
			BuildDO buildDO = (BuildDO)doObject;
			if(null!=buildInsertResponse) {
				buildDO = new BuildDO();
				CommonUtility.copyBeanProperties(buildInsertResponse.getBuild(), buildDO);
				buildDO.setTokenId(buildInsertResponse.getTokenId());
			}
			Map<String, String> responseCodeMap=new HashMap<String, String>();
			responseCodeMap.put(buildInsertResponse.getResponseCode(), buildInsertResponse.getResponseDescription());
			buildDO.setResponseMap(responseCodeMap);
			return buildDO;
		}
		
		else if(action.equals(ICommonConstants.DELETE_REQUEST_ACTION)) {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "populateBuildDeleteResponse","Build Delete");
			BuildDeleteResponse buildDeleteResponse= (BuildDeleteResponse) responseObject;
			
			if(null!=buildDeleteResponse) {
				Map<String, String> responseCodeMap=new HashMap<String, String>();
				responseCodeMap.put(buildDeleteResponse.getResponseCode(), buildDeleteResponse.getResponseDescription());
				if(buildDeleteResponse.getResponseCode().equals("200")) {
					BuildDO newBuildDO = new BuildDO();
					newBuildDO.setResponseMap(responseCodeMap);
					newBuildDO.setTokenId(buildDeleteResponse.getTokenId());
					return newBuildDO;
				}
				else {
					BuildDO buildDO = (BuildDO)doObject;
					buildDO.setResponseMap(responseCodeMap);
					buildDO.setTokenId(buildDeleteResponse.getTokenId());
					return buildDO;
				}
			}
			else {
				return null;
			}
		}
		
		else {
			throw new CustomException("400", "Invalid Request");
		}
	}*/
	
}
