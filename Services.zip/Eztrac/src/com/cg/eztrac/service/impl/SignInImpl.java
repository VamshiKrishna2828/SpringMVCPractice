package com.cg.eztrac.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.domain.RoleDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.domain.UserLocationDO;
import com.cg.eztrac.encryption.AESEncryption;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.IServiceMandates;
import com.cg.eztrac.service.request.LoginInfoReq;
import com.cg.eztrac.service.response.LoginInfoRes;
import com.google.gson.Gson;

@Service
public class SignInImpl implements IServiceMandates {
	String classname =SignInImpl.class.getName();
	
	/** forming LoginRequest ( userDO -> request ) */
	@Override
	public Object populateRequest(Object object, String action) throws CustomException {
		UserDO userDO = (UserDO)object;
		String methodName="populateDOToLoginRequest";
		LoginInfoReq loginInfoReq = new LoginInfoReq();
		try {
			loginInfoReq.setLoginId(userDO.getUsername());
			loginInfoReq.setPassowrd(AESEncryption.encrypt(userDO.getPassword()));
			loginInfoReq.setTokenId(CommonUtility.getTokenId());
		} catch (CustomException e) {
			LoggerManager.writeErrorLog(classname,methodName,e.getMessage(), e,"exception while setting the vslues to login request");
		}
		return loginInfoReq;
	}

	/** forming UserDO ( response -> DO ) */
	@Override
	public Object populateResponse(Object responseObject,Object doObject, String action) throws CustomException {
		LoginInfoRes loginSignResp = (LoginInfoRes)responseObject;
		UserDO userDO = (UserDO) doObject ;
		if(loginSignResp.getResponseCode().equalsIgnoreCase(ICommonConstants.SERVICESTATUS_SL1000)){ // success=100
			List<RoleDO> roleDOList = new ArrayList<RoleDO>();
			
			Gson gson = new Gson();
			/** convert response "gson" which is returned from Service response to "object" */
			for (int i=0;i<loginSignResp.getRolepermission().size();i++){
				RoleDO roleDO = new RoleDO();
				String roleDOJson = gson.toJson( loginSignResp.getRolepermission().get(i));
				roleDO = gson.fromJson(roleDOJson, RoleDO.class);
				roleDOList.add(roleDO);
			}
			List<UserLocationDO> locationDOList = new ArrayList<UserLocationDO>();
			CommonUtility.copyBeanProperties(loginSignResp.getUserlocations(), locationDOList);
			userDO.setUserlocations(locationDOList);
			userDO.setRoles(roleDOList);
			userDO.setAccountName(loginSignResp.getUserDedail().getAccountName());
			userDO.setClientReportingFlag(loginSignResp.getUserDedail().getClientReportingFlag());
			userDO.setClientSsoId(loginSignResp.getUserDedail().getClientSsoId());
			userDO.setEmailId(loginSignResp.getUserDedail().getEmailId());
			userDO.setEmployeeCode(loginSignResp.getUserDedail().getEmployeeCode());
			userDO.setGdcName(loginSignResp.getUserDedail().getGdcName());
			userDO.setInductionFlag(loginSignResp.getUserDedail().getInductionFlag());
			userDO.setSbu(loginSignResp.getUserDedail().getSbu());
			userDO.setSubAccountId(loginSignResp.getUserDedail().getSubAccountId());
			userDO.setSubAccountName(loginSignResp.getUserDedail().getAccountName());
			userDO.setTelMobileNum(loginSignResp.getUserDedail().getTelMobileNum());
			userDO.setTelOfficeNum(loginSignResp.getUserDedail().getTelOfficeNum());
			userDO.setUnitAssigned(loginSignResp.getUserDedail().getUnitAssigned());
			userDO.setUserId(loginSignResp.getUserDedail().getUserId());
			userDO.setUsername(loginSignResp.getUserDedail().getUsername());
			//userDO.setSuccess(loginSignResp.getResponseCode().equals(ICommonConstants.LOGIN_SUCCESS_CODE));
			//userDO.setInvalidPassword(loginSignResp.getResponseCode().equals(ICommonConstants.INVALID_PASSWORD_CODE));
			userDO.setSuccess(true);
		}
		/*if(!userDO.isSuccess()){
			if(loginSignResp.getResponseCode().equals(ICommonConstants.INVALID_PASSWORD_CODE)){
				userDO.setInvalidPassword(true);
			} else if(loginSignResp.getResponseCode().equals(ICommonConstants.INVALID_USERNAME_CODE)){
				userDO.setInvalidUsername(true);
			}
		}*/
		else if(loginSignResp.getResponseCode().equalsIgnoreCase(ICommonConstants.SERVICESTATUS_SL1001)){
			userDO.setInvalidPassword(true);
			userDO.setInvalidUsername(true);
		}
		else {
			throw new CustomException("","Login Service Error Occurred!! Please login again Later...");
		}
		return userDO;
	}
	
	@Override
	public Object invokeService(Object object, String action) throws CustomException {
		LoginInfoReq loginInfoReq = (LoginInfoReq) object;
		String methodName = "loginSignIn";
		LoginInfoRes response = null;
		LoggerManager.writeInfoLog(classname,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "Before calling rest service invocation");
		try {
			response = (LoginInfoRes) EztracRestClient.invokeRestService(loginInfoReq, CommonUtility.getValFrmAppUrlProp("ez.service.login.url"), LoginInfoRes.class.getName());
		}catch (CustomException e) {
			// TODO: handle exception
			if(null!=response) {
				if(response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FL1000) || response.getResponseCode().equals(ICommonConstants.SERVICESTATUS_FL1001)) {
					throw new CustomException(response.getResponseCode(),response.getResponseDescription());
				}
				else {
					throw new CustomException(e.getErrCode(),e.getErrMsg());
				}
			}
			else {
				throw new CustomException(e.getErrCode(),e.getErrMsg());
			}
		}
	
		LoggerManager.writeInfoLog(classname,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "After rest service invocation");
		return response;
	}
	
	@Override
	public Object serviceProcessor(Object object, String action) throws CustomException {
		UserDO userDO = (UserDO)object;
		LoginInfoReq loginInfoReq = (LoginInfoReq) populateRequest(userDO,null);
		LoginInfoRes loginInfoRes = (LoginInfoRes)invokeService(loginInfoReq,null);
		userDO = (UserDO) populateResponse(loginInfoRes, userDO,null);
		return userDO;
	}
	
}
