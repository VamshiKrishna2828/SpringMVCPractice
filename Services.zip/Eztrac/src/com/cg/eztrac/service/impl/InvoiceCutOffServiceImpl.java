package com.cg.eztrac.service.impl;

import org.springframework.stereotype.Service;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.resttemplate.EztracRestClient;
import com.cg.eztrac.service.InvoiceCutOffService;
import com.cg.eztrac.service.request.InvoiceCutOffRequest;
import com.cg.eztrac.service.response.InvoiceCutOffResponse;

@Service
public class InvoiceCutOffServiceImpl implements InvoiceCutOffService {
	String classname =SignInImpl.class.getName();
	

	@SuppressWarnings("unchecked")
	@Override
	public InvoiceCutOffResponse  invoiceService(InvoiceCutOffRequest invoiceCutOffRequest) throws CustomException {
		String methodName = "invoiceService";
		InvoiceCutOffResponse response = null;
		LoggerManager.writeInfoLog(classname,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "Before calling rest service invocation");
		response = (InvoiceCutOffResponse) EztracRestClient.invokeRestService(invoiceCutOffRequest, CommonUtility.getValFrmAppUrlProp("ez.service.getInvoiceCutOff.url"), InvoiceCutOffResponse.class.getName());
	//	System.out.println(response);
		LoggerManager.writeInfoLog(classname,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "After rest service invocation");
		return response;
	}


}
