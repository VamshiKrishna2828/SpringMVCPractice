package com.cg.eztrac.service;

import com.cg.eztrac.service.request.PerCCInsertRequest;
import com.cg.eztrac.service.request.PerDetailsRequest;
import com.cg.eztrac.service.request.PerInsertRequest;
import com.cg.eztrac.service.request.PerListRequest;
import com.cg.eztrac.service.response.PerCCInsertResponse;
import com.cg.eztrac.service.response.PerDetailsResponse;
import com.cg.eztrac.service.response.PerInsertResponse;
import com.cg.eztrac.service.response.PerListResponse;

public interface PerService {
	
	public PerListResponse getPerList(PerListRequest perListRequest) throws Exception;
	
	public PerDetailsResponse getPerDetails(PerDetailsRequest perDetailsRequest) ;
	
	public PerInsertResponse insertPerDetails(PerInsertRequest perInsertRequest);
	
	public PerCCInsertResponse insertPerCCDetails(PerCCInsertRequest perInsertRequest);
	
}
