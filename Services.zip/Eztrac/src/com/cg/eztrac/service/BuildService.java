package com.cg.eztrac.service;

import com.cg.eztrac.service.request.BuildDetailsRequest;
import com.cg.eztrac.service.request.BuildInsertRequest;
import com.cg.eztrac.service.request.BuildListRequest;
import com.cg.eztrac.service.response.BuildDetailsResponse;
import com.cg.eztrac.service.response.BuildInsertResponse;
import com.cg.eztrac.service.response.BuildListResponse;

public interface BuildService {
	
	public BuildListResponse getBuildList(BuildListRequest buildListRequest) throws Exception;
	
	public BuildDetailsResponse getBuildDetails(BuildDetailsRequest buildDetailsRequest) throws Exception;
	
	public BuildInsertResponse insertBuildDetails(BuildInsertRequest buildInsertRequest) throws Exception;
	
}
