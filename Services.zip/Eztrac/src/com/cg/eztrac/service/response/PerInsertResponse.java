package com.cg.eztrac.service.response;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.PerDO;

@Component(value="perInsertResponse")
public class PerInsertResponse extends PerDO implements IRestServiceResponse {
	
	//private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	
	/*public String getTokenId() {
		return tokenId;
	}*/
	public String getChannelId() {
		return channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	
	
	
	
}
