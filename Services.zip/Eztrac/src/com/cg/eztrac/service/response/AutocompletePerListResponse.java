package com.cg.eztrac.service.response;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.eztrac.domain.PerChangeControlDO;
import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.domain.PerLoeDO;
import com.cg.eztrac.domain.PurchaseOrderDO;

@Component(value="autocompletePerListResponse")
public class AutocompletePerListResponse {

	private List<PerDO> perDetail;
	private String tokenId;
	private String responseCode;
	private String responseDescription;
	/**
	 * @return the perDetail
	 */
	public List<PerDO> getPerDetail() {
		return perDetail;
	}
	/**
	 * @param perDetail the perDetail to set
	 */
	public void setPerDetail(List<PerDO> perDetail) {
		this.perDetail = perDetail;
	}
	/**
	 * @return the tokenId
	 */
	public String getTokenId() {
		return tokenId;
	}
	/**
	 * @param tokenId the tokenId to set
	 */
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	/**
	 * @return the responseCode
	 */
	public String getResponseCode() {
		return responseCode;
	}
	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	/**
	 * @return the responseDescription
	 */
	public String getResponseDescription() {
		return responseDescription;
	}
	/**
	 * @param responseDescription the responseDescription to set
	 */
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	
	@Override
	public String toString() {
		return "AutocompletePerListResponse [perDetail=" + perDetail + ", tokenId=" + tokenId + ", responseCode=" + responseCode
				+ ", responseDescription=" + responseDescription + "]";
	}
	
	public class AutocompletePerListDetails{
		
		//General - Fields - Per Module
		
		private Date currentPhaseEndDate;
		private String[] managersToNotifyArray;
		private String parNumber;
		private Date perReceiptDate;
		private String projectComments;
		private Integer projectType;
		private String projectTypeName;
		private String status;
		
		//Schedule Updates - Fields - Per Module
		private Date scheduleCallDate;
		private Date cancellationDate;
		private Date currentScheduleEndDate;
		private Date currentScheduleStartDate;
		private Date restartDate;
		private Date stopDate;
		
		private PerChangeControlDO perChangeControl;
		private PerLoeDO perLoe;
		
		private List<PurchaseOrderDO> purchaseOrderList;
		private List<PerChangeControlDO> perChangeControlList;
		
		private String description; //TODO - Remove this - Temp added

		/**
		 * @return the currentPhaseEndDate
		 */
		public Date getCurrentPhaseEndDate() {
			return currentPhaseEndDate;
		}

		/**
		 * @param currentPhaseEndDate the currentPhaseEndDate to set
		 */
		public void setCurrentPhaseEndDate(Date currentPhaseEndDate) {
			this.currentPhaseEndDate = currentPhaseEndDate;
		}

		/**
		 * @return the managersToNotifyArray
		 */
		public String[] getManagersToNotifyArray() {
			return managersToNotifyArray;
		}

		/**
		 * @param managersToNotifyArray the managersToNotifyArray to set
		 */
		public void setManagersToNotifyArray(String[] managersToNotifyArray) {
			this.managersToNotifyArray = managersToNotifyArray;
		}

		/**
		 * @return the parNumber
		 */
		public String getParNumber() {
			return parNumber;
		}

		/**
		 * @param parNumber the parNumber to set
		 */
		public void setParNumber(String parNumber) {
			this.parNumber = parNumber;
		}

		/**
		 * @return the perReceiptDate
		 */
		public Date getPerReceiptDate() {
			return perReceiptDate;
		}

		/**
		 * @param perReceiptDate the perReceiptDate to set
		 */
		public void setPerReceiptDate(Date perReceiptDate) {
			this.perReceiptDate = perReceiptDate;
		}

		/**
		 * @return the projectComments
		 */
		public String getProjectComments() {
			return projectComments;
		}

		/**
		 * @param projectComments the projectComments to set
		 */
		public void setProjectComments(String projectComments) {
			this.projectComments = projectComments;
		}

		/**
		 * @return the projectType
		 */
		public Integer getProjectType() {
			return projectType;
		}

		/**
		 * @param projectType the projectType to set
		 */
		public void setProjectType(Integer projectType) {
			this.projectType = projectType;
		}

		/**
		 * @return the projectTypeName
		 */
		public String getProjectTypeName() {
			return projectTypeName;
		}

		/**
		 * @param projectTypeName the projectTypeName to set
		 */
		public void setProjectTypeName(String projectTypeName) {
			this.projectTypeName = projectTypeName;
		}

		/**
		 * @return the status
		 */
		public String getStatus() {
			return status;
		}

		/**
		 * @param status the status to set
		 */
		public void setStatus(String status) {
			this.status = status;
		}

		/**
		 * @return the scheduleCallDate
		 */
		public Date getScheduleCallDate() {
			return scheduleCallDate;
		}

		/**
		 * @param scheduleCallDate the scheduleCallDate to set
		 */
		public void setScheduleCallDate(Date scheduleCallDate) {
			this.scheduleCallDate = scheduleCallDate;
		}

		/**
		 * @return the cancellationDate
		 */
		public Date getCancellationDate() {
			return cancellationDate;
		}

		/**
		 * @param cancellationDate the cancellationDate to set
		 */
		public void setCancellationDate(Date cancellationDate) {
			this.cancellationDate = cancellationDate;
		}

		/**
		 * @return the currentScheduleEndDate
		 */
		public Date getCurrentScheduleEndDate() {
			return currentScheduleEndDate;
		}

		/**
		 * @param currentScheduleEndDate the currentScheduleEndDate to set
		 */
		public void setCurrentScheduleEndDate(Date currentScheduleEndDate) {
			this.currentScheduleEndDate = currentScheduleEndDate;
		}

		/**
		 * @return the currentScheduleStartDate
		 */
		public Date getCurrentScheduleStartDate() {
			return currentScheduleStartDate;
		}

		/**
		 * @param currentScheduleStartDate the currentScheduleStartDate to set
		 */
		public void setCurrentScheduleStartDate(Date currentScheduleStartDate) {
			this.currentScheduleStartDate = currentScheduleStartDate;
		}

		/**
		 * @return the restartDate
		 */
		public Date getRestartDate() {
			return restartDate;
		}

		/**
		 * @param restartDate the restartDate to set
		 */
		public void setRestartDate(Date restartDate) {
			this.restartDate = restartDate;
		}

		/**
		 * @return the stopDate
		 */
		public Date getStopDate() {
			return stopDate;
		}

		/**
		 * @param stopDate the stopDate to set
		 */
		public void setStopDate(Date stopDate) {
			this.stopDate = stopDate;
		}

		/**
		 * @return the perChangeControl
		 */
		public PerChangeControlDO getPerChangeControl() {
			return perChangeControl;
		}

		/**
		 * @param perChangeControl the perChangeControl to set
		 */
		public void setPerChangeControl(PerChangeControlDO perChangeControl) {
			this.perChangeControl = perChangeControl;
		}

		/**
		 * @return the perLoe
		 */
		public PerLoeDO getPerLoe() {
			return perLoe;
		}

		/**
		 * @param perLoe the perLoe to set
		 */
		public void setPerLoe(PerLoeDO perLoe) {
			this.perLoe = perLoe;
		}

		/**
		 * @return the purchaseOrderList
		 */
		public List<PurchaseOrderDO> getPurchaseOrderList() {
			return purchaseOrderList;
		}

		/**
		 * @param purchaseOrderList the purchaseOrderList to set
		 */
		public void setPurchaseOrderList(List<PurchaseOrderDO> purchaseOrderList) {
			this.purchaseOrderList = purchaseOrderList;
		}

		/**
		 * @return the perChangeControlList
		 */
		public List<PerChangeControlDO> getPerChangeControlList() {
			return perChangeControlList;
		}

		/**
		 * @param perChangeControlList the perChangeControlList to set
		 */
		public void setPerChangeControlList(List<PerChangeControlDO> perChangeControlList) {
			this.perChangeControlList = perChangeControlList;
		}

		/**
		 * @return the description
		 */
		public String getDescription() {
			return description;
		}

		/**
		 * @param description the description to set
		 */
		public void setDescription(String description) {
			this.description = description;
		}
		
		

		
	}
	
}
