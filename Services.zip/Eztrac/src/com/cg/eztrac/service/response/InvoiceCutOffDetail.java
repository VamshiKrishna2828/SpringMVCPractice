package com.cg.eztrac.service.response;

public class InvoiceCutOffDetail {
	private int invoiceYear;
	private int invoiceMonth;
	private int invoiceDt;
	public int getInvoiceYear() {
		return invoiceYear;
	}
	public void setInvoiceYear(int invoiceYear) {
		this.invoiceYear = invoiceYear;
	}
	public int getInvoiceMonth() {
		return invoiceMonth;
	}
	public void setInvoiceMonth(int invoiceMonth) {
		this.invoiceMonth = invoiceMonth;
	}
	public int getInvoiceDt() {
		return invoiceDt;
	}
	public void setInvoiceDt(int invoiceDt) {
		this.invoiceDt = invoiceDt;
	} 
}
