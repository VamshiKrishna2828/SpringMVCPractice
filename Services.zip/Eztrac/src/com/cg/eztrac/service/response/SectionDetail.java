	package com.cg.eztrac.service.response;

import java.util.List;

import com.cg.eztrac.common.IRestServiceResponse;
import com.cg.eztrac.domain.SubSectionDO;

public class SectionDetail implements IRestServiceResponse{

    
	Integer sectionID;
	Integer sectionType;
	String sectionName;
	List<SubSectionDO> subSection;
	
	public Integer getSectionType() {
		return sectionType;
	}
	public void setSectionType(Integer sectionType) {
		this.sectionType = sectionType;
	}
	public Integer getSectionID() {
		return sectionID;
	}
	public void setSectionID(Integer sectionID) {
		this.sectionID = sectionID;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	
	public List<SubSectionDO> getSubSection() {
		return subSection;
	}
	public void setSubSection(List<SubSectionDO> subSection) {
		this.subSection = subSection;
	}
	@Override
	public String getTokenId() {
		return null;
	}
	@Override
	public String getChannelId() {
		return null;
	}
	@Override
	public String getResponseCode() {
		return null;
	}
	@Override
	public String getResponseDescription() {
		return null;
	}
	
}
