package com.cg.eztrac.service;

import com.cg.eztrac.vo.UserVO;

public interface UserService {
	public UserVO findByUserName(String username); 

}
