package com.cg.eztrac.service;

import java.util.Date;
import java.util.List;

import com.cg.eztrac.service.request.DeleteTimeSheetRequest;
import com.cg.eztrac.service.request.GetPerListTimeSheetRequest;
import com.cg.eztrac.service.request.InsertTimeSheetRequest;
import com.cg.eztrac.service.request.TimeSheetRequest;
import com.cg.eztrac.service.response.DeleteTimeSheetResponse;
import com.cg.eztrac.service.response.InsertTimeSheetResponse;
import com.cg.eztrac.service.response.PerListResponse;
import com.cg.eztrac.service.response.TimeSheetResponse;
import com.cg.eztrac.vo.SubSystemVO;
import com.cg.eztrac.vo.SystemDetailsVO;
import com.cg.eztrac.vo.TimeSheetVO;

public interface TimeSheetService {

	TimeSheetVO getTimeSheetList(Date startDate, Date endDate, String projectName);
	List<SubSystemVO> getAllSubsystemDetails(int subSytem);
	List<SystemDetailsVO> getAllSystemDetails();
	boolean saveTimeSheet(TimeSheetVO timesheetVO);
	//boolean deleteTimeSheet(DeleteTimeSheetRequest deleteTimeSheetRequest);
	public TimeSheetResponse getTimeSheetDetails(TimeSheetRequest timeSheetRequest);
	public PerListResponse getPerListDetails(GetPerListTimeSheetRequest getPerListTimeSheetRequest);
	InsertTimeSheetResponse insertTimeSheetDetails(InsertTimeSheetRequest insertTimeSheetRequest);
	DeleteTimeSheetResponse deleteTimeSheetDetails(DeleteTimeSheetRequest insertTimeSheetRequest);

}
