package com.cg.eztrac.service.request;

import java.util.List;

import com.cg.eztrac.common.IRestServiceRequest;

public class DeleteTimeSheetRequest implements IRestServiceRequest{
		
	private List<TimeSheetDelete> tsDelete;
	private String tokenId;
	private String channelId;
	
	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param channelId the channelId to set
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * @param tokenId the tokenId to set
	 */
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	
	/**
	 * @return the tsDelete
	 */
	public List<TimeSheetDelete> getTsDelete() {
		return tsDelete;
	}

	/**
	 * @param tsDelete the tsDelete to set
	 */
	public void setTsDelete(List<TimeSheetDelete> tsDelete) {
		this.tsDelete = tsDelete;
	}

	public static class TimeSheetDelete {
		
		private Integer timeSheetId;

		public Integer getTimeSheetId() {
			return timeSheetId;
		}

		public void setTimeSheetId(Integer timeSheetId) {
			this.timeSheetId = timeSheetId;
		}

	}
}