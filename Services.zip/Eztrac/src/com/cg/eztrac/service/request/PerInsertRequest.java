package com.cg.eztrac.service.request;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.domain.PerDO;

@Component(value="perInsertRequest")
public class PerInsertRequest extends PerDO implements IRestServiceRequest {
	
	//private String tokenId;
	private String channelId;
	
	/*public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}*/
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
	
}
