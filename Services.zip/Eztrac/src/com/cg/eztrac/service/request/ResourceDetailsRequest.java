package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class ResourceDetailsRequest implements IRestServiceRequest {

	private int subAccountId;
	
	public int getSubAccountId() {
		return subAccountId;
	}

	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}

	@Override
	public String getChannelId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTokenId() {
		// TODO Auto-generated method stub
		return null;
	}

	
}