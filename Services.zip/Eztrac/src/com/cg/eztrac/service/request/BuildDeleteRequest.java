package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class BuildDeleteRequest implements IRestServiceRequest {
	
	private Integer buildId;
	private String tokenId;
	private String channelId;
	
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public Integer getBuildId() {
		return buildId;
	}
	public void setBuildId(Integer buildId) {
		this.buildId = buildId;
	}

}
