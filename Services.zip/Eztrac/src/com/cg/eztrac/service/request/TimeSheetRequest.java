package com.cg.eztrac.service.request;

import com.cg.eztrac.common.IRestServiceRequest;

public class TimeSheetRequest implements IRestServiceRequest {
	
	private String perNumber;
	private Integer userId;
	private Integer systemId;
	private Integer sybSytemId;
	private String  startDate;
	private String endDate;
	private String tokenId;
	private String channelId;
	
	public String getPerNumber() {
		return perNumber;
	}
	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}
	public Integer getSystemId() {
		return systemId;
	}
	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}
	public Integer getSybSytemId() {
		return sybSytemId;
	}
	public void setSybSytemId(Integer sybSytemId) {
		this.sybSytemId = sybSytemId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	@Override
	public String toString() {
		return "TimeSheetRequest [perNumber=" + perNumber + ", userId=" + userId + ", systemId=" + systemId
				+ ", sybSytemId=" + sybSytemId + ", startDate=" + startDate + ", endDate=" + endDate + ", tokenId="
				+ tokenId + ", channelId=" + channelId + "]";
	}
	
}