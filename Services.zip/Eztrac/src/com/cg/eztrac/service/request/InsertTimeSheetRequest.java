package com.cg.eztrac.service.request;

import java.util.List;

import com.cg.eztrac.common.IRestServiceRequest;

public class InsertTimeSheetRequest implements IRestServiceRequest {

	private List<TimeSheetRow> timesheetList;
	private String tokenId;
	
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}

	@Override
	public String getChannelId() {
		return "EZ";
	}

	@Override
	public String getTokenId() {
		return "TEST";
	}

	/**
	 * @return the timesheetList
	 */
	public List<TimeSheetRow> getTimesheetList() {
		return timesheetList;
	}

	/**
	 * @param timesheetList the timesheetList to set
	 */
	public void setTimesheetList(List<TimeSheetRow> timesheetList) {
		this.timesheetList = timesheetList;
	}

	public static class TimeSheetRow{
		
		private String timeSheetId;
		private int buildId;
		private int taskId;
		private int subTaskId;	
		private String dateWorked;
		private int hoursWorked;
		private String invoiceCutoffDate;
		private int approvedBy;
		//private Date approvedOn;
		private String approvedOn;
		private int createdBy;
		//private Date createdOn;
		private String createdOn;
		private int lastModifiedBy;
		//private Date lastModidfiedOn;
		private String lastModidfiedOn;
		private boolean onsiteFlag;
		private int userId;
		private String statusCd;
		
		/**
		 * @return the buildId
		 */
		public int getBuildId() {
			return buildId;
		}
		/**
		 * @param buildId the buildId to set
		 */
		public void setBuildId(int buildId) {
			this.buildId = buildId;
		}
		/**
		 * @return the taskId
		 */
		public int getTaskId() {
			return taskId;
		}
		/**
		 * @param taskId the taskId to set
		 */
		public void setTaskId(int taskId) {
			this.taskId = taskId;
		}
		/**
		 * @return the subTaskId
		 */
		public int getSubTaskId() {
			return subTaskId;
		}
		/**
		 * @param subTaskId the subTaskId to set
		 */
		public void setSubTaskId(int subTaskId) {
			this.subTaskId = subTaskId;
		}
		/**
		 * @return the dateWorked
		 */
		public String getDateWorked() {
			return dateWorked;
		}
		/**
		 * @param dateWorked the dateWorked to set
		 */
		public void setDateWorked(String dateWorked) {
			this.dateWorked = dateWorked;
		}
		/**
		 * @return the hoursWorked
		 */
		public int getHoursWorked() {
			return hoursWorked;
		}
		/**
		 * @param hoursWorked the hoursWorked to set
		 */
		public void setHoursWorked(int hoursWorked) {
			this.hoursWorked = hoursWorked;
		}
		/**
		 * @return the invoiceCutoffDate
		 */
		public String getInvoiceCutoffDate() {
			return invoiceCutoffDate;
		}
		/**
		 * @param invoiceCutoffDate the invoiceCutoffDate to set
		 */
		public void setInvoiceCutoffDate(String invoiceCutoffDate) {
			this.invoiceCutoffDate = invoiceCutoffDate;
		}
		/**
		 * @return the approvedBy
		 */
		public int getApprovedBy() {
			return approvedBy;
		}
		/**
		 * @param approvedBy the approvedBy to set
		 */
		public void setApprovedBy(int approvedBy) {
			this.approvedBy = approvedBy;
		}
		/**
		 * @return the createdBy
		 */
		public int getCreatedBy() {
			return createdBy;
		}
		/**
		 * @param createdBy the createdBy to set
		 */
		public void setCreatedBy(int createdBy) {
			this.createdBy = createdBy;
		}
		/**
		 * @return the lastModifiedBy
		 */
		public int getLastModifiedBy() {
			return lastModifiedBy;
		}
		/**
		 * @param lastModifiedBy the lastModifiedBy to set
		 */
		public void setLastModifiedBy(int lastModifiedBy) {
			this.lastModifiedBy = lastModifiedBy;
		}
		/**
		 * @return the onsiteFlag
		 */
		public boolean isOnsiteFlag() {
			return onsiteFlag;
		}
		/**
		 * @param onsiteFlag the onsiteFlag to set
		 */
		public void setOnsiteFlag(boolean onsiteFlag) {
			this.onsiteFlag = onsiteFlag;
		}
		/**
		 * @return the userId
		 */
		public int getUserId() {
			return userId;
		}
		/**
		 * @param userId the userId to set
		 */
		public void setUserId(int userId) {
			this.userId = userId;
		}
		/**
		 * @return the timeSheetId
		 */
		public String getTimeSheetId() {
			return timeSheetId;
		}
		/**
		 * @param timeSheetId the timeSheetId to set
		 */
		public void setTimeSheetId(String timeSheetId) {
			this.timeSheetId = timeSheetId;
		}
		/**
		 * @return the approvedOn
		 */
		public String getApprovedOn() {
			return approvedOn;
		}
		/**
		 * @param approvedOn the approvedOn to set
		 */
		public void setApprovedOn(String approvedOn) {
			this.approvedOn = approvedOn;
		}
		/**
		 * @return the createdOn
		 */
		public String getCreatedOn() {
			return createdOn;
		}
		/**
		 * @param createdOn the createdOn to set
		 */
		public void setCreatedOn(String createdOn) {
			this.createdOn = createdOn;
		}
		/**
		 * @return the lastModidfiedOn
		 */
		public String getLastModidfiedOn() {
			return lastModidfiedOn;
		}
		/**
		 * @param lastModidfiedOn the lastModidfiedOn to set
		 */
		public void setLastModidfiedOn(String lastModidfiedOn) {
			this.lastModidfiedOn = lastModidfiedOn;
		}
		/**
		 * @return the statusCd
		 */
		public String getStatusCd() {
			return statusCd;
		}
		/**
		 * @param statusCd the statusCd to set
		 */
		public void setStatusCd(String statusCd) {
			this.statusCd = statusCd;
		}
		
		
		
	}
}