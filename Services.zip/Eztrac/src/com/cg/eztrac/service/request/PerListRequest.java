package com.cg.eztrac.service.request;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.domain.PerDO;

@Component(value="perListRequest")
public class PerListRequest extends PerDO implements IRestServiceRequest {

	private String channel;
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	@Override
	public String getChannelId() {
		return null;
	}
	
}
