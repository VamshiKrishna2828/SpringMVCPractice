package com.cg.eztrac.service.domainobject;

public class TimeSheetDetailDO {

	private Integer timeSheetId;
	private String workDate;
	private int hoursWorked;
	private int buildId;
	private int taskId;
	private int subTaskId;
	private int approvedBy;
	private String approvedOn;
	private String comments;
	private boolean onsiteFlag;
	private boolean favouriteFlag;
	private	int perId;
	private	String perNumber;
	private String perDesc;
	private String updateFlag;
	private String subSystemName;
	private	int subSytemId;
	private String readOnlyFlag;
	private String statusCode;
	
	
	public Integer getTimeSheetId() {
		return timeSheetId;
	}
	public void setTimeSheetId(Integer timeSheetId) {
		this.timeSheetId = timeSheetId;
	}
	/**
	 * @return the workDate
	 */
	public String getWorkDate() {
		return workDate;
	}
	/**
	 * @param workDate the workDate to set
	 */
	public void setWorkDate(String workDate) {
		this.workDate = workDate;
	}
	/**
	 * @return the buildId
	 */
	public int getBuildId() {
		return buildId;
	}
	/**
	 * @param buildId the buildId to set
	 */
	public void setBuildId(int buildId) {
		this.buildId = buildId;
	}
	/**
	 * @return the taskId
	 */
	public int getTaskId() {
		return taskId;
	}
	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}
	/**
	 * @return the subTaskId
	 */
	public int getSubTaskId() {
		return subTaskId;
	}
	/**
	 * @param subTaskId the subTaskId to set
	 */
	public void setSubTaskId(int subTaskId) {
		this.subTaskId = subTaskId;
	}
	/**
	 * @return the hoursWorked
	 */
	public int getHoursWorked() {
		return hoursWorked;
	}
	/**
	 * @param hoursWorked the hoursWorked to set
	 */
	public void setHoursWorked(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	/**
	 * @return the approvedBy
	 */
	public int getApprovedBy() {
		return approvedBy;
	}
	/**
	 * @param approvedBy the approvedBy to set
	 */
	public void setApprovedBy(int approvedBy) {
		this.approvedBy = approvedBy;
	}
	/**
	 * @return the approvedOn
	 */
	public String getApprovedOn() {
		return approvedOn;
	}
	/**
	 * @param approvedOn the approvedOn to set
	 */
	public void setApprovedOn(String approvedOn) {
		this.approvedOn = approvedOn;
	}
	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}
	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}
	/**
	 * @return the onsiteFlag
	 */
	public boolean getOnsiteFlag() {
		return onsiteFlag;
	}
	/**
	 * @param onsiteFlag the onsiteFlag to set
	 */
	public void setOnsiteFlag(boolean onsiteFlag) {
		this.onsiteFlag = onsiteFlag;
	}
	/**
	 * @return the favouriteFlag
	 */
	public boolean getFavouriteFlag() {
		return favouriteFlag;
	}
	/**
	 * @param favouriteFlag the favouriteFlag to set
	 */
	public void setFavouriteFlag(boolean favouriteFlag) {
		this.favouriteFlag = favouriteFlag;
	}
	/**
	 * @return the perId
	 */
	public int getPerId() {
		return perId;
	}
	/**
	 * @param perId the perId to set
	 */
	public void setPerId(int perId) {
		this.perId = perId;
	}
	/**
	 * @return the perNumber
	 */
	public String getPerNumber() {
		return perNumber;
	}
	/**
	 * @param perNumber the perNumber to set
	 */
	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}
	/**
	 * @return the perDesc
	 */
	public String getPerDesc() {
		return perDesc;
	}
	/**
	 * @param perDesc the perDesc to set
	 */
	public void setPerDesc(String perDesc) {
		this.perDesc = perDesc;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TimeSheetDetailDO [timeSheetId=" + timeSheetId + ", workDate=" + workDate + ", hoursWorked="
				+ hoursWorked + ", buildId=" + buildId + ", taskId=" + taskId + ", subTaskId=" + subTaskId
				+ ", approvedBy=" + approvedBy + ", approvedOn=" + approvedOn + ", comments=" + comments
				+ ", onsiteFlag=" + onsiteFlag + ", favouriteFlag=" + favouriteFlag + ", perId=" + perId
				+ ", perNumber=" + perNumber + ", perDesc=" + perDesc + "]";
	}
	/**
	 * @return the updateFlag
	 */
	public String getUpdateFlag() {
		return updateFlag;
	}
	/**
	 * @param updateFlag the updateFlag to set
	 */
	public void setUpdateFlag(String updateFlag) {
		this.updateFlag = updateFlag;
	}
	/**
	 * @return the subSystemName
	 */
	public String getSubSystemName() {
		return subSystemName;
	}
	/**
	 * @param subSystemName the subSystemName to set
	 */
	public void setSubSystemName(String subSystemName) {
		this.subSystemName = subSystemName;
	}
	/**
	 * @return the subSytemId
	 */
	public int getSubSytemId() {
		return subSytemId;
	}
	/**
	 * @param subSytemId the subSytemId to set
	 */
	public void setSubSytemId(int subSytemId) {
		this.subSytemId = subSytemId;
	}
	/**
	 * @return the readOnlyFlag
	 */
	public String getReadOnlyFlag() {
		return readOnlyFlag;
	}
	/**
	 * @param readOnlyFlag the readOnlyFlag to set
	 */
	public void setReadOnlyFlag(String readOnlyFlag) {
		this.readOnlyFlag = readOnlyFlag;
	}
	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}
	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
}