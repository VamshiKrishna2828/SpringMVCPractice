package com.cg.eztrac.service.domainobject;

public class SubSystemDO {

	private int subSystemID;
	private String subSystemName;
	private String subSystemTech;
	private String subSystemEmail;
	
	/**
	 * @return the subSystemID
	 */
	public int getSubSystemID() {
		return subSystemID;
	}
	/**
	 * @param subSystemID the subSystemID to set
	 */
	public void setSubSystemID(int subSystemID) {
		this.subSystemID = subSystemID;
	}
	/**
	 * @return the subSystemName
	 */
	public String getSubSystemName() {
		return subSystemName;
	}
	/**
	 * @param subSystemName the subSystemName to set
	 */
	public void setSubSystemName(String subSystemName) {
		this.subSystemName = subSystemName;
	}
	/**
	 * @return the subSystemTech
	 */
	public String getSubSystemTech() {
		return subSystemTech;
	}
	/**
	 * @param subSystemTech the subSystemTech to set
	 */
	public void setSubSystemTech(String subSystemTech) {
		this.subSystemTech = subSystemTech;
	}
	/**
	 * @return the subSystemEmail
	 */
	public String getSubSystemEmail() {
		return subSystemEmail;
	}
	/**
	 * @param subSystemEmail the subSystemEmail to set
	 */
	public void setSubSystemEmail(String subSystemEmail) {
		this.subSystemEmail = subSystemEmail;
	}
	
}