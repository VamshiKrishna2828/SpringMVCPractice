package com.cg.eztrac.service.domainobject;

public class TimeSheetHeaderDO {

	private String perNumber;
	private int loeOnsite;
	private int loeOffshore;
	private int loeOnsiteConsumed;
	private int loeOffshoreConsumed;
	private String invoiceCutOffDate;
	
	public String getPerNumber() {
		return perNumber;
	}
	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}
	public int getLoeOnsite() {
		return loeOnsite;
	}
	public void setLoeOnsite(int loeOnsite) {
		this.loeOnsite = loeOnsite;
	}
	public int getLoeOffshore() {
		return loeOffshore;
	}
	public void setLoeOffshore(int loeOffshore) {
		this.loeOffshore = loeOffshore;
	}
	public int getLoeOnsiteConsumed() {
		return loeOnsiteConsumed;
	}
	public void setLoeOnsiteConsumed(int loeOnsiteConsumed) {
		this.loeOnsiteConsumed = loeOnsiteConsumed;
	}
	public int getLoeOffshoreConsumed() {
		return loeOffshoreConsumed;
	}
	public void setLoeOffshoreConsumed(int loeOffshoreConsumed) {
		this.loeOffshoreConsumed = loeOffshoreConsumed;
	}
	
}