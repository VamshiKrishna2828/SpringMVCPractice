package com.cg.eztrac.service.domainobject;

public class BuildDO {

}
