package com.cg.eztrac.service;

import com.cg.eztrac.exception.CustomException;

public interface IServiceMandates {
	Object serviceProcessor(Object doObject, String action) throws CustomException;
	Object populateRequest(Object requestObject, String action) throws CustomException;
	Object invokeService(Object requestObject, String action) throws CustomException;
	Object populateResponse(Object responseObject, Object doObject, String action) throws CustomException;
}
