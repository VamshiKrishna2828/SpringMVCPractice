package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.InvoiceCutOffService;
import com.cg.eztrac.service.impl.InvoiceCutOffServiceImpl;
import com.cg.eztrac.service.request.InvoiceCutOffRequest;
import com.cg.eztrac.service.response.InvoiceCutOffDetail;
import com.cg.eztrac.service.response.InvoiceCutOffResponse;
import com.google.gson.Gson;

public class InvoiceDO {
	String className="InvoiceDO";
	
	private int invoiceYear;
	private int invoiceMonth;
	private int invoiceDt;
	
	
	public int getInvoiceYear() {
		return invoiceYear;
	}
	public void setInvoiceYear(int invoiceYear) {
		this.invoiceYear = invoiceYear;
	}
	public int getInvoiceMonth() {
		return invoiceMonth;
	}
	public void setInvoiceMonth(int invoiceMonth) {
		this.invoiceMonth = invoiceMonth;
	}
	public int getInvoiceDt() {
		return invoiceDt;
	}
	public void setInvoiceDt(int invoiceDt) {
		this.invoiceDt = invoiceDt;
	}
	
	public  List<InvoiceDO> callSetInvoiceDateService(UserDO userDO)throws CustomException {
		 userDO = new UserDO(); 
		 List<InvoiceDO> invoiceDoList = null;
		 InvoiceCutOffRequest invoiceCutOffRequest = populateDOToInvoiceRequest(userDO);
		 InvoiceCutOffService invoiceImpl = new InvoiceCutOffServiceImpl();
		 InvoiceCutOffResponse  invoiceCutOffResponse = invoiceImpl.invoiceService(invoiceCutOffRequest);
		 if(null!=invoiceCutOffResponse) {
			 List<InvoiceCutOffDetail>  invoiceCutOffResponseList=invoiceCutOffResponse.getInvoiceCutOffDetail();
			 invoiceDoList = populateInvoiceResponseToDO(invoiceCutOffResponseList,userDO);
			
		 }
		 //List<InvoiceCutOffResponse>  invoiceCutOffResponse = invoiceImpl.invoiceService(invoiceCutOffRequest);
		 return invoiceDoList;
		 
	}
	
	/** forming LoginRequest ( userDO -> request) */
	private InvoiceCutOffRequest populateDOToInvoiceRequest(UserDO userDO) {
		String methodName="populateDOToInvoiceRequest";
		InvoiceCutOffRequest invoiceCutOffRequest = new InvoiceCutOffRequest();
		try {
			invoiceCutOffRequest.setSubAccountId(1);
			invoiceCutOffRequest.setTokenId(userDO.getTokenId());
		} catch (CustomException e) {
		LoggerManager.writeErrorLog(className,methodName,e.getMessage(), e,"exception while setting the vslues to InvoiceRequest request");
		}
		return invoiceCutOffRequest;
	}
	
	
	/** forming InvoiceDO ( response-> DO) */
	private List<InvoiceDO> populateInvoiceResponseToDO(List<InvoiceCutOffDetail>  invoiceCutOffResponseList, UserDO userDO) {
		String methodName="populateInvoiceResponseToDO";
		if(null!=invoiceCutOffResponseList) {
			List<InvoiceDO> invoiceDOList=new ArrayList<InvoiceDO>(invoiceCutOffResponseList.size());
			InvoiceDO invoiceDO=new InvoiceDO();
			Gson gson = new Gson();
			for (int i=0;i<invoiceCutOffResponseList.size();i++){
				invoiceDO=new InvoiceDO();
				String invoiceJson= gson.toJson( invoiceCutOffResponseList.get(i));
				invoiceDO= gson.fromJson(invoiceJson, InvoiceDO.class);
				invoiceDOList.add(invoiceDO);
			}
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN+"In InvoiceResponseToDO", "InvoiceResponse populated to DO");
			return invoiceDOList;
		}
		else {
			return null;
		}
		
	/*	userDO = new UserDO();
		userDO.setInvoiceDt(invoiceCutOffResponse.getInvoiceDt());
		userDO.setInvoiceMonth(invoiceCutOffResponse.getInvoiceMonth());
		userDO.setInvoiceYear(invoiceCutOffResponse.getInvoiceYear());*/
		
		
	}
	
}
