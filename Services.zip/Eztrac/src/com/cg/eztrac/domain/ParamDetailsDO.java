package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.impl.OnLoadCommonServiceImpl;
import com.cg.eztrac.service.request.ParamDetailsRequest;
import com.cg.eztrac.service.response.ParamDetailsRes;
import com.cg.eztrac.service.response.ParamDetailsResponse;
import com.google.gson.Gson;

public class ParamDetailsDO {
	
	private static final String CLASS_NAME = ParamDetailsDO.class.getSimpleName();
	
	private Integer subAccountId;
	
	private String Status_CD;
	
	private Integer paramTypeID;
	
	private String paramTypeName;
	
	private List<ParamDO> paramValue;

	
	public Integer getSubAccountId() {
		return subAccountId;
	}

	public void setSubAccountId(Integer subAccountId) {
		this.subAccountId = subAccountId;
	}

	public String getStatus_CD() {
		return Status_CD;
	}

	public void setStatus_CD(String status_CD) {
		Status_CD = status_CD;
	}

	public Integer getParamTypeID() {
		return paramTypeID;
	}

	public void setParamTypeID(Integer paramTypeID) {
		this.paramTypeID = paramTypeID;
	}

	public String getParamTypeName() {
		return paramTypeName;
	}

	public void setParamTypeName(String paramTypeName) {
		this.paramTypeName = paramTypeName;
	}

	public List<ParamDO> getParamValue() {
		return paramValue;
	}

	public void setParamValue(List<ParamDO> paramValue) {
		this.paramValue = paramValue;
	}

	
	@Override
	public String toString() {
		return "ParamDetailsDO [subAccountId=" + subAccountId + ", Status_CD=" + Status_CD + ", paramTypeID="
				+ paramTypeID + ", paramTypeName=" + paramTypeName + ", paramValue=" + paramValue + "]";
	}

	public List<ParamDetailsDO> callParamDetailsService(ParamDetailsDO paramDetailsDO) {
		String methodName = "callParamDetailsService";
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "In ParamDetailsDO", "Going to invoke the service");
		OnLoadCommonService onLoadCommonService = new OnLoadCommonServiceImpl();
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "In ParamDetailsDO", "Before calling the getAllParamDetails() to get paramDetailsResponse");
		//List<ParamDetailsResponse> paramDetailsResponseList = onLoadCommonService.getAllParamDetails(populateParamDetailsRequest(paramDetailsDO));
		ParamDetailsRes paramDetailsRes = onLoadCommonService.getAllParamDetails(populateParamDetailsRequest(paramDetailsDO));
		List<ParamDetailsResponse> paramDetailsResponseList = paramDetailsRes.getParamDetail();
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "In ParamDetailsDO", "getAllParamDetails() is called and got paramDetailsResponse");
		List<ParamDetailsDO> paramDetailsDOList = getParamDetailsDOList(paramDetailsResponseList);
		LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "In ParamDetailsDO", "Retrieved paramDetailsDOList from paramDetailsResponse --> "+paramDetailsDOList);
		
		return paramDetailsDOList;
	}
	
	private ParamDetailsRequest populateParamDetailsRequest(ParamDetailsDO paramDetailsDO) {
		ParamDetailsRequest paramDetailsRequest = new ParamDetailsRequest();
		
		//TODO - Need to check this Later Starts
		paramDetailsRequest.setSubAccountId(paramDetailsDO.getSubAccountId());
		paramDetailsRequest.setStatus_CD(paramDetailsDO.getStatus_CD());
		
		LoggerManager.writeInfoLog(CLASS_NAME, "populateParamDetailsRequest", ICommonConstants.LOGIN_SERVICE_LOG_KEY + "In ParamDetailsDO", "paramDetailsRequest --> "+paramDetailsRequest.toString());
		
		return paramDetailsRequest;
	}
	
	private List<ParamDetailsDO> getParamDetailsDOList(List<ParamDetailsResponse> paramDetailsResponseList) {
		String methodName = "getParamDetailsDOList";
		List<ParamDetailsDO> paramDetailsDOList = null;
		try {
			if(null != paramDetailsResponseList && !paramDetailsResponseList.isEmpty()) {
				paramDetailsDOList = new ArrayList<ParamDetailsDO>(paramDetailsResponseList.size());
				Gson gson = new Gson();
				for (int i = 0 ; i < paramDetailsResponseList.size(); i++) {
					String paramDetailsDOJson = gson.toJson(paramDetailsResponseList.get(i));
					ParamDetailsDO paramDetailsDO = gson.fromJson(paramDetailsDOJson, ParamDetailsDO.class);
					LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "In ParamDetailsDO", "Setting ParamDetailsDO from paramDetailsResponse --> paramDetailsDO -->"+paramDetailsDO.toString());
					paramDetailsDOList.add(paramDetailsDO);
				}
				LoggerManager.writeInfoLog(CLASS_NAME, methodName, ICommonConstants.LOGIN_SERVICE_LOG_KEY + "In ParamDetailsDO", "Setting ParamDetailsDOList from paramDetailsResponse");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return paramDetailsDOList;
	}
	
}
