package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.List;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.service.OnLoadCommonService;
import com.cg.eztrac.service.impl.OnLoadCommonServiceImpl;
import com.cg.eztrac.service.request.PMDetailsRequest;
import com.cg.eztrac.service.request.PMODetailsRequest;
import com.cg.eztrac.service.request.SystemDetailsRequest;
import com.cg.eztrac.service.response.PMDetailsResponse;
import com.cg.eztrac.service.response.PMODetailsResponse;
import com.cg.eztrac.service.response.PMResponse;
import com.cg.eztrac.service.response.ResourceResponse;
import com.cg.eztrac.service.response.SystemDetailsResponse;
import com.cg.eztrac.service.response.SystemRes;
import com.google.gson.Gson;

public class PMDetailsDO {

	String className = PMDetailsDO.class.getSimpleName();
	private Integer userId;
	private String name;
	private String pmStatus;

	public List<PMDetailsDO> callPMDetailService(PMDetailsDO pmDetailsDO) {
		
		String methodName="callPMDetailService";
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.PM_DETAILS_SERVICE_LOG_KEY+"In callPMDetailService", "Before populating the pmDetailsRequest from DO");
		PMDetailsRequest pmDetailsRequest = populatePMRequestFromDO(pmDetailsDO);
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.PM_DETAILS_SERVICE_LOG_KEY+"In callPMDetailService", "Details are populated into pmDetailsRequest");
		
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.PM_DETAILS_SERVICE_LOG_KEY+"In callPMDetailService", "Before calling the getPMDetails() to get pmDetailResponseList ");
		OnLoadCommonService onLoadCommonServcie = new OnLoadCommonServiceImpl();
		PMResponse pmResponse = onLoadCommonServcie.getPMDetails(pmDetailsRequest);
		List<PMDetailsResponse> pmDetailsListResponse = pmResponse.getPm();
		LoggerManager.writeInfoLog(className,methodName,ICommonConstants.PM_DETAILS_SERVICE_LOG_KEY+"In callPMDetailService", "getPMDetails() is called and got pmDetailServiceResponseList");
		List<PMDetailsDO> pmDetailsDOList = populateResponseToDO(pmDetailsListResponse);
		return pmDetailsDOList;
	}

	private PMDetailsRequest populatePMRequestFromDO(PMDetailsDO pmDetailsDO) {
		String methodName = "populatePMRequestFromDO";
		PMDetailsRequest pmDetailsRequest = new PMDetailsRequest();
		pmDetailsRequest.setSubAccountId(1);
		LoggerManager.writeInfoLog(className, methodName, ICommonConstants.PM_DETAILS_SERVICE_LOG_KEY + "In populatePMRequestFromDO", "pmDetailsRequest populated from DO");
		
		return pmDetailsRequest;
	}

	private List<PMDetailsDO> populateResponseToDO(List<PMDetailsResponse> pmDetailResponseList) {
		String methodName="populateResponseToDO";
		List<PMDetailsDO> pmDetailsDOList = new ArrayList<PMDetailsDO>();
		
		try {
			PMDetailsDO pmDetailsDO = null;
			Gson gson = new Gson();
			for (int i = 0; i < pmDetailResponseList.size(); i++) {
				pmDetailsDO = new PMDetailsDO();
				String pmDetailDOJson = gson.toJson(pmDetailResponseList.get(i));
				pmDetailsDO = gson.fromJson(pmDetailDOJson, PMDetailsDO.class);
				pmDetailsDOList.add(pmDetailsDO);
			}
			LoggerManager.writeInfoLog(className, methodName,"In populateResponseToDO", "Setting PMDetailsDO from pmDetailsResponse");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return pmDetailsDOList;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPmStatus() {
		return pmStatus;
	}

	public void setPmStatus(String pmStatus) {
		this.pmStatus = pmStatus;
	}

}