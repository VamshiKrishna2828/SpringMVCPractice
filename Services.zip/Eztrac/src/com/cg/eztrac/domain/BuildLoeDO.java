package com.cg.eztrac.domain;

public class BuildLoeDO extends LoeDO {
	
	private String buildPlanningLOEEstimationDateString;
	private String buildExecutionLOEEstimationDateString;
	
	private Float buildTotalExecutionCCLOEReq;
	private Float buildTotalExecutionCCLOEDesign;
	private Float buildTotalExecutionCCLOECons;
	private Float buildTotalExecutionCCLOETest;
	private Float buildTotalExecutionCCLOERelease;
	
	public String getBuildPlanningLOEEstimationDateString() {
		return buildPlanningLOEEstimationDateString;
	}
	public void setBuildPlanningLOEEstimationDateString(String buildPlanningLOEEstimationDateString) {
		this.buildPlanningLOEEstimationDateString = buildPlanningLOEEstimationDateString;
	}
	public String getBuildExecutionLOEEstimationDateString() {
		return buildExecutionLOEEstimationDateString;
	}
	public void setBuildExecutionLOEEstimationDateString(String buildExecutionLOEEstimationDateString) {
		this.buildExecutionLOEEstimationDateString = buildExecutionLOEEstimationDateString;
	}
	public Float getBuildTotalExecutionCCLOEReq() {
		return buildTotalExecutionCCLOEReq;
	}
	public void setBuildTotalExecutionCCLOEReq(Float buildTotalExecutionCCLOEReq) {
		this.buildTotalExecutionCCLOEReq = buildTotalExecutionCCLOEReq;
	}
	public Float getBuildTotalExecutionCCLOEDesign() {
		return buildTotalExecutionCCLOEDesign;
	}
	public void setBuildTotalExecutionCCLOEDesign(Float buildTotalExecutionCCLOEDesign) {
		this.buildTotalExecutionCCLOEDesign = buildTotalExecutionCCLOEDesign;
	}
	public Float getBuildTotalExecutionCCLOECons() {
		return buildTotalExecutionCCLOECons;
	}
	public void setBuildTotalExecutionCCLOECons(Float buildTotalExecutionCCLOECons) {
		this.buildTotalExecutionCCLOECons = buildTotalExecutionCCLOECons;
	}
	public Float getBuildTotalExecutionCCLOETest() {
		return buildTotalExecutionCCLOETest;
	}
	public void setBuildTotalExecutionCCLOETest(Float buildTotalExecutionCCLOETest) {
		this.buildTotalExecutionCCLOETest = buildTotalExecutionCCLOETest;
	}
	public Float getBuildTotalExecutionCCLOERelease() {
		return buildTotalExecutionCCLOERelease;
	}
	public void setBuildTotalExecutionCCLOERelease(Float buildTotalExecutionCCLOERelease) {
		this.buildTotalExecutionCCLOERelease = buildTotalExecutionCCLOERelease;
	}
	@Override
	public String toString() {
		return "BuildLoeDO [buildPlanningLOEEstimationDateString=" + buildPlanningLOEEstimationDateString
				+ ", buildExecutionLOEEstimationDateString=" + buildExecutionLOEEstimationDateString
				+ ", buildTotalExecutionCCLOEReq=" + buildTotalExecutionCCLOEReq + ", buildTotalExecutionCCLOEDesign="
				+ buildTotalExecutionCCLOEDesign + ", buildTotalExecutionCCLOECons=" + buildTotalExecutionCCLOECons
				+ ", buildTotalExecutionCCLOETest=" + buildTotalExecutionCCLOETest
				+ ", buildTotalExecutionCCLOERelease=" + buildTotalExecutionCCLOERelease + "]";
	}
}
