package com.cg.eztrac.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.impl.BuildServiceImpl;
import com.cg.eztrac.service.impl.PerServiceImpl;

@Component(value="perDO")
public class PerDO extends EstimationDO{
	
	private static final String CLASS_NAME = PerDO.class.getSimpleName();
	
	@Autowired
	PerServiceImpl perServiceImpl;
	
	//General - Fields - Per Module
	
	private String currentPhaseEndDateString;
	private Integer[] managersToNotifyArray;
	private List<PMDetailsDO> itpmManagerList;
	private String parNumber;
	private String perReceiptDateString;
	private String projectComments;
	private Integer projectType;
	private String projectTypeName;
	private String status;
	
	//Schedule Updates - Fields - Per Module
	private String scheduleCallDateString;
	private String cancellationDateString;
	private String currentScheduleEndDateString;
	private String currentScheduleStartDateString;
	private String restartDateString;
	private String stopDateString;
	
	private PerChangeControlDO perChangeControl;
	private PerLoeDO perLoe;
	
	private List<PurchaseOrderDO> purchaseOrderList;
	private List<PerChangeControlDO> perChangeControlList;
	
	private BuildDO buildDO;
	
	public String getCurrentPhaseEndDateString() {
		return currentPhaseEndDateString;
	}
	public void setCurrentPhaseEndDateString(String currentPhaseEndDateString) {
		this.currentPhaseEndDateString = currentPhaseEndDateString;
	}
	public Integer[] getManagersToNotifyArray() {
		return managersToNotifyArray;
	}
	public void setManagersToNotifyArray(Integer[] managersToNotifyArray) {
		this.managersToNotifyArray = managersToNotifyArray;
	}
	public List<PMDetailsDO> getItpmManagerList() {
		return itpmManagerList;
	}
	public void setItpmManagerList(List<PMDetailsDO> itpmManagerList) {
		this.itpmManagerList = itpmManagerList;
	}
	public String getParNumber() {
		return parNumber;
	}
	public void setParNumber(String parNumber) {
		this.parNumber = parNumber;
	}
	public String getPerReceiptDateString() {
		return perReceiptDateString;
	}
	public void setPerReceiptDateString(String perReceiptDateString) {
		this.perReceiptDateString = perReceiptDateString;
	}
	public String getScheduleCallDateString() {
		return scheduleCallDateString;
	}
	public void setScheduleCallDateString(String scheduleCallDateString) {
		this.scheduleCallDateString = scheduleCallDateString;
	}
	public String getCancellationDateString() {
		return cancellationDateString;
	}
	public void setCancellationDateString(String cancellationDateString) {
		this.cancellationDateString = cancellationDateString;
	}
	public String getCurrentScheduleEndDateString() {
		return currentScheduleEndDateString;
	}
	public void setCurrentScheduleEndDateString(String currentScheduleEndDateString) {
		this.currentScheduleEndDateString = currentScheduleEndDateString;
	}
	public String getCurrentScheduleStartDateString() {
		return currentScheduleStartDateString;
	}
	public void setCurrentScheduleStartDateString(String currentScheduleStartDateString) {
		this.currentScheduleStartDateString = currentScheduleStartDateString;
	}
	public String getRestartDateString() {
		return restartDateString;
	}
	public void setRestartDateString(String restartDateString) {
		this.restartDateString = restartDateString;
	}
	public String getStopDateString() {
		return stopDateString;
	}
	public void setStopDateString(String stopDateString) {
		this.stopDateString = stopDateString;
	}
	public String getProjectComments() {
		return projectComments;
	}
	public void setProjectComments(String projectComments) {
		this.projectComments = projectComments;
	}
	public Integer getProjectType() {
		return projectType;
	}
	public void setProjectType(Integer projectType) {
		this.projectType = projectType;
	}
	public String getProjectTypeName() {
		return projectTypeName;
	}
	public void setProjectTypeName(String projectTypeName) {
		this.projectTypeName = projectTypeName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public PerChangeControlDO getPerChangeControl() {
		return perChangeControl;
	}
	public void setPerChangeControl(PerChangeControlDO perChangeControl) {
		this.perChangeControl = perChangeControl;
	}
	public PerLoeDO getPerLoe() {
		return perLoe;
	}
	public void setPerLoe(PerLoeDO perLoe) {
		this.perLoe = perLoe;
	}
	public List<PurchaseOrderDO> getPurchaseOrderList() {
		return purchaseOrderList;
	}
	public void setPurchaseOrderList(List<PurchaseOrderDO> purchaseOrderList) {
		this.purchaseOrderList = purchaseOrderList;
	}
	public List<PerChangeControlDO> getPerChangeControlList() {
		return perChangeControlList;
	}
	public void setPerChangeControlList(List<PerChangeControlDO> perChangeControlList) {
		this.perChangeControlList = perChangeControlList;
	}
	
	public BuildDO getBuildDO() {
		return buildDO;
	}
	public void setBuildDO(BuildDO buildDO) {
		this.buildDO = buildDO;
	}
	

	public void getBuildList(BuildListDO buildListDO) throws CustomException {
		final String METHOD_NAME = "getBuildList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.getBuildList()", "");
		
		BuildServiceImpl buildServiceImpl = new BuildServiceImpl();
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling BuildList BuildServiceImpl", "Start");
			buildListDO = (BuildListDO) buildServiceImpl.serviceProcessor(buildListDO, ICommonConstants.LIST_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from BuildList BuildServiceImpl", "End");
		}
		catch (CustomException e) {
			System.out.println("PERDO catch block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildList Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from PerDO.getBuildList()", "");
	}

	public void getBuildDetails(BuildDO buildDO) throws CustomException {
		final String METHOD_NAME = "getBuildDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.getBuildDetails()", "");
		
		BuildServiceImpl buildServiceImpl = new BuildServiceImpl();
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling BuildDetails BuildServiceImpl", "Start");
			buildDO = (BuildDO)buildServiceImpl.serviceProcessor(buildDO, ICommonConstants.DETAILS_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from BuildDetails BuildServiceImpl", "End");
			this.setBuildDO(buildDO);
		}
		catch (CustomException e) {
			System.out.println("BuildDO - getBuildDetails Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildDetails Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from PerDO.getBuildDetails()", "");
	}
	
	public void insertBuildDetails(BuildDO buildDO) throws CustomException {
		final String METHOD_NAME = "insertBuildDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.insertBuildDetails()", "");
		
		BuildServiceImpl buildServiceImpl = new BuildServiceImpl();
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling BuildDetails BuildServiceImpl", "Start");
			buildDO = (BuildDO)buildServiceImpl.serviceProcessor(buildDO, ICommonConstants.INSERT_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from BuildDetails BuildServiceImpl", "End");
			this.setBuildDO(buildDO);
		}
		catch (CustomException e) {
			System.out.println("PerDO - InsertBuildDetails Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "buildInsert Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from  PerDO.insertBuildDetails()", "");
	}
	
	public void deleteBuild(BuildDO buildDO) throws CustomException {
		final String METHOD_NAME = "deleteBuild";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.deleteBuild()", "");
		
		BuildServiceImpl buildServiceImpl = new BuildServiceImpl();
		
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling BuildDelete BuildServiceImpl", "Start");
			buildDO = (BuildDO)buildServiceImpl.serviceProcessor(buildDO, ICommonConstants.DELETE_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from BuildDelete BuildServiceImpl", "End");
			this.setBuildDO(buildDO);
		}
		catch (CustomException e) {
			System.out.println("PerDO - deleteBuild Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "BuildDelete Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Return from  PerDO.deleteBuild()", "");
	}
	
	public void insertPerCCDetails(PerDO perDO) throws CustomException {
		final String METHOD_NAME = "insertPerCCDetails";
		PerServiceImpl perServiceImpl = new PerServiceImpl();
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.insertPerCCDetails:", "Before Invoking Insert Request");
		
		try {
			//perDO = (perDO)perServiceImpl.serviceProcessor(perDO, ICommonConstants.PER_CC_INSERT_REQUEST_ACTION);
		}
		catch (CustomException e) {
			System.out.println("PerDO - insertPerCCDetails Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "perCcInsertResponse Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
		
	}

}
