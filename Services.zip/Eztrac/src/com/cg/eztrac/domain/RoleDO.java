package com.cg.eztrac.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.service.impl.PerServiceImpl;

@Component(value="roleDO")
public class RoleDO {
	
	private String CLASS_NAME = "RoleDO";
	
	private Integer roleId;
	private String roleName;
	List<RolePermissionDO> RolePermissionList = new ArrayList<RolePermissionDO>();
	private PerDO perDO;
	
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public List<RolePermissionDO> getRolePermissionList() {
		return RolePermissionList;
	}
	public void setRolePermissionList(List<RolePermissionDO> rolePermissionList) {
		RolePermissionList = rolePermissionList;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public PerDO getPerDO() {
		return perDO;
	}
	public void setPerDO(PerDO perDO) {
		this.perDO = perDO;
	}
	
	public void getPerList(PerListDO perListDO) throws CustomException {
		final String METHOD_NAME = "getPerList";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside RoleDO.getPerList()", "");
		
		PerServiceImpl perServiceImpl = new PerServiceImpl();
		try{
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling PerList PerServiceImpl", "Start");
			perListDO = (PerListDO)perServiceImpl.serviceProcessor(perListDO, ICommonConstants.LIST_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from PerList PerServiceImpl", "End");
		}
		catch(CustomException e){
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per List  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
	}
	
	public void getPerDetails(PerDO perDO) throws CustomException {
		final String METHOD_NAME = "getPerDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.getPerDetails()", "");
		
		PerServiceImpl perServiceImpl = new PerServiceImpl();
		try{
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling PerDetails PerServiceImpl", "Start");
			perDO = (PerDO) perServiceImpl.serviceProcessor(perDO, ICommonConstants.DETAILS_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from PerDetails PerServiceImpl", "End");
			this.setPerDO(perDO);
		}
		catch(CustomException e){
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per Details  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
	}
	
	public void insertPerDetails(PerDO perDO) throws CustomException {
		final String METHOD_NAME = "insertPerDetails";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.insertPerDetails()", "");
		
		PerServiceImpl perServiceImpl = new PerServiceImpl();
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling InsertPer PerServiceImpl", "Start");
			perDO = (PerDO)perServiceImpl.serviceProcessor(perDO, ICommonConstants.INSERT_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from InsertPer PerServiceImpl", "End");
			this.setPerDO(perDO);
		}
		catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "Per Insert  Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
	}
	
	public void deletePer(PerDO perDO) throws CustomException {
		final String METHOD_NAME = "deletePer";
		LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Inside PerDO.deletePer()", "");
		
		PerServiceImpl perServiceImpl = new PerServiceImpl();
		try {
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "Before Calling DeletePer PerServiceImpl", "Start");
			perDO = (PerDO)perServiceImpl.serviceProcessor(perDO, ICommonConstants.DELETE_REQUEST_ACTION);
			LoggerManager.writeInfoLog(CLASS_NAME, METHOD_NAME, "After returning from DeletePer PerServiceImpl", "End");
			this.setPerDO(perDO);
		}
		catch (CustomException e) {
			System.out.println("RoleDO - deletePer Catch Block");
			e.printStackTrace();
			LoggerManager.writeErrorLog(CLASS_NAME, METHOD_NAME, "DeletePer Exception", e, "");
			throw new CustomException(e.getErrCode(),e.getErrMsg());
		}
	}
	
}
