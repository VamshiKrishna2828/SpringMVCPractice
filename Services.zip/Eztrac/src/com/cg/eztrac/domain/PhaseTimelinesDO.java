package com.cg.eztrac.domain;

public class PhaseTimelinesDO {
	
	private String plannedReqEndDateString;
	private String plannedReqStartDateString;
	private String plannedDesignEndDateString;
	private String plannedDesignStartDateString;
	private String plannedConEndDateString;
	private String plannedConStartDateString;
	private String plannedTestingEndDateString;
	private String plannedTestingStartDateString;
	private String plannedReleaseEndDateString;
	private String plannedReleaseStartDateString;
	
	private String actualReqEndDateString;
	private String actualReqStartDateString;
	private String actualDesignEndDateString;
	private String actualDesignStartDateString;
	private String actualConEndDateString;
	private String actualConStartDateString;
	private String actualTestingEndDateString;
	private String actualTestingStartDateString;
	private String actualReleaseEndDateString;
	private String actualReleaseStartDateString;
	
	
	public String getPlannedReqEndDateString() {
		return plannedReqEndDateString;
	}


	public void setPlannedReqEndDateString(String plannedReqEndDateString) {
		this.plannedReqEndDateString = plannedReqEndDateString;
	}


	public String getPlannedReqStartDateString() {
		return plannedReqStartDateString;
	}


	public void setPlannedReqStartDateString(String plannedReqStartDateString) {
		this.plannedReqStartDateString = plannedReqStartDateString;
	}


	public String getPlannedDesignEndDateString() {
		return plannedDesignEndDateString;
	}


	public void setPlannedDesignEndDateString(String plannedDesignEndDateString) {
		this.plannedDesignEndDateString = plannedDesignEndDateString;
	}


	public String getPlannedDesignStartDateString() {
		return plannedDesignStartDateString;
	}


	public void setPlannedDesignStartDateString(String plannedDesignStartDateString) {
		this.plannedDesignStartDateString = plannedDesignStartDateString;
	}


	public String getPlannedConEndDateString() {
		return plannedConEndDateString;
	}


	public void setPlannedConEndDateString(String plannedConEndDateString) {
		this.plannedConEndDateString = plannedConEndDateString;
	}


	public String getPlannedConStartDateString() {
		return plannedConStartDateString;
	}


	public void setPlannedConStartDateString(String plannedConStartDateString) {
		this.plannedConStartDateString = plannedConStartDateString;
	}


	public String getPlannedTestingEndDateString() {
		return plannedTestingEndDateString;
	}


	public void setPlannedTestingEndDateString(String plannedTestingEndDateString) {
		this.plannedTestingEndDateString = plannedTestingEndDateString;
	}


	public String getPlannedTestingStartDateString() {
		return plannedTestingStartDateString;
	}


	public void setPlannedTestingStartDateString(String plannedTestingStartDateString) {
		this.plannedTestingStartDateString = plannedTestingStartDateString;
	}


	public String getPlannedReleaseEndDateString() {
		return plannedReleaseEndDateString;
	}


	public void setPlannedReleaseEndDateString(String plannedReleaseEndDateString) {
		this.plannedReleaseEndDateString = plannedReleaseEndDateString;
	}


	public String getPlannedReleaseStartDateString() {
		return plannedReleaseStartDateString;
	}


	public void setPlannedReleaseStartDateString(String plannedReleaseStartDateString) {
		this.plannedReleaseStartDateString = plannedReleaseStartDateString;
	}


	public String getActualReqEndDateString() {
		return actualReqEndDateString;
	}


	public void setActualReqEndDateString(String actualReqEndDateString) {
		this.actualReqEndDateString = actualReqEndDateString;
	}


	public String getActualReqStartDateString() {
		return actualReqStartDateString;
	}


	public void setActualReqStartDateString(String actualReqStartDateString) {
		this.actualReqStartDateString = actualReqStartDateString;
	}


	public String getActualDesignEndDateString() {
		return actualDesignEndDateString;
	}


	public void setActualDesignEndDateString(String actualDesignEndDateString) {
		this.actualDesignEndDateString = actualDesignEndDateString;
	}


	public String getActualDesignStartDateString() {
		return actualDesignStartDateString;
	}


	public void setActualDesignStartDateString(String actualDesignStartDateString) {
		this.actualDesignStartDateString = actualDesignStartDateString;
	}


	public String getActualConEndDateString() {
		return actualConEndDateString;
	}


	public void setActualConEndDateString(String actualConEndDateString) {
		this.actualConEndDateString = actualConEndDateString;
	}


	public String getActualConStartDateString() {
		return actualConStartDateString;
	}


	public void setActualConStartDateString(String actualConStartDateString) {
		this.actualConStartDateString = actualConStartDateString;
	}


	public String getActualTestingEndDateString() {
		return actualTestingEndDateString;
	}


	public void setActualTestingEndDateString(String actualTestingEndDateString) {
		this.actualTestingEndDateString = actualTestingEndDateString;
	}


	public String getActualTestingStartDateString() {
		return actualTestingStartDateString;
	}


	public void setActualTestingStartDateString(String actualTestingStartDateString) {
		this.actualTestingStartDateString = actualTestingStartDateString;
	}


	public String getActualReleaseEndDateString() {
		return actualReleaseEndDateString;
	}


	public void setActualReleaseEndDateString(String actualReleaseEndDateString) {
		this.actualReleaseEndDateString = actualReleaseEndDateString;
	}


	public String getActualReleaseStartDateString() {
		return actualReleaseStartDateString;
	}


	public void setActualReleaseStartDateString(String actualReleaseStartDateString) {
		this.actualReleaseStartDateString = actualReleaseStartDateString;
	}


	@Override
	public String toString() {
		return "PhaseTimelinesDO [plannedReqEndDateString=" + plannedReqEndDateString + ", plannedReqStartDateString="
				+ plannedReqStartDateString + ", plannedDesignEndDateString=" + plannedDesignEndDateString
				+ ", plannedDesignStartDateString=" + plannedDesignStartDateString + ", plannedConEndDateString="
				+ plannedConEndDateString + ", plannedConStartDateString=" + plannedConStartDateString
				+ ", plannedTestingEndDateString=" + plannedTestingEndDateString + ", plannedTestingStartDateString="
				+ plannedTestingStartDateString + ", plannedReleaseEndDateString=" + plannedReleaseEndDateString
				+ ", plannedReleaseStartDateString=" + plannedReleaseStartDateString + ", actualReqEndDateString="
				+ actualReqEndDateString + ", actualReqStartDateString=" + actualReqStartDateString
				+ ", actualDesignEndDateString=" + actualDesignEndDateString + ", actualDesignStartDateString="
				+ actualDesignStartDateString + ", actualConEndDateString=" + actualConEndDateString
				+ ", actualConStartDateString=" + actualConStartDateString + ", actualTestingEndDateString="
				+ actualTestingEndDateString + ", actualTestingStartDateString=" + actualTestingStartDateString
				+ ", actualReleaseEndDateString=" + actualReleaseEndDateString + ", actualReleaseStartDateString="
				+ actualReleaseStartDateString + "]";
	}
	
	
	
}
