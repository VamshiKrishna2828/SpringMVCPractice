package com.cg.eztrac.domain;

import java.util.List;

import org.springframework.stereotype.Component;

@Component(value="perListDO")
public class PerListDO extends EstimationListDO{
	
	private PerDO per;
	private List<PerDO> perList;
	public PerDO getPer() {
		return per;
	}
	public void setPer(PerDO per) {
		this.per = per;
	}
	public List<PerDO> getPerList() {
		return perList;
	}
	public void setPerList(List<PerDO> perList) {
		this.perList = perList;
	}
	
}
