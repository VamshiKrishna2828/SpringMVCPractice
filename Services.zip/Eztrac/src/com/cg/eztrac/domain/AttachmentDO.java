package com.cg.eztrac.domain;

import java.util.Date;

public class AttachmentDO {
	
	private String url;
	private String remarks;
	private String createdBy;
	private String createdOnString;
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOnString() {
		return createdOnString;
	}
	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}
	@Override
	public String toString() {
		return "AttachmentDO [url=" + url + ", remarks=" + remarks + ", createdBy=" + createdBy + ", createdOnString="
				+ createdOnString + "]";
	}
}
