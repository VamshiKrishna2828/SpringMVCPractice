package com.cg.eztrac.domain;

import java.util.Date;

public class BuildChangeControlDO extends ChangeControlDO {
	
	private int buildCCId;
	private String buildCCDescription;
	private String buildCCComments;
	private int buildCCReqLoe;
	private int buildCCDesignLoe;
	private int buildCCConLoe;
	private int buildCCTestingLoe;
	private int buildCCReleaseLoe;
	private Date buildCCEstimationDate;
	
	public int getBuildCCId() {
		return buildCCId;
	}
	public void setBuildCCId(int buildCCId) {
		this.buildCCId = buildCCId;
	}
	public String getBuildCCDescription() {
		return buildCCDescription;
	}
	public void setBuildCCDescription(String buildCCDescription) {
		this.buildCCDescription = buildCCDescription;
	}
	public String getBuildCCComments() {
		return buildCCComments;
	}
	public void setBuildCCComments(String buildCCComments) {
		this.buildCCComments = buildCCComments;
	}
	public int getBuildCCReqLoe() {
		return buildCCReqLoe;
	}
	public void setBuildCCReqLoe(int buildCCReqLoe) {
		this.buildCCReqLoe = buildCCReqLoe;
	}
	public int getBuildCCDesignLoe() {
		return buildCCDesignLoe;
	}
	public void setBuildCCDesignLoe(int buildCCDesignLoe) {
		this.buildCCDesignLoe = buildCCDesignLoe;
	}
	public int getBuildCCConLoe() {
		return buildCCConLoe;
	}
	public void setBuildCCConLoe(int buildCCConLoe) {
		this.buildCCConLoe = buildCCConLoe;
	}
	public int getBuildCCTestingLoe() {
		return buildCCTestingLoe;
	}
	public void setBuildCCTestingLoe(int buildCCTestingLoe) {
		this.buildCCTestingLoe = buildCCTestingLoe;
	}
	public int getBuildCCReleaseLoe() {
		return buildCCReleaseLoe;
	}
	public void setBuildCCReleaseLoe(int buildCCReleaseLoe) {
		this.buildCCReleaseLoe = buildCCReleaseLoe;
	}
	public Date getBuildCCEstimationDate() {
		return buildCCEstimationDate;
	}
	public void setBuildCCEstimationDate(Date buildCCEstimationDate) {
		this.buildCCEstimationDate = buildCCEstimationDate;
	}
	
	@Override
	public String toString() {
		return "BuildChangeControlDO [buildCCId=" + buildCCId + ", buildCCDescription=" + buildCCDescription
				+ ", buildCCComments=" + buildCCComments + ", buildCCReqLoe=" + buildCCReqLoe + ", buildCCDesignLoe="
				+ buildCCDesignLoe + ", buildCCConLoe=" + buildCCConLoe + ", buildCCTestingLoe=" + buildCCTestingLoe
				+ ", buildCCReleaseLoe=" + buildCCReleaseLoe + ", buildCCEstimationDate=" + buildCCEstimationDate + "]";
	}
	
}
