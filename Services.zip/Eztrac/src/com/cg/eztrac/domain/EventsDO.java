package com.cg.eztrac.domain;

public class EventsDO {
	

}
