package com.cg.eztrac.domain;

public class PurchaseOrderDO {
	
	private String poNumber;
	private Double poAmount;
	private String createdBy;
	private String createdOnString;
	
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public Double getPoAmount() {
		return poAmount;
	}
	public void setPoAmount(Double poAmount) {
		this.poAmount = poAmount;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOnString() {
		return createdOnString;
	}
	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}
	@Override
	public String toString() {
		return "PurchaseOrderDO [poNumber=" + poNumber + ", poAmount=" + poAmount + ", createdBy=" + createdBy
				+ ", createdOnString=" + createdOnString + "]";
	}
}
