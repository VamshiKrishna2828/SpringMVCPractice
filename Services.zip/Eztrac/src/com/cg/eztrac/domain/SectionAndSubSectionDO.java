package com.cg.eztrac.domain;

public class SectionAndSubSectionDO {
	Integer subSectionID;
	Integer subSectionType;
	String subSectionName;
	Integer sectionID;
	Integer sectionType;
	String sectionName;
	//SectionDetail section;
	public Integer getSubSectionType() {
		return subSectionType;
	}
	public void setSubSectionType(Integer subSectionType) {
		this.subSectionType = subSectionType;
	}
	public Integer getSubSectionID() {
		return subSectionID;
	}
	public void setSubSectionID(Integer subSectionID) {
		this.subSectionID = subSectionID;
	}
	public String getSubSectionName() {
		return subSectionName;
	}
	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}
/*	public SectionDetail getSection() {
		return section;
	}
	public void setSection(SectionDetail section) {
		this.section = section;
	}*/
	public Integer getSectionID() {
		return sectionID;
	}
	public void setSectionID(Integer sectionID) {
		this.sectionID = sectionID;
	}
	public Integer getSectionType() {
		return sectionType;
	}
	public void setSectionType(Integer sectionType) {
		this.sectionType = sectionType;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

}
