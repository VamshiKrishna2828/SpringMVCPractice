package com.cg.eztrac.vo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class PerVO extends EstimationVO {
	
	//General - Fields - Per Module
	
	private String currentPhaseEndDateString;
	private Date currentPhaseEndDate;
	String managersToNotify;
	private Integer[] managersToNotifyArray;
	private List<PMDetailsVO> managersList;
	private List<PMDetailsVO> itpmManagerList;
	private String parNumber;
	private String perReceiptDateString;
	private Date perReceiptDate;
	private String projectComments;
	private Integer projectType;
	private String projectTypeName;
	
	
	//Schedule Updates - Fields - Per Module
	private String scheduleCallDateString;
	private Date scheduleCallDate;
	private String cancellationDateString;
	private Date cancellationDate;
	private String currentScheduleEndDateString;
	private Date currentScheduleEndDate;
	private String currentScheduleStartDateString;
	private Date currentScheduleStartDate;
	private String restartDateString;
	private Date restartDate;
	private String stopDateString;
	private Date stopDate;
	
	private PerChangeControlVO perChangeControl;
	private PerLoeVO perLoe;
	
	private List<PurchaseOrderVO> purchaseOrderList;
	private List<PerChangeControlVO> perChangeControlList;
	
	public String getCurrentPhaseEndDateString() {
		return currentPhaseEndDateString;
	}
	public void setCurrentPhaseEndDateString(String currentPhaseEndDateString) {
		this.currentPhaseEndDateString = currentPhaseEndDateString;
	}
	public Date getCurrentPhaseEndDate() {
		return currentPhaseEndDate;
	}
	public void setCurrentPhaseEndDate(Date currentPhaseEndDate) {
		this.currentPhaseEndDate = currentPhaseEndDate;
	}
	
	public String getManagersToNotify() {
		return managersToNotify;
	}
	public void setManagersToNotify(String managersToNotify) {
		this.managersToNotify = managersToNotify;
	}
	public Integer[] getManagersToNotifyArray() {
		return managersToNotifyArray;
	}
	public void setManagersToNotifyArray(Integer[] managersToNotifyArray) {
		this.managersToNotifyArray = managersToNotifyArray;
	}
	public List<PMDetailsVO> getManagersList() {
		return managersList;
	}
	public void setManagersList(List<PMDetailsVO> managersList) {
		this.managersList = managersList;
	}
	
	public List<PMDetailsVO> getItpmManagerList() {
		return itpmManagerList;
	}
	public void setItpmManagerList(List<PMDetailsVO> itpmManagerList) {
		this.itpmManagerList = itpmManagerList;
	}
	public String getParNumber() {
		return parNumber;
	}
	public void setParNumber(String parNumber) {
		this.parNumber = parNumber;
	}
	public String getPerReceiptDateString() {
		return perReceiptDateString;
	}
	public void setPerReceiptDateString(String perReceiptDateString) {
		this.perReceiptDateString = perReceiptDateString;
	}
	public Date getPerReceiptDate() {
		return perReceiptDate;
	}
	public void setPerReceiptDate(Date perReceiptDate) {
		this.perReceiptDate = perReceiptDate;
	}
	public String getProjectComments() {
		return projectComments;
	}
	public void setProjectComments(String projectComments) {
		this.projectComments = projectComments;
	}
	public Integer getProjectType() {
		return projectType;
	}
	public void setProjectType(Integer projectType) {
		this.projectType = projectType;
	}
	public String getProjectTypeName() {
		return projectTypeName;
	}
	public void setProjectTypeName(String projectTypeName) {
		this.projectTypeName = projectTypeName;
	}
	public String getScheduleCallDateString() {
		return scheduleCallDateString;
	}
	public void setScheduleCallDateString(String scheduleCallDateString) {
		this.scheduleCallDateString = scheduleCallDateString;
	}
	public Date getScheduleCallDate() {
		return scheduleCallDate;
	}
	public void setScheduleCallDate(Date scheduleCallDate) {
		this.scheduleCallDate = scheduleCallDate;
	}
	public String getCancellationDateString() {
		return cancellationDateString;
	}
	public void setCancellationDateString(String cancellationDateString) {
		this.cancellationDateString = cancellationDateString;
	}
	public Date getCancellationDate() {
		return cancellationDate;
	}
	public void setCancellationDate(Date cancellationDate) {
		this.cancellationDate = cancellationDate;
	}
	public String getCurrentScheduleEndDateString() {
		return currentScheduleEndDateString;
	}
	public void setCurrentScheduleEndDateString(String currentScheduleEndDateString) {
		this.currentScheduleEndDateString = currentScheduleEndDateString;
	}
	public Date getCurrentScheduleEndDate() {
		return currentScheduleEndDate;
	}
	public void setCurrentScheduleEndDate(Date currentScheduleEndDate) {
		this.currentScheduleEndDate = currentScheduleEndDate;
	}
	public String getCurrentScheduleStartDateString() {
		return currentScheduleStartDateString;
	}
	public void setCurrentScheduleStartDateString(String currentScheduleStartDateString) {
		this.currentScheduleStartDateString = currentScheduleStartDateString;
	}
	public Date getCurrentScheduleStartDate() {
		return currentScheduleStartDate;
	}
	public void setCurrentScheduleStartDate(Date currentScheduleStartDate) {
		this.currentScheduleStartDate = currentScheduleStartDate;
	}
	public String getRestartDateString() {
		return restartDateString;
	}
	public void setRestartDateString(String restartDateString) {
		this.restartDateString = restartDateString;
	}
	public Date getRestartDate() {
		return restartDate;
	}
	public void setRestartDate(Date restartDate) {
		this.restartDate = restartDate;
	}
	public String getStopDateString() {
		return stopDateString;
	}
	public void setStopDateString(String stopDateString) {
		this.stopDateString = stopDateString;
	}
	public Date getStopDate() {
		return stopDate;
	}
	public void setStopDate(Date stopDate) {
		this.stopDate = stopDate;
	}
	public PerChangeControlVO getPerChangeControl() {
		return perChangeControl;
	}
	public void setPerChangeControl(PerChangeControlVO perChangeControl) {
		this.perChangeControl = perChangeControl;
	}
	public PerLoeVO getPerLoe() {
		return perLoe;
	}
	public void setPerLoe(PerLoeVO perLoe) {
		this.perLoe = perLoe;
	}
	public List<PurchaseOrderVO> getPurchaseOrderList() {
		return purchaseOrderList;
	}
	public void setPurchaseOrderList(List<PurchaseOrderVO> purchaseOrderList) {
		this.purchaseOrderList = purchaseOrderList;
	}
	public List<PerChangeControlVO> getPerChangeControlList() {
		return perChangeControlList;
	}
	public void setPerChangeControlList(List<PerChangeControlVO> perChangeControlList) {
		this.perChangeControlList = perChangeControlList;
	}
	@Override
	public String toString() {
		return "PerVO [currentPhaseEndDateString=" + currentPhaseEndDateString + ", currentPhaseEndDate="
				+ currentPhaseEndDate + ", managersToNotify=" + managersToNotify + ", managersToNotifyArray="
				+ Arrays.toString(managersToNotifyArray) + ", managersList=" + managersList + ", itpmManagerList="
				+ itpmManagerList + ", parNumber=" + parNumber + ", perReceiptDateString=" + perReceiptDateString
				+ ", perReceiptDate=" + perReceiptDate + ", projectComments=" + projectComments + ", projectType="
				+ projectType + ", projectTypeName=" + projectTypeName + ", scheduleCallDateString="
				+ scheduleCallDateString + ", scheduleCallDate=" + scheduleCallDate + ", cancellationDateString="
				+ cancellationDateString + ", cancellationDate=" + cancellationDate + ", currentScheduleEndDateString="
				+ currentScheduleEndDateString + ", currentScheduleEndDate=" + currentScheduleEndDate
				+ ", currentScheduleStartDateString=" + currentScheduleStartDateString + ", currentScheduleStartDate="
				+ currentScheduleStartDate + ", restartDateString=" + restartDateString + ", restartDate=" + restartDate
				+ ", stopDateString=" + stopDateString + ", stopDate=" + stopDate + ", perChangeControl="
				+ perChangeControl + ", perLoe=" + perLoe + ", purchaseOrderList=" + purchaseOrderList
				+ ", perChangeControlList=" + perChangeControlList + "]";
	}

	
}
