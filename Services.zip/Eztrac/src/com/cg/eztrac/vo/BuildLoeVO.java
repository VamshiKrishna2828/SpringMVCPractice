package com.cg.eztrac.vo;

import java.util.Date;

public class BuildLoeVO extends LoeVO {
	
	private String buildPlanningLOEEstimationDateString;
	private Date buildPlanningLOEEstimationDate;
	private String buildExecutionLOEEstimationDateString;
	private Date buildExecutionLOEEstimationDate;
	
	private Float buildTotalExecutionCCLOEReq;
	private Float buildTotalExecutionCCLOEDesign;
	private Float buildTotalExecutionCCLOECons;
	private Float buildTotalExecutionCCLOETest;
	private Float buildTotalExecutionCCLOERelease;
	
	public String getBuildPlanningLOEEstimationDateString() {
		return buildPlanningLOEEstimationDateString;
	}
	public void setBuildPlanningLOEEstimationDateString(String buildPlanningLOEEstimationDateString) {
		this.buildPlanningLOEEstimationDateString = buildPlanningLOEEstimationDateString;
	}
	public Date getBuildPlanningLOEEstimationDate() {
		return buildPlanningLOEEstimationDate;
	}
	public void setBuildPlanningLOEEstimationDate(Date buildPlanningLOEEstimationDate) {
		this.buildPlanningLOEEstimationDate = buildPlanningLOEEstimationDate;
	}
	public String getBuildExecutionLOEEstimationDateString() {
		return buildExecutionLOEEstimationDateString;
	}
	public void setBuildExecutionLOEEstimationDateString(String buildExecutionLOEEstimationDateString) {
		this.buildExecutionLOEEstimationDateString = buildExecutionLOEEstimationDateString;
	}
	public Date getBuildExecutionLOEEstimationDate() {
		return buildExecutionLOEEstimationDate;
	}
	public void setBuildExecutionLOEEstimationDate(Date buildExecutionLOEEstimationDate) {
		this.buildExecutionLOEEstimationDate = buildExecutionLOEEstimationDate;
	}
	public Float getBuildTotalExecutionCCLOEReq() {
		return buildTotalExecutionCCLOEReq;
	}
	public void setBuildTotalExecutionCCLOEReq(Float buildTotalExecutionCCLOEReq) {
		this.buildTotalExecutionCCLOEReq = buildTotalExecutionCCLOEReq;
	}
	public Float getBuildTotalExecutionCCLOEDesign() {
		return buildTotalExecutionCCLOEDesign;
	}
	public void setBuildTotalExecutionCCLOEDesign(Float buildTotalExecutionCCLOEDesign) {
		this.buildTotalExecutionCCLOEDesign = buildTotalExecutionCCLOEDesign;
	}
	public Float getBuildTotalExecutionCCLOECons() {
		return buildTotalExecutionCCLOECons;
	}
	public void setBuildTotalExecutionCCLOECons(Float buildTotalExecutionCCLOECons) {
		this.buildTotalExecutionCCLOECons = buildTotalExecutionCCLOECons;
	}
	public Float getBuildTotalExecutionCCLOETest() {
		return buildTotalExecutionCCLOETest;
	}
	public void setBuildTotalExecutionCCLOETest(Float buildTotalExecutionCCLOETest) {
		this.buildTotalExecutionCCLOETest = buildTotalExecutionCCLOETest;
	}
	public Float getBuildTotalExecutionCCLOERelease() {
		return buildTotalExecutionCCLOERelease;
	}
	public void setBuildTotalExecutionCCLOERelease(Float buildTotalExecutionCCLOERelease) {
		this.buildTotalExecutionCCLOERelease = buildTotalExecutionCCLOERelease;
	}
	@Override
	public String toString() {
		return "BuildLoeVO [buildPlanningLOEEstimationDateString=" + buildPlanningLOEEstimationDateString
				+ ", buildPlanningLOEEstimationDate=" + buildPlanningLOEEstimationDate
				+ ", buildExecutionLOEEstimationDateString=" + buildExecutionLOEEstimationDateString
				+ ", buildExecutionLOEEstimationDate=" + buildExecutionLOEEstimationDate
				+ ", buildTotalExecutionCCLOEReq=" + buildTotalExecutionCCLOEReq + ", buildTotalExecutionCCLOEDesign="
				+ buildTotalExecutionCCLOEDesign + ", buildTotalExecutionCCLOECons=" + buildTotalExecutionCCLOECons
				+ ", buildTotalExecutionCCLOETest=" + buildTotalExecutionCCLOETest
				+ ", buildTotalExecutionCCLOERelease=" + buildTotalExecutionCCLOERelease + "]";
	}
	
}
