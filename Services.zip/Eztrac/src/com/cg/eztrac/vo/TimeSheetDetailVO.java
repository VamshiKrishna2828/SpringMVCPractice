package com.cg.eztrac.vo;

public class TimeSheetDetailVO {

	private int timeSheetId;
	private String workDate;
	private int hoursWorked;
	private String updateFlag;
//	private int buildId;
//	private int taskId;
//	private int subTaskId;
//	private int approvedBy;
//	private String approvedOn;
//	private String comments;
//	private boolean onsiteFlag;
//	private boolean favouriteFlag;
//	private	int perId;
//	private	String perNumber;
//	private String perDesc;

	/**
	 * @return the hoursWorked
	 */
	public int getHoursWorked() {
		return hoursWorked;
	}

	/**
	 * @param hoursWorked the hoursWorked to set
	 */
	public void setHoursWorked(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}

	/**
	 * @return the workDate
	 */
	public String getWorkDate() {
		return workDate;
	}

	/**
	 * @param workDate the workDate to set
	 */
	public void setWorkDate(String workDate) {
		this.workDate = workDate;
	}

	/**
	 * @return the timeSheetId
	 */
	public int getTimeSheetId() {
		return timeSheetId;
	}

	/**
	 * @param timeSheetId the timeSheetId to set
	 */
	public void setTimeSheetId(int timeSheetId) {
		this.timeSheetId = timeSheetId;
	}

	/**
	 * @return the updateFlag
	 */
	public String getUpdateFlag() {
		return updateFlag;
	}

	/**
	 * @param updateFlag the updateFlag to set
	 */
	public void setUpdateFlag(String updateFlag) {
		this.updateFlag = updateFlag;
	}
	
	
}