package com.cg.eztrac.vo;

import java.util.Date;

public class ChangeControlVO {
	
	private int ccId;
	private String ccNumber;
	private String ccCategoryId;
	private String ccPhase;
	private String ccStartDateString;
	private Date ccStartDate;
	private String ccEndDateString;
	private Date ccEndDate;
	private String ccDescription;
	
	private String ccCreatedBy;
	private String ccCreatedOnString;
	private Date ccCreatedOn;
	private String ccLastModifiedBy;
	private String ccLastModifiedOnString;
	private Date ccLastModifiedOn;
	
	public int getCcId() {
		return ccId;
	}
	public void setCcId(int ccId) {
		this.ccId = ccId;
	}
	public String getCcNumber() {
		return ccNumber;
	}
	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}
	public String getCcCategoryId() {
		return ccCategoryId;
	}
	public void setCcCategoryId(String ccCategoryId) {
		this.ccCategoryId = ccCategoryId;
	}
	public String getCcPhase() {
		return ccPhase;
	}
	public void setCcPhase(String ccPhase) {
		this.ccPhase = ccPhase;
	}
	public String getCcStartDateString() {
		return ccStartDateString;
	}
	public void setCcStartDateString(String ccStartDateString) {
		this.ccStartDateString = ccStartDateString;
	}
	public Date getCcStartDate() {
		return ccStartDate;
	}
	public void setCcStartDate(Date ccStartDate) {
		this.ccStartDate = ccStartDate;
	}
	public String getCcEndDateString() {
		return ccEndDateString;
	}
	public void setCcEndDateString(String ccEndDateString) {
		this.ccEndDateString = ccEndDateString;
	}
	public Date getCcEndDate() {
		return ccEndDate;
	}
	public void setCcEndDate(Date ccEndDate) {
		this.ccEndDate = ccEndDate;
	}
	public String getCcDescription() {
		return ccDescription;
	}
	public void setCcDescription(String ccDescription) {
		this.ccDescription = ccDescription;
	}
	public String getCcCreatedBy() {
		return ccCreatedBy;
	}
	public void setCcCreatedBy(String ccCreatedBy) {
		this.ccCreatedBy = ccCreatedBy;
	}
	public String getCcCreatedOnString() {
		return ccCreatedOnString;
	}
	public void setCcCreatedOnString(String ccCreatedOnString) {
		this.ccCreatedOnString = ccCreatedOnString;
	}
	public Date getCcCreatedOn() {
		return ccCreatedOn;
	}
	public void setCcCreatedOn(Date ccCreatedOn) {
		this.ccCreatedOn = ccCreatedOn;
	}
	public String getCcLastModifiedBy() {
		return ccLastModifiedBy;
	}
	public void setCcLastModifiedBy(String ccLastModifiedBy) {
		this.ccLastModifiedBy = ccLastModifiedBy;
	}
	public String getCcLastModifiedOnString() {
		return ccLastModifiedOnString;
	}
	public void setCcLastModifiedOnString(String ccLastModifiedOnString) {
		this.ccLastModifiedOnString = ccLastModifiedOnString;
	}
	public Date getCcLastModifiedOn() {
		return ccLastModifiedOn;
	}
	public void setCcLastModifiedOn(Date ccLastModifiedOn) {
		this.ccLastModifiedOn = ccLastModifiedOn;
	}
	@Override
	public String toString() {
		return "ChangeControlVO [ccId=" + ccId + ", ccNumber=" + ccNumber + ", ccCategoryId=" + ccCategoryId
				+ ", ccPhase=" + ccPhase + ", ccStartDateString=" + ccStartDateString + ", ccStartDate=" + ccStartDate
				+ ", ccEndDateString=" + ccEndDateString + ", ccEndDate=" + ccEndDate + ", ccDescription="
				+ ccDescription + ", ccCreatedBy=" + ccCreatedBy + ", ccCreatedOnString=" + ccCreatedOnString
				+ ", ccCreatedOn=" + ccCreatedOn + ", ccLastModifiedBy=" + ccLastModifiedBy
				+ ", ccLastModifiedOnString=" + ccLastModifiedOnString + ", ccLastModifiedOn=" + ccLastModifiedOn + "]";
	}
	
}
