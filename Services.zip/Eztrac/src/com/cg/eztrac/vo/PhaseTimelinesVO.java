package com.cg.eztrac.vo;

import java.util.Date;

public class PhaseTimelinesVO {
	
	private String plannedReqEndDateString;
	private Date plannedReqEndDate;
	private String plannedReqStartDateString;
	private Date plannedReqStartDate;
	private String plannedDesignEndDateString;
	private Date plannedDesignEndDate;
	private String plannedDesignStartDateString;
	private Date plannedDesignStartDate;
	private String plannedConEndDateString;
	private Date plannedConEndDate;
	private String plannedConStartDateString;
	private Date plannedConStartDate;
	private String plannedTestingEndDateString;
	private Date plannedTestingEndDate;
	private String plannedTestingStartDateString;
	private Date plannedTestingStartDate;
	private String plannedReleaseEndDateString;
	private Date plannedReleaseEndDate;
	private String plannedReleaseStartDateString;
	private Date plannedReleaseStartDate;
	
	private String actualReqEndDateString;
	private Date actualReqEndDate;
	private String actualReqStartDateString;
	private Date actualReqStartDate;
	private String actualDesignEndDateString;
	private Date actualDesignEndDate;
	private String actualDesignStartDateString;
	private Date actualDesignStartDate;
	private String actualConEndDateString;
	private Date actualConEndDate;
	private String actualConStartDateString;
	private Date actualConStartDate;
	private String actualTestingEndDateString;
	private Date actualTestingEndDate;
	private String actualTestingStartDateString;
	private Date actualTestingStartDate;
	private String actualReleaseEndDateString;
	private Date actualReleaseEndDate;
	private String actualReleaseStartDateString;
	private Date actualReleaseStartDate;
	public String getPlannedReqEndDateString() {
		return plannedReqEndDateString;
	}
	public void setPlannedReqEndDateString(String plannedReqEndDateString) {
		this.plannedReqEndDateString = plannedReqEndDateString;
	}
	public Date getPlannedReqEndDate() {
		return plannedReqEndDate;
	}
	public void setPlannedReqEndDate(Date plannedReqEndDate) {
		this.plannedReqEndDate = plannedReqEndDate;
	}
	public String getPlannedReqStartDateString() {
		return plannedReqStartDateString;
	}
	public void setPlannedReqStartDateString(String plannedReqStartDateString) {
		this.plannedReqStartDateString = plannedReqStartDateString;
	}
	public Date getPlannedReqStartDate() {
		return plannedReqStartDate;
	}
	public void setPlannedReqStartDate(Date plannedReqStartDate) {
		this.plannedReqStartDate = plannedReqStartDate;
	}
	public String getPlannedDesignEndDateString() {
		return plannedDesignEndDateString;
	}
	public void setPlannedDesignEndDateString(String plannedDesignEndDateString) {
		this.plannedDesignEndDateString = plannedDesignEndDateString;
	}
	public Date getPlannedDesignEndDate() {
		return plannedDesignEndDate;
	}
	public void setPlannedDesignEndDate(Date plannedDesignEndDate) {
		this.plannedDesignEndDate = plannedDesignEndDate;
	}
	public String getPlannedDesignStartDateString() {
		return plannedDesignStartDateString;
	}
	public void setPlannedDesignStartDateString(String plannedDesignStartDateString) {
		this.plannedDesignStartDateString = plannedDesignStartDateString;
	}
	public Date getPlannedDesignStartDate() {
		return plannedDesignStartDate;
	}
	public void setPlannedDesignStartDate(Date plannedDesignStartDate) {
		this.plannedDesignStartDate = plannedDesignStartDate;
	}
	public String getPlannedConEndDateString() {
		return plannedConEndDateString;
	}
	public void setPlannedConEndDateString(String plannedConEndDateString) {
		this.plannedConEndDateString = plannedConEndDateString;
	}
	public Date getPlannedConEndDate() {
		return plannedConEndDate;
	}
	public void setPlannedConEndDate(Date plannedConEndDate) {
		this.plannedConEndDate = plannedConEndDate;
	}
	public String getPlannedConStartDateString() {
		return plannedConStartDateString;
	}
	public void setPlannedConStartDateString(String plannedConStartDateString) {
		this.plannedConStartDateString = plannedConStartDateString;
	}
	public Date getPlannedConStartDate() {
		return plannedConStartDate;
	}
	public void setPlannedConStartDate(Date plannedConStartDate) {
		this.plannedConStartDate = plannedConStartDate;
	}
	public String getPlannedTestingEndDateString() {
		return plannedTestingEndDateString;
	}
	public void setPlannedTestingEndDateString(String plannedTestingEndDateString) {
		this.plannedTestingEndDateString = plannedTestingEndDateString;
	}
	public Date getPlannedTestingEndDate() {
		return plannedTestingEndDate;
	}
	public void setPlannedTestingEndDate(Date plannedTestingEndDate) {
		this.plannedTestingEndDate = plannedTestingEndDate;
	}
	public String getPlannedTestingStartDateString() {
		return plannedTestingStartDateString;
	}
	public void setPlannedTestingStartDateString(String plannedTestingStartDateString) {
		this.plannedTestingStartDateString = plannedTestingStartDateString;
	}
	public Date getPlannedTestingStartDate() {
		return plannedTestingStartDate;
	}
	public void setPlannedTestingStartDate(Date plannedTestingStartDate) {
		this.plannedTestingStartDate = plannedTestingStartDate;
	}
	public String getPlannedReleaseEndDateString() {
		return plannedReleaseEndDateString;
	}
	public void setPlannedReleaseEndDateString(String plannedReleaseEndDateString) {
		this.plannedReleaseEndDateString = plannedReleaseEndDateString;
	}
	public Date getPlannedReleaseEndDate() {
		return plannedReleaseEndDate;
	}
	public void setPlannedReleaseEndDate(Date plannedReleaseEndDate) {
		this.plannedReleaseEndDate = plannedReleaseEndDate;
	}
	public String getPlannedReleaseStartDateString() {
		return plannedReleaseStartDateString;
	}
	public void setPlannedReleaseStartDateString(String plannedReleaseStartDateString) {
		this.plannedReleaseStartDateString = plannedReleaseStartDateString;
	}
	public Date getPlannedReleaseStartDate() {
		return plannedReleaseStartDate;
	}
	public void setPlannedReleaseStartDate(Date plannedReleaseStartDate) {
		this.plannedReleaseStartDate = plannedReleaseStartDate;
	}
	public String getActualReqEndDateString() {
		return actualReqEndDateString;
	}
	public void setActualReqEndDateString(String actualReqEndDateString) {
		this.actualReqEndDateString = actualReqEndDateString;
	}
	public Date getActualReqEndDate() {
		return actualReqEndDate;
	}
	public void setActualReqEndDate(Date actualReqEndDate) {
		this.actualReqEndDate = actualReqEndDate;
	}
	public String getActualReqStartDateString() {
		return actualReqStartDateString;
	}
	public void setActualReqStartDateString(String actualReqStartDateString) {
		this.actualReqStartDateString = actualReqStartDateString;
	}
	public Date getActualReqStartDate() {
		return actualReqStartDate;
	}
	public void setActualReqStartDate(Date actualReqStartDate) {
		this.actualReqStartDate = actualReqStartDate;
	}
	public String getActualDesignEndDateString() {
		return actualDesignEndDateString;
	}
	public void setActualDesignEndDateString(String actualDesignEndDateString) {
		this.actualDesignEndDateString = actualDesignEndDateString;
	}
	public Date getActualDesignEndDate() {
		return actualDesignEndDate;
	}
	public void setActualDesignEndDate(Date actualDesignEndDate) {
		this.actualDesignEndDate = actualDesignEndDate;
	}
	public String getActualDesignStartDateString() {
		return actualDesignStartDateString;
	}
	public void setActualDesignStartDateString(String actualDesignStartDateString) {
		this.actualDesignStartDateString = actualDesignStartDateString;
	}
	public Date getActualDesignStartDate() {
		return actualDesignStartDate;
	}
	public void setActualDesignStartDate(Date actualDesignStartDate) {
		this.actualDesignStartDate = actualDesignStartDate;
	}
	public String getActualConEndDateString() {
		return actualConEndDateString;
	}
	public void setActualConEndDateString(String actualConEndDateString) {
		this.actualConEndDateString = actualConEndDateString;
	}
	public Date getActualConEndDate() {
		return actualConEndDate;
	}
	public void setActualConEndDate(Date actualConEndDate) {
		this.actualConEndDate = actualConEndDate;
	}
	public String getActualConStartDateString() {
		return actualConStartDateString;
	}
	public void setActualConStartDateString(String actualConStartDateString) {
		this.actualConStartDateString = actualConStartDateString;
	}
	public Date getActualConStartDate() {
		return actualConStartDate;
	}
	public void setActualConStartDate(Date actualConStartDate) {
		this.actualConStartDate = actualConStartDate;
	}
	public String getActualTestingEndDateString() {
		return actualTestingEndDateString;
	}
	public void setActualTestingEndDateString(String actualTestingEndDateString) {
		this.actualTestingEndDateString = actualTestingEndDateString;
	}
	public Date getActualTestingEndDate() {
		return actualTestingEndDate;
	}
	public void setActualTestingEndDate(Date actualTestingEndDate) {
		this.actualTestingEndDate = actualTestingEndDate;
	}
	public String getActualTestingStartDateString() {
		return actualTestingStartDateString;
	}
	public void setActualTestingStartDateString(String actualTestingStartDateString) {
		this.actualTestingStartDateString = actualTestingStartDateString;
	}
	public Date getActualTestingStartDate() {
		return actualTestingStartDate;
	}
	public void setActualTestingStartDate(Date actualTestingStartDate) {
		this.actualTestingStartDate = actualTestingStartDate;
	}
	public String getActualReleaseEndDateString() {
		return actualReleaseEndDateString;
	}
	public void setActualReleaseEndDateString(String actualReleaseEndDateString) {
		this.actualReleaseEndDateString = actualReleaseEndDateString;
	}
	public Date getActualReleaseEndDate() {
		return actualReleaseEndDate;
	}
	public void setActualReleaseEndDate(Date actualReleaseEndDate) {
		this.actualReleaseEndDate = actualReleaseEndDate;
	}
	public String getActualReleaseStartDateString() {
		return actualReleaseStartDateString;
	}
	public void setActualReleaseStartDateString(String actualReleaseStartDateString) {
		this.actualReleaseStartDateString = actualReleaseStartDateString;
	}
	public Date getActualReleaseStartDate() {
		return actualReleaseStartDate;
	}
	public void setActualReleaseStartDate(Date actualReleaseStartDate) {
		this.actualReleaseStartDate = actualReleaseStartDate;
	}
	
	@Override
	public String toString() {
		return "PhaseTimelinesVO [plannedReqEndDateString=" + plannedReqEndDateString + ", plannedReqEndDate="
				+ plannedReqEndDate + ", plannedReqStartDateString=" + plannedReqStartDateString
				+ ", plannedReqStartDate=" + plannedReqStartDate + ", plannedDesignEndDateString="
				+ plannedDesignEndDateString + ", plannedDesignEndDate=" + plannedDesignEndDate
				+ ", plannedDesignStartDateString=" + plannedDesignStartDateString + ", plannedDesignStartDate="
				+ plannedDesignStartDate + ", plannedConEndDateString=" + plannedConEndDateString
				+ ", plannedConEndDate=" + plannedConEndDate + ", plannedConStartDateString="
				+ plannedConStartDateString + ", plannedConStartDate=" + plannedConStartDate
				+ ", plannedTestingEndDateString=" + plannedTestingEndDateString + ", plannedTestingEndDate="
				+ plannedTestingEndDate + ", plannedTestingStartDateString=" + plannedTestingStartDateString
				+ ", plannedTestingStartDate=" + plannedTestingStartDate + ", plannedReleaseEndDateString="
				+ plannedReleaseEndDateString + ", plannedReleaseEndDate=" + plannedReleaseEndDate
				+ ", plannedReleaseStartDateString=" + plannedReleaseStartDateString + ", plannedReleaseStartDate="
				+ plannedReleaseStartDate + ", actualReqEndDateString=" + actualReqEndDateString + ", actualReqEndDate="
				+ actualReqEndDate + ", actualReqStartDateString=" + actualReqStartDateString + ", actualReqStartDate="
				+ actualReqStartDate + ", actualDesignEndDateString=" + actualDesignEndDateString
				+ ", actualDesignEndDate=" + actualDesignEndDate + ", actualDesignStartDateString="
				+ actualDesignStartDateString + ", actualDesignStartDate=" + actualDesignStartDate
				+ ", actualConEndDateString=" + actualConEndDateString + ", actualConEndDate=" + actualConEndDate
				+ ", actualConStartDateString=" + actualConStartDateString + ", actualConStartDate="
				+ actualConStartDate + ", actualTestingEndDateString=" + actualTestingEndDateString
				+ ", actualTestingEndDate=" + actualTestingEndDate + ", actualTestingStartDateString="
				+ actualTestingStartDateString + ", actualTestingStartDate=" + actualTestingStartDate
				+ ", actualReleaseEndDateString=" + actualReleaseEndDateString + ", actualReleaseEndDate="
				+ actualReleaseEndDate + ", actualReleaseStartDateString=" + actualReleaseStartDateString
				+ ", actualReleaseStartDate=" + actualReleaseStartDate + "]";
	}
	
	

}
