package com.cg.eztrac.vo;

import java.util.List;

import org.springframework.stereotype.Component;

@Component(value="perListVO")
public class PerListVO extends EstimationListVO{
	
	private PerVO per;
	private List<PerVO> perList;
	public PerVO getPer() {
		return per;
	}
	public void setPer(PerVO per) {
		this.per = per;
	}
	public List<PerVO> getPerList() {
		return perList;
	}
	public void setPerList(List<PerVO> perList) {
		this.perList = perList;
	}
}
