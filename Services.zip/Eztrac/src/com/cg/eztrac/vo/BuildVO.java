package com.cg.eztrac.vo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class BuildVO extends EstimationVO {

	//General - Fields - Build Module
	
	private Integer buildId;
	private Integer currentBuildPhase;
	private String currentBuildPhaseName;
	private Integer onsiteLeverage;
	private Integer onsiteTimesheetLeverage;
	private Float phaseCompletion;
	private String cancelDateString;
	private Date cancelDate;
	private String assignedTo;
	private Integer[] assignedToArray;
	private String[] assignedToArrayName;
	private Boolean isAssigned;
	private List<ResourceDetailsVO> resourcesList;
	private List<ResourceDetailsVO> assignedResourcesList;
	
	private BuildChangeControlVO buildChangeControl;
	private BuildLoeVO buildLoe;
	
	private List<BuildChangeControlVO> buildChangeControlList;
	
	//lists to populate dropdowns
	private List<SubSystemVO> subSystemList;
	private List<String> assignedToList;
	
	//Map for perNumber dropdown
	private Map<Integer,String> perNumbersMap;
	
	public Integer getBuildId() {
		return buildId;
	}
	public void setBuildId(Integer buildId) {
		this.buildId = buildId;
	}
	public Integer getCurrentBuildPhase() {
		return currentBuildPhase;
	}
	public void setCurrentBuildPhase(Integer currentBuildPhase) {
		this.currentBuildPhase = currentBuildPhase;
	}
	public String getCurrentBuildPhaseName() {
		return currentBuildPhaseName;
	}
	public void setCurrentBuildPhaseName(String currentBuildPhaseName) {
		this.currentBuildPhaseName = currentBuildPhaseName;
	}
	public Integer getOnsiteLeverage() {
		return onsiteLeverage;
	}
	public void setOnsiteLeverage(Integer onsiteLeverage) {
		this.onsiteLeverage = onsiteLeverage;
	}
	public Integer getOnsiteTimesheetLeverage() {
		return onsiteTimesheetLeverage;
	}
	public void setOnsiteTimesheetLeverage(Integer onsiteTimesheetLeverage) {
		this.onsiteTimesheetLeverage = onsiteTimesheetLeverage;
	}
	public Float getPhaseCompletion() {
		return phaseCompletion;
	}
	public void setPhaseCompletion(Float phaseCompletion) {
		this.phaseCompletion = phaseCompletion;
	}
	public String getCancelDateString() {
		return cancelDateString;
	}
	public void setCancelDateString(String cancelDateString) {
		this.cancelDateString = cancelDateString;
	}
	public Date getCancelDate() {
		return cancelDate;
	}
	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}
	public String getAssignedTo() {
		return assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public Integer[] getAssignedToArray() {
		return assignedToArray;
	}
	public void setAssignedToArray(Integer[] assignedToArray) {
		this.assignedToArray = assignedToArray;
	}
	public BuildChangeControlVO getBuildChangeControl() {
		return buildChangeControl;
	}
	public void setBuildChangeControl(BuildChangeControlVO buildChangeControl) {
		this.buildChangeControl = buildChangeControl;
	}
	public BuildLoeVO getBuildLoe() {
		return buildLoe;
	}
	public void setBuildLoe(BuildLoeVO buildLoe) {
		this.buildLoe = buildLoe;
	}
	public List<BuildChangeControlVO> getBuildChangeControlList() {
		return buildChangeControlList;
	}
	public void setBuildChangeControlList(List<BuildChangeControlVO> buildChangeControlList) {
		this.buildChangeControlList = buildChangeControlList;
	}
	public List<SubSystemVO> getSubSystemList() {
		return subSystemList;
	}
	public void setSubSystemList(List<SubSystemVO> subSystemList) {
		this.subSystemList = subSystemList;
	}
	public String[] getAssignedToArrayName() {
		return assignedToArrayName;
	}
	public void setAssignedToArrayName(String[] assignedToArrayName) {
		this.assignedToArrayName = assignedToArrayName;
	}
	public Boolean getIsAssigned() {
		return isAssigned;
	}
	public void setIsAssigned(Boolean isAssigned) {
		this.isAssigned = isAssigned;
	}
	public List<ResourceDetailsVO> getResourcesList() {
		return resourcesList;
	}
	public void setResourcesList(List<ResourceDetailsVO> resourcesList) {
		this.resourcesList = resourcesList;
	}
	public List<ResourceDetailsVO> getAssignedResourcesList() {
		return assignedResourcesList;
	}
	public void setAssignedResourcesList(List<ResourceDetailsVO> assignedResourcesList) {
		this.assignedResourcesList = assignedResourcesList;
	}
	public List<String> getAssignedToList() {
		return assignedToList;
	}
	public void setAssignedToList(List<String> assignedToList) {
		this.assignedToList = assignedToList;
	}
	public Map<Integer, String> getPerNumbersMap() {
		return perNumbersMap;
	}
	public void setPerNumbersMap(Map<Integer, String> perNumbersMap) {
		this.perNumbersMap = perNumbersMap;
	}
	@Override
	public String toString() {
		return "BuildVO [buildId=" + buildId + ", currentBuildPhase=" + currentBuildPhase + ", currentBuildPhaseName="
				+ currentBuildPhaseName + ", onsiteLeverage=" + onsiteLeverage + ", onsiteTimesheetLeverage="
				+ onsiteTimesheetLeverage + ", phaseCompletion=" + phaseCompletion + ", cancelDateString="
				+ cancelDateString + ", cancelDate=" + cancelDate + ", assignedToArray="
				+ Arrays.toString(assignedToArray) + ", assignedToArrayName=" + Arrays.toString(assignedToArrayName)
				+ ", resourcesList=" + resourcesList + ", buildChangeControl=" + buildChangeControl + ", buildLoe="
				+ buildLoe + ", buildChangeControlList=" + buildChangeControlList + ", subSystemList=" + subSystemList
				+ ", assignedToList=" + assignedToList + ", perNumbersMap=" + perNumbersMap + "]";
	}
	
}
