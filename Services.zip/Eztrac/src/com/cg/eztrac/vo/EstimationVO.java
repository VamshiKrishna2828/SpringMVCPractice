package com.cg.eztrac.vo;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class EstimationVO extends CommonVO {
	
	//General - Fields - Common for Per and Build Modules
	private Integer perId;
	private String perNumber;
	private String perDescription;
	private Integer currentPerPhase;
	private String currentPerPhaseName;
	private Integer projectHealth;
	private String projectHealthName;
	private Integer projectCoordinator;
	private String projectCoordinatorName;
	private String comments;
	private Integer systemId;
	private String systemName; 
	private Integer subSystemId;
	private String subSystemName;
	
	private String createdBy;
	private String createdOnString;
	private Date createdOn;
	private String lastModifiedBy;
	private String lastModifiedOnString;
	private Date lastModifiedOn;
	
	private Integer userId;
	private String statusCode;
	private Integer currentRoleId;
	private String emailId;
	
	private PhaseTimelinesVO phaseTimelines;
	private PurchaseOrderVO purchaseOrder;
	
	private AttachmentVO attachment;
	private CommentVO comment;
	private NotificationVO notification;
	
	private List<AttachmentVO> attachmentList;
	private List<CommentVO> commentList;
	private List<NotificationVO> notificationList;
	
	//Response Code and Description Map
	private Map<String,String> responseMap;

	public Integer getPerId() {
		return perId;
	}

	public void setPerId(Integer perId) {
		this.perId = perId;
	}

	public String getPerNumber() {
		return perNumber;
	}

	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}

	public String getPerDescription() {
		return perDescription;
	}

	public void setPerDescription(String perDescription) {
		this.perDescription = perDescription;
	}

	public Integer getCurrentPerPhase() {
		return currentPerPhase;
	}

	public void setCurrentPerPhase(Integer currentPerPhase) {
		this.currentPerPhase = currentPerPhase;
	}

	public String getCurrentPerPhaseName() {
		return currentPerPhaseName;
	}

	public void setCurrentPerPhaseName(String currentPerPhaseName) {
		this.currentPerPhaseName = currentPerPhaseName;
	}

	public Integer getProjectHealth() {
		return projectHealth;
	}

	public void setProjectHealth(Integer projectHealth) {
		this.projectHealth = projectHealth;
	}

	public String getProjectHealthName() {
		return projectHealthName;
	}

	public void setProjectHealthName(String projectHealthName) {
		this.projectHealthName = projectHealthName;
	}

	public Integer getProjectCoordinator() {
		return projectCoordinator;
	}

	public void setProjectCoordinator(Integer projectCoordinator) {
		this.projectCoordinator = projectCoordinator;
	}

	public String getProjectCoordinatorName() {
		return projectCoordinatorName;
	}

	public void setProjectCoordinatorName(String projectCoordinatorName) {
		this.projectCoordinatorName = projectCoordinatorName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Integer getSystemId() {
		return systemId;
	}

	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public Integer getSubSystemId() {
		return subSystemId;
	}

	public void setSubSystemId(Integer subSystemId) {
		this.subSystemId = subSystemId;
	}

	public String getSubSystemName() {
		return subSystemName;
	}

	public void setSubSystemName(String subSystemName) {
		this.subSystemName = subSystemName;
	}


	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedOnString() {
		return createdOnString;
	}

	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getLastModifiedOnString() {
		return lastModifiedOnString;
	}

	public void setLastModifiedOnString(String lastModifiedOnString) {
		this.lastModifiedOnString = lastModifiedOnString;
	}

	public Date getLastModifiedOn() {
		return lastModifiedOn;
	}

	public void setLastModifiedOn(Date lastModifiedOn) {
		this.lastModifiedOn = lastModifiedOn;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public Integer getCurrentRoleId() {
		return currentRoleId;
	}

	public void setCurrentRoleId(Integer currentRoleId) {
		this.currentRoleId = currentRoleId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public PhaseTimelinesVO getPhaseTimelines() {
		return phaseTimelines;
	}

	public void setPhaseTimelines(PhaseTimelinesVO phaseTimelines) {
		this.phaseTimelines = phaseTimelines;
	}

	public PurchaseOrderVO getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrderVO purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public AttachmentVO getAttachment() {
		return attachment;
	}

	public void setAttachment(AttachmentVO attachment) {
		this.attachment = attachment;
	}

	public CommentVO getComment() {
		return comment;
	}

	public void setComment(CommentVO comment) {
		this.comment = comment;
	}

	public NotificationVO getNotification() {
		return notification;
	}

	public void setNotification(NotificationVO notification) {
		this.notification = notification;
	}

	public List<AttachmentVO> getAttachmentList() {
		return attachmentList;
	}

	public void setAttachmentList(List<AttachmentVO> attachmentList) {
		this.attachmentList = attachmentList;
	}

	public List<CommentVO> getCommentList() {
		return commentList;
	}

	public void setCommentList(List<CommentVO> commentList) {
		this.commentList = commentList;
	}

	public List<NotificationVO> getNotificationList() {
		return notificationList;
	}

	public void setNotificationList(List<NotificationVO> notificationList) {
		this.notificationList = notificationList;
	}

	public Map<String, String> getResponseMap() {
		return responseMap;
	}

	public void setResponseMap(Map<String, String> responseMap) {
		this.responseMap = responseMap;
	}

	@Override
	public String toString() {
		return "EstimationVO [perId=" + perId + ", perNumber=" + perNumber + ", perDescription=" + perDescription
				+ ", currentPerPhase=" + currentPerPhase + ", currentPerPhaseName=" + currentPerPhaseName
				+ ", projectHealth=" + projectHealth + ", projectHealthName=" + projectHealthName
				+ ", projectCoordinator=" + projectCoordinator + ", projectCoordinatorName=" + projectCoordinatorName
				+ ", comments=" + comments + ", systemId=" + systemId + ", systemName=" + systemName + ", subSystemId="
				+ subSystemId + ", subSystemName=" + subSystemName + ", createdBy=" + createdBy + ", createdOnString="
				+ createdOnString + ", createdOn=" + createdOn + ", lastModifiedBy=" + lastModifiedBy
				+ ", lastModifiedOnString=" + lastModifiedOnString + ", lastModifiedOn=" + lastModifiedOn + ", userId="
				+ userId + ", statusCode=" + statusCode + ", currentRoleId=" + currentRoleId + ", emailId=" + emailId
				+ ", phaseTimelines=" + phaseTimelines + ", purchaseOrder=" + purchaseOrder + ", attachment="
				+ attachment + ", comment=" + comment + ", notification=" + notification + ", attachmentList="
				+ attachmentList + ", commentList=" + commentList + ", notificationList=" + notificationList
				+ ", responseMap=" + responseMap + "]";
	}

}
