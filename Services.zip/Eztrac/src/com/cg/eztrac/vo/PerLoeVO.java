package com.cg.eztrac.vo;

public class PerLoeVO extends LoeVO {
	
	private Float perPlanningLOETotal;
	private Float perExecutionLOETotal;
	private Float perActualDaysLOETotal;
	
	public Float getPerPlanningLOETotal() {
		return perPlanningLOETotal;
	}
	public void setPerPlanningLOETotal(Float perPlanningLOETotal) {
		this.perPlanningLOETotal = perPlanningLOETotal;
	}
	public Float getPerExecutionLOETotal() {
		return perExecutionLOETotal;
	}
	public void setPerExecutionLOETotal(Float perExecutionLOETotal) {
		this.perExecutionLOETotal = perExecutionLOETotal;
	}
	public Float getPerActualDaysLOETotal() {
		return perActualDaysLOETotal;
	}
	public void setPerActualDaysLOETotal(Float perActualDaysLOETotal) {
		this.perActualDaysLOETotal = perActualDaysLOETotal;
	}
	@Override
	public String toString() {
		return "PerLoeVO [perPlanningLOETotal=" + perPlanningLOETotal + ", perExecutionLOETotal=" + perExecutionLOETotal
				+ ", perActualDaysLOETotal=" + perActualDaysLOETotal + "]";
	}
	
}
