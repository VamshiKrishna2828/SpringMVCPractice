package com.cg.eztrac.vo;

import java.io.Serializable;

public class SubSectionVO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6423739005483390791L;
	private Integer subSectionId;
	private String subSectionName="";
	boolean elligbleFlag = true;
	private Integer subSectionType;
	public Integer getSubSectionId() {
		return subSectionId;
	}
	public void setSubSectionId(Integer subSectionId) {
		this.subSectionId = subSectionId;
	}
	public String getSubSectionName() {
		return subSectionName;
	}
	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}
	public boolean isElligbleFlag() {
		return elligbleFlag;
	}
	public void setElligbleFlag(boolean elligbleFlag) {
		this.elligbleFlag = elligbleFlag;
	}
	public Integer getSubSectionType() {
		return subSectionType;
	}
	public void setSubSectionType(Integer subSectionType) {
		this.subSectionType = subSectionType;
	}
	
}
