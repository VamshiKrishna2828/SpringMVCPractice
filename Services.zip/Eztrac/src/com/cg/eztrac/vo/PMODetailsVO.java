package com.cg.eztrac.vo;

public class PMODetailsVO {
	
	private static final String CLASS_NAME = PMODetailsVO.class.getSimpleName();
	
	private Integer userId;
	private String name;
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "PMODetailsVO [userId=" + userId + ", name=" + name + "]";
	}
	
}
