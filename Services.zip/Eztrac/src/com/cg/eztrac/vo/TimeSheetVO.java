package com.cg.eztrac.vo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.eztrac.domain.PerDO;
import com.cg.eztrac.service.domainobject.TimeSheetDetailDO;
import com.cg.eztrac.service.domainobject.TimeSheetHeaderDO;

public class TimeSheetVO extends CommonVO {

	private List<SystemDetailsVO> systemList;
	private HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>> timeSheetDetailMap;
	private Map<String, TimeSheetHeaderDO> timeSheetHeaderMap;
	private Map<Integer, Map<Integer, List<TimeSheetDetailVO>>> timeSheetInsertionMap;
	
	private List<PerDO> perDetail;
	private String perNumber;
	private String currentPerPhase;
	private List<String> timePeriodList;
	private List<SubSystemVO> subSystemList;
	private String currentWeek;
	private String insertStatus;
	private String deleteStatus;
	private List<Integer> timeSheetIdList;
	
	private String channelId;
	private Integer systemId;
	private Integer subSystemId;
	private String startDate;
	private String endDate;
	private String projectName;
	private String insertType;
	private String resourceName;
	private Integer userId;
	
	//Response Code and Description Map
	private Map<String,String> responseMap;
	
	@SuppressWarnings({ "serial" })
	public TimeSheetVO() {
		Map<Integer, Map<Integer, List<TimeSheetDetailVO>>> finalMap = new InputMap<Integer, Map<Integer, List<TimeSheetDetailVO>>>() {
			protected Map<Integer, List<TimeSheetDetailVO>> create() {
	            return new InputMap<Integer, List<TimeSheetDetailVO>>() {
	                protected List<TimeSheetDetailVO> create() {
	                    return new ArrayList<TimeSheetDetailVO>();
	                }
	            };
	        }
	    };
		 this.setTimeSheetInsertionMap(finalMap);
	}
	
	private static abstract class InputMap<K, V> extends HashMap<K, V> {
		
		private static final long serialVersionUID = -5842195809137431920L;

		@SuppressWarnings("unchecked")
		@Override
	    public V get(Object key) {
	        V val = super.get(key);
	        if (val == null || val.equals("")) {
	            put((K)key, val = create());
	        }
	        return val;
	    }

	    protected abstract V create();
	}
	
	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public List<SystemDetailsVO> getSystemList() {
		return systemList;
	}

	public void setSystemList(List<SystemDetailsVO> systemList) {
		this.systemList = systemList;
	}

	public Integer getSystemId() {
		return systemId;
	}

	public void setSystemId(Integer systemId) {
		this.systemId = systemId;
	}

	public Integer getSubSystemId() {
		return subSystemId;
	}

	public void setSubSystemId(Integer subSystemId) {
		this.subSystemId = subSystemId;
	}
	public String getStartDate() {
		return startDate;
		}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Map<String, TimeSheetHeaderDO> getTimeSheetHeaderMap() {
		return timeSheetHeaderMap;
	}

	public void setTimeSheetHeaderMap(Map<String, TimeSheetHeaderDO> timeSheetHeaderMap) {
		this.timeSheetHeaderMap = timeSheetHeaderMap;
	}

	public Map<Integer, Map<Integer, List<TimeSheetDetailVO>>> getTimeSheetInsertionMap() {
		return timeSheetInsertionMap;
	}

	public void setTimeSheetInsertionMap(Map<Integer, Map<Integer, List<TimeSheetDetailVO>>> timeSheetInsertionMap) {
		this.timeSheetInsertionMap = timeSheetInsertionMap;
	}
	public String getInsertType() {
		return insertType;
	}
	public void setInsertType(String insertType) {
		this.insertType = insertType;
	}
	public HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>> getTimeSheetDetailMap() {
		return timeSheetDetailMap;
	}

	public void setTimeSheetDetailMap(HashMap<String, HashMap<Integer, List<TimeSheetDetailDO>>> timeSheetDetailMap) {
		this.timeSheetDetailMap = timeSheetDetailMap;
	}

	public List<PerDO> getPerDetail() {
		return perDetail;
	}
	public void setPerDetail(List<PerDO> perDetail) {
		this.perDetail = perDetail;
	}

	public String getPerNumber() {
		return perNumber;
	}
	public void setPerNumber(String perNumber) {
		this.perNumber = perNumber;
	}

	public String getCurrentPerPhase() {
		return currentPerPhase;
	}
	public void setCurrentPerPhase(String currentPerPhase) {
		this.currentPerPhase = currentPerPhase;
	}
	public List<String> getTimePeriodList() {
		return timePeriodList;
	}

	public void setTimePeriodList(List<String> timePeriodList) {
		this.timePeriodList = timePeriodList;
	}

	public List<SubSystemVO> getSubSystemList() {
		return subSystemList;
	}
	public void setSubSystemList(List<SubSystemVO> subSystemList) {
		this.subSystemList = subSystemList;
	}
	public String getCurrentWeek() {
		return currentWeek;
	}
	public void setCurrentWeek(String currentWeek) {
		this.currentWeek = currentWeek;
	}

	public String getInsertStatus() {
		return insertStatus;
	}

	public void setInsertStatus(String insertStatus) {
		this.insertStatus = insertStatus;
	}
	public String getDeleteStatus() {
		return deleteStatus;
	}

	public void setDeleteStatus(String deleteStatus) {
		this.deleteStatus = deleteStatus;
	}

	public List<Integer> getTimeSheetIdList() {
		return timeSheetIdList;
	}
	public void setTimeSheetIdList(List<Integer> timeSheetIdList) {
		this.timeSheetIdList = timeSheetIdList;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Map<String, String> getResponseMap() {
		return responseMap;
	}

	public void setResponseMap(Map<String, String> responseMap) {
		this.responseMap = responseMap;
	}

}