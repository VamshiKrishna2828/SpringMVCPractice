package com.cg.eztrac.vo;

import java.util.Date;

public class CommentVO {
	
	private String comment;
	private String commentBy;
	private String commentOnString;
	private Date commentOn;
	
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getCommentBy() {
		return commentBy;
	}
	public void setCommentBy(String commentBy) {
		this.commentBy = commentBy;
	}
	public String getCommentOnString() {
		return commentOnString;
	}
	public void setCommentOnString(String commentOnString) {
		this.commentOnString = commentOnString;
	}
	public Date getCommentOn() {
		return commentOn;
	}
	public void setCommentOn(Date commentOn) {
		this.commentOn = commentOn;
	}
	
	@Override
	public String toString() {
		return "CommentVO [comment=" + comment + ", commentBy=" + commentBy + ", commentOnString=" + commentOnString
				+ ", commentOn=" + commentOn + "]";
	}
	
}
