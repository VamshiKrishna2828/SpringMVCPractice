package com.cg.eztrac.vo;

import java.util.Date;

public class AttachmentVO {
	
	private String url;
	private String remarks;
	private String createdBy;
	private String createdOnString;
	private Date createdOn;
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedOnString() {
		return createdOnString;
	}
	public void setCreatedOnString(String createdOnString) {
		this.createdOnString = createdOnString;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	@Override
	public String toString() {
		return "AttachmentVO [url=" + url + ", remarks=" + remarks + ", createdBy=" + createdBy + ", createdOnString="
				+ createdOnString + ", createdOn=" + createdOn + "]";
	}
	
}
