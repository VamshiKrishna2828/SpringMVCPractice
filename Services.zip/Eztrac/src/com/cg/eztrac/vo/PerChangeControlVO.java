package com.cg.eztrac.vo;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class PerChangeControlVO extends ChangeControlVO {
	
	private String perCCPhase;
	private String perCCCancellationDateString;
	private Date perCCCancellationDate;
	private String perCCCompletionDateString;
	private Date perCCCompletionDate;
	private String[] perCCTeamsInvolvedArray;
	
	private boolean perCCSendMailFlag;
	private boolean perCCOnsiteOnlyFlag;
	private boolean perCCMarkAllCCClosedFlag;
	
	private AttachmentVO perCCAttachmentVO;
	private List<AttachmentVO> attachmentList;

	public String getPerCCPhase() {
		return perCCPhase;
	}

	public void setPerCCPhase(String perCCPhase) {
		this.perCCPhase = perCCPhase;
	}

	public String getPerCCCancellationDateString() {
		return perCCCancellationDateString;
	}

	public void setPerCCCancellationDateString(String perCCCancellationDateString) {
		this.perCCCancellationDateString = perCCCancellationDateString;
	}

	public Date getPerCCCancellationDate() {
		return perCCCancellationDate;
	}

	public void setPerCCCancellationDate(Date perCCCancellationDate) {
		this.perCCCancellationDate = perCCCancellationDate;
	}

	public String getPerCCCompletionDateString() {
		return perCCCompletionDateString;
	}

	public void setPerCCCompletionDateString(String perCCCompletionDateString) {
		this.perCCCompletionDateString = perCCCompletionDateString;
	}

	public Date getPerCCCompletionDate() {
		return perCCCompletionDate;
	}

	public void setPerCCCompletionDate(Date perCCCompletionDate) {
		this.perCCCompletionDate = perCCCompletionDate;
	}

	public String[] getPerCCTeamsInvolvedArray() {
		return perCCTeamsInvolvedArray;
	}

	public void setPerCCTeamsInvolvedArray(String[] perCCTeamsInvolvedArray) {
		this.perCCTeamsInvolvedArray = perCCTeamsInvolvedArray;
	}

	public boolean isPerCCSendMailFlag() {
		return perCCSendMailFlag;
	}

	public void setPerCCSendMailFlag(boolean perCCSendMailFlag) {
		this.perCCSendMailFlag = perCCSendMailFlag;
	}

	public boolean isPerCCOnsiteOnlyFlag() {
		return perCCOnsiteOnlyFlag;
	}

	public void setPerCCOnsiteOnlyFlag(boolean perCCOnsiteOnlyFlag) {
		this.perCCOnsiteOnlyFlag = perCCOnsiteOnlyFlag;
	}

	public boolean isPerCCMarkAllCCClosedFlag() {
		return perCCMarkAllCCClosedFlag;
	}

	public void setPerCCMarkAllCCClosedFlag(boolean perCCMarkAllCCClosedFlag) {
		this.perCCMarkAllCCClosedFlag = perCCMarkAllCCClosedFlag;
	}

	public AttachmentVO getPerCCAttachmentVO() {
		return perCCAttachmentVO;
	}

	public void setPerCCAttachmentVO(AttachmentVO perCCAttachmentVO) {
		this.perCCAttachmentVO = perCCAttachmentVO;
	}

	public List<AttachmentVO> getAttachmentList() {
		return attachmentList;
	}

	public void setAttachmentList(List<AttachmentVO> attachmentList) {
		this.attachmentList = attachmentList;
	}

	@Override
	public String toString() {
		return "PerChangeControlVO [perCCPhase=" + perCCPhase + ", perCCCancellationDateString="
				+ perCCCancellationDateString + ", perCCCancellationDate=" + perCCCancellationDate
				+ ", perCCCompletionDateString=" + perCCCompletionDateString + ", perCCCompletionDate="
				+ perCCCompletionDate + ", perCCTeamsInvolvedArray=" + Arrays.toString(perCCTeamsInvolvedArray)
				+ ", perCCSendMailFlag=" + perCCSendMailFlag + ", perCCOnsiteOnlyFlag=" + perCCOnsiteOnlyFlag
				+ ", perCCMarkAllCCClosedFlag=" + perCCMarkAllCCClosedFlag + ", perCCAttachmentVO=" + perCCAttachmentVO
				+ ", attachmentList=" + attachmentList + "]";
	}

}
