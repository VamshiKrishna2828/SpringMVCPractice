package com.cg.eztrac.vo;

public class ResourceDetailsVO {
	
	private static final String CLASS_NAME = ResourceDetailsVO.class.getSimpleName();
	
	private Integer userId;
	private String name;
	private String resourceStatus;
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getResourceStatus() {
		return resourceStatus;
	}
	public void setResourceStatus(String resourceStatus) {
		this.resourceStatus = resourceStatus;
	}
	@Override
	public String toString() {
		return "ResourceDetailsVO [userId=" + userId + ", name=" + name + ", resourceStatus=" + resourceStatus + "]";
	}
	
}
