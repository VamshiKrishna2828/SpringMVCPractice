package com.cg.eztrac.vo;

import java.util.List;

import org.springframework.stereotype.Component;

@Component(value = "systemDetailsVO")
public class SystemDetailsVO {
	
	private int subAccountId;
	private int systemID;
	private String systemName;
	private List<SubSystemVO> subsystemDetails;
	
	/**
	 * @return the subAccountId
	 */
	public int getSubAccountId() {
		return subAccountId;
	}
	/**
	 * @param subAccountId the subAccountId to set
	 */
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}
	/**
	 * @return the systemID
	 */
	public int getSystemID() {
		return systemID;
	}
	/**
	 * @param systemID the systemID to set
	 */
	public void setSystemID(int systemID) {
		this.systemID = systemID;
	}
	/**
	 * @return the systemName
	 */
	public String getSystemName() {
		return systemName;
	}
	/**
	 * @param systemName the systemName to set
	 */
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	/**
	 * @return the subsystemDetails
	 */
	public List<SubSystemVO> getSubsystemDetails() {
		return subsystemDetails;
	}
	/**
	 * @param subsystemDetails the subsystemDetails to set
	 */
	public void setSubsystemDetails(List<SubSystemVO> subsystemDetails) {
		this.subsystemDetails = subsystemDetails;
	}
	
}