package com.cg.eztrac.handler;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.cg.eztrac.common.CommonUtility;
import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.context.ServletContextImpl;
import com.cg.eztrac.domain.InvoiceDO;
import com.cg.eztrac.domain.MenuDO;
import com.cg.eztrac.domain.RoleDO;
import com.cg.eztrac.domain.UserDO;
import com.cg.eztrac.exception.CustomException;
import com.cg.eztrac.vo.HomePageVO;
import com.cg.eztrac.vo.InvoiceVO;
import com.cg.eztrac.vo.LoginVO;
import com.cg.eztrac.vo.SectionVO;
import com.google.gson.Gson;

public class LoginHandler {
	String className=LoginHandler.class.getSimpleName();
	
	@SuppressWarnings("unchecked")
	public HomePageVO callSignInHandler(LoginVO loginVO, ServletContextImpl servletContextImpl, HttpSession httpSession) throws CustomException {
		String methodName="callSignInService";
		HomePageVO homePageVO = new HomePageVO ();
		
		UserDO userDO = null;
		MenuDO menuDO = new MenuDO();

		if (null != httpSession.getAttribute(ICommonConstants.USER_DETAILS)) {
			userDO = (UserDO) httpSession.getAttribute(ICommonConstants.USER_DETAILS);
		} else {
			userDO = new UserDO();
			CommonUtility.copyBeanProperties(loginVO, userDO);
			/** try-catch commented because might use in future for handling service failure*/
			/*try {*/
				userDO.authenticateUser();
		/*	} catch (Exception e) {
				throw new Exception();
			}*/
			httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
		}
		
		try {
			/** 100=success */
			if(userDO.isSuccess()) {
				Map<Integer,String> sortedRoles = getSortedRoles(userDO.getRoles());
				httpSession.setAttribute(ICommonConstants.PERMISSIABLE_ROLEID_SESSION, sortedRoles);
				Map.Entry<Integer,String> entry = sortedRoles.entrySet().iterator().next();
				Integer defaultRoleId = entry.getKey();
				httpSession.setAttribute(ICommonConstants.USER_ROLEID, defaultRoleId);
				/** get all permissible role_id and role_name*/
				if(null!=sortedRoles && !sortedRoles.isEmpty()){
					Map<Integer, Map<Integer, List<SectionVO>>> allRoleMenuAccebiltiy = (Map<Integer, Map<Integer, List<SectionVO>>>) servletContextImpl.getObjectFromServletContext(ICommonConstants.All_ROLE_MENU_ACCESS_CONTEXT);
					System.out.println(allRoleMenuAccebiltiy);
					
					/** get all role_menu */
					if(null != allRoleMenuAccebiltiy) {
						int roleId = (int)sortedRoles.keySet().toArray()[0];
						CommonUtility.formRoleRestrictionMatrix(roleId);
						/** get role_menu only for default role_id */
						Map<Integer, List<SectionVO>> menuBasedOnRole = allRoleMenuAccebiltiy.get(roleId);
						
						String menuMapJson = new Gson().toJson(menuBasedOnRole);
						System.out.println("*******************************************************");
						System.out.println(menuMapJson);
						/**  convert role_menu to json and put it into MenuDO */
						menuDO.setCustomizeJsonMap(menuMapJson);
						menuDO.setSwitchRoles(sortedRoles);
						menuBasedOnRole = null;
						userDO.setMenuDO(menuDO);
						List<RoleDO> roleDOList = userDO.getRoles();
						for(RoleDO currentRoleDO:roleDOList){
							if(currentRoleDO.getRoleId()==roleId){
								userDO.setCurrentRoleDO(currentRoleDO);
							}
						}
						userDO.setMenuDO(menuDO);
						httpSession.setAttribute(ICommonConstants.USER_DETAILS, userDO);
						homePageVO.setResultPage("home");
					} else {
						throw new CustomException("","Menu not formed");
					}
				}
			} else if(userDO.isInvalidPassword()) {
				/** 201=invalid pwd*/
				homePageVO.setErrorMsg("error.login.password.invalid");
				homePageVO.setResultPage(ICommonConstants.LOGIN);
				homePageVO.setField("password");
			}
			else if(userDO.isInvalidUsername()){
				/** 200=invalid username*/
				homePageVO.setErrorMsg("error.login.username.invalid");
				homePageVO.setResultPage(ICommonConstants.LOGIN); // constant
				homePageVO.setField("username");
			}
			else{
				homePageVO.setResultPage("login");
			}
			LoggerManager.writeInfoLog(className,methodName,ICommonConstants.LOGIN_SERVICE_LOG_KEY+"invoked rest service", "After calling (service)-loginSignIn()");
		} catch (CustomException e) {
			e.printStackTrace();
			LoggerManager.writeErrorLog(className, methodName, e.getMessage(),e , " Exception while callSignInService ");
		}
		return homePageVO;
	}

	private Map<Integer,String> getSortedRoles(List<RoleDO> rolePermissionDetails) {
		Map<Integer,String> roleNames =new HashMap<Integer,String>(); 
		for (RoleDO roleDO : rolePermissionDetails) {
			roleNames.put(roleDO.getRoleId(), roleDO.getRoleName());
		}
		return roleNames;
	}

	public InvoiceVO callSetInvoiceDateService(ServletContextImpl servletContextImpl, HttpSession httpSession) {
		String methodName="callSetInvoiceDateService";
		InvoiceVO invoiceVO=new InvoiceVO(); 
		UserDO userDO = new UserDO(); 
		InvoiceDO invoiceDO=new InvoiceDO();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		 List<InvoiceDO> invoiceDOList=new ArrayList<InvoiceDO>();
		try {
			invoiceDOList = invoiceDO.callSetInvoiceDateService(userDO);
		} catch (CustomException e) {
			e.printStackTrace();
		}
	/*	for (int i=0;i<invoiceDOList.size();i++){
			invoiceDO=invoiceDOList.get(i);
			invoiceVO.setInvoiceMonth(invoiceDO.getInvoiceMonth());
			invoiceVO.setInvoiceDt(invoiceDO.getInvoiceDt());
			invoiceVO.setInvoiceYear(invoiceDO.getInvoiceYear());
		}*/
		if(null!=invoiceDOList) {
			List<Date> sortedInvoiceDates=CommonUtility.formDate(invoiceDOList);
			List<String> sortedInvoiceStringDate= new ArrayList<String>();
			System.out.println("^^^^^^^^^^^^^^date^^^^^^^^^^");
			for (int i=0;i<sortedInvoiceDates.size();i++){
				sortedInvoiceStringDate.add(sdf.format(sortedInvoiceDates.get(i)))	;
				System.out.println(sortedInvoiceStringDate.get(i));
			}
			
			System.out.println(sortedInvoiceStringDate);
			
			String latestDate=sdf.format(sortedInvoiceDates.get(sortedInvoiceDates.size()-1));
			
			System.out.println(latestDate);
			String[] dates=latestDate.split("-");
			invoiceVO.setInvoiceMonth(Integer.parseInt(dates[1]));
			invoiceVO.setInvoiceDt(Integer.parseInt(dates[2]));
			invoiceVO.setInvoiceYear(Integer.parseInt(dates[0]));
			//httpSession.setAttribute(ICommonConstants.LATESTINVOICEDATEINDATEFORMATE, latestDate);
			httpSession.setAttribute(ICommonConstants.INVOICEDATELIST, sortedInvoiceStringDate);
			
			
			httpSession.setAttribute(ICommonConstants.LATESTINVOICEDATE, invoiceVO);
		}
		
		return invoiceVO;
	}
	
/*
	public List<SectionDetail> hardcodeSectionDetailsResponse() {
		
		List<SectionDetail> sectionDetailResponseList=new ArrayList<SectionDetail>();
		
		SectionDetail sectionDetailResponse=new SectionDetail();		
		sectionDetailResponse.setSectionId(11);
		sectionDetailResponse.setSectionName("PROJECTS|PER");
		sectionDetailResponse.setSectionType("1");
		HashMap<Integer, HashMap<String, List<SubSections>>> sectionDetailMap =new HashMap<Integer, HashMap<String, List<SubSections>>>();
		HashMap<String, List<SubSections>> subSectionMap=new HashMap<String, List<SubSections>>();
		List<SubSections> subectionlist=new ArrayList<SubSections>();
		SubSections subSection=new SubSections();
		subSection.setSubSectionId(100);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(101);
		subSection.setSubSectionName("EDIT");
		subSection.setEligibleFlag(true);
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(102);
		subSection.setSubSectionName("UPLOAD");
		subectionlist.add(subSection);
		subSectionMap.put("PROJECTS|PER", subectionlist);
		sectionDetailMap.put(11,subSectionMap);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(12);
		sectionDetailResponse.setSectionName("PROJECTS|BUILD");	
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(103);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(104);
		subSection.setSubSectionName("EDIT");
		subectionlist.add(subSection);	
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(13);
		sectionDetailResponse.setSectionName("Projects|TIMESHEET");	
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(105);
		subSection.setSubSectionName("TIMESHEET");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(14);
		sectionDetailResponse.setSectionName("Reports|Cards Services Report");	
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(106);
		subSection.setSubSectionName("INVOICE REPORTS");		
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(107);
		subSection.setSubSectionName("EFFORT VARIANCE REPORT");		
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(15);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(108);
		subSection.setSubSectionName("Missed Timesheet Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(109);
		subSection.setSubSectionName("Timesheet Reports");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(16);
		sectionDetailResponse.setSectionName("HELPDESK");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(110);
		subSection.setSubSectionName("Log Request");
		subectionlist.add(subSection);
		subSection=new SubSections();	
		subSection.setSubSectionId(111);
		subSection.setSubSectionName("Service Request");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(17);
		sectionDetailResponse.setSectionName("Administration");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(112);
		subSection.setSubSectionName("USERS");
		subectionlist.add(subSection);
		subSection=new SubSections();	
		subSection.setSubSectionId(113);
		subSection.setSubSectionName("SYSTEM");
		subectionlist.add(subSection);
		subSection=new SubSections();	
		subSection.setSubSectionId(114);
		subSection.setSubSectionName("SUB SYSTEM");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(18);
		sectionDetailResponse.setSectionName("Finance And Business");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(115);
		subSection.setSubSectionName("Travel expenses and others");	
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(19);
		sectionDetailResponse.setSectionName("Invoice and Billing");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();	
		subSection.setSubSectionId(116);
		subSection.setSubSectionName("INVOICE REPORTS");	
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		return sectionDetailResponseList;
	}
	
	public List<RoleDetails> hardcodeLoginresponse() {
		
		List<RoleDetails> rolePermisssionList = new  ArrayList<RoleDetails>();
		RoleDetails rolePermissionDetails=new RoleDetails();
		SectionDetail sectionDetailResponse=new SectionDetail();
		
		HashMap<Integer, HashMap<String, List<SubSections>>> sectionDetailMap = new HashMap<Integer, HashMap<String, List<SubSections>>>();
		HashMap<String, List<SubSections>> sectionMap = new HashMap<String, List<SubSections>>();
		*//*************** list[0] of rolePermission **********************//*
		rolePermissionDetails.setRoleId(2);
		rolePermissionDetails.setRoleName("PMO");
		List<SectionDetail> sectionDetailResponseList=new ArrayList<SectionDetail>();
		
		sectionDetailResponse.setSectionId(11);
		sectionDetailResponse.setSectionName("PROJECTS|PER");
		sectionDetailResponse.setSectionType("1");
		List<SubSections> subectionlist=new ArrayList<SubSections>();
		SubSections subSection=new SubSections();
		subSection.setSubSectionId(100);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(101);
		subSection.setSubSectionName("EDIT");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionMap.put(sectionDetailResponse.getSectionName(), subectionlist);
		sectionDetailMap.put(sectionDetailResponse.getSectionId(), sectionMap);
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(12);
		sectionDetailResponse.setSectionName("PROJECTS|build");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(103);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(13);
		sectionDetailResponse.setSectionName("PROJECTS|timesheet");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(105);
		subSection.setSubSectionName("Timesheet");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(14);
		sectionDetailResponse.setSectionName("Reports|Cards Services Report");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(106);
		subSection.setSubSectionName("Invoice Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(107);
		subSection.setSubSectionName("Effort Variance Report");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(15);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(108);
		subSection.setSubSectionName("Missed Timesheet Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(109);
		subSection.setSubSectionName("Timesheet Reports");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(16);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(110);
		subSection.setSubSectionName("Log Request");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(111);
		subSection.setSubSectionName("Service Request");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);		
		
		rolePermissionDetails.setSectionDetailResponse(sectionDetailResponseList);
		rolePermisssionList.add(rolePermissionDetails);
		*//*************** End of  list[0] of rolePermission **********************//*
		
		
		*//*************** Second list of rolePermission **********************//*
		rolePermissionDetails.setRoleId(3);
		rolePermissionDetails.setRoleName("PM");
		sectionDetailResponseList=new ArrayList<SectionDetail>();
		
		sectionDetailResponse.setSectionId(11);
		sectionDetailResponse.setSectionName("PROJECTS|PER");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(100);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(101);
		subSection.setSubSectionName("EDIT");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);			
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(12);
		sectionDetailResponse.setSectionName("PROJECTS|build");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(103);
		subSection.setSubSectionName("NEW");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(13);
		sectionDetailResponse.setSectionName("PROJECTS|timesheet");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(105);
		subSection.setSubSectionName("Timesheet");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(14);
		sectionDetailResponse.setSectionName("Reports|Cards Services Report");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(106);
		subSection.setSubSectionName("Invoice Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(107);
		subSection.setSubSectionName("Effort Variance Report");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(15);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(108);
		subSection.setSubSectionName("Missed Timesheet Reports");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(109);
		subSection.setSubSectionName("Timesheet Reports");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);
		
		sectionDetailResponse=new SectionDetail();
		sectionDetailResponse.setSectionId(16);
		sectionDetailResponse.setSectionName("Reports|TimeSheet Reports");
		sectionDetailResponse.setSectionType("1");
		subectionlist=new ArrayList<SubSections>();
		subSection=new SubSections();
		subSection.setSubSectionId(110);
		subSection.setSubSectionName("Log Request");
		subectionlist.add(subSection);
		subSection=new SubSections();
		subSection.setSubSectionId(111);
		subSection.setSubSectionName("Service Request");
		subectionlist.add(subSection);
		sectionDetailResponse.setSubSectionList(subectionlist);	
		sectionDetailResponseList.add(sectionDetailResponse);		
		
		rolePermissionDetails.setSectionDetailResponse(sectionDetailResponseList);
		rolePermisssionList.add(rolePermissionDetails);
		*//*************** End of Second list of rolePermission **********************//*
		
//		loginInfoResponse.setRolePersmission(rolePermisssionList);
		return rolePermisssionList;
	}*/
}
