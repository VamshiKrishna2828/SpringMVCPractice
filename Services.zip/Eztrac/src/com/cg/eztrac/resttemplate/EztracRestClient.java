package com.cg.eztrac.resttemplate;

import java.text.DateFormat;
import java.util.Date;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.cg.eztrac.common.ICommonConstants;
import com.cg.eztrac.common.IRestServiceRequest;
import com.cg.eztrac.common.LoggerManager;
import com.cg.eztrac.exception.CustomException;

public class EztracRestClient {
	static final String CLASS_NAME = EztracRestClient.class.getSimpleName();

	@SuppressWarnings({ "unused", "unchecked" })
	public static Object invokeRestService(IRestServiceRequest requestObject, String requestServiceURL, String responseObjectType) throws CustomException{
		final String methodName = "invokeRestService ";
		String defaultRestServiceMethod = "POST";
		String serviceMethodType = "";
		HttpMethod serviceMethod = null;
		if (null == serviceMethodType) {
			serviceMethod = HttpMethod.valueOf(serviceMethodType);
		} else {
			serviceMethod = HttpMethod.valueOf(defaultRestServiceMethod);
		}
		MultiValueMap<String, Object> headers = new LinkedMultiValueMap<String, Object>();
		headers.add("Accept", MediaType.APPLICATION_JSON.toString());
		headers.add("Content-Type", MediaType.APPLICATION_JSON.toString());
		@SuppressWarnings("rawtypes")
		HttpEntity request = new HttpEntity(requestObject, headers);
		ResponseEntity<?> response = null;
		RestTemplate restTemplateObj = new RestTemplate();
		Object postForObject = null;
		Object responseObject = null;
		long currentTimeMillis = System.currentTimeMillis();
		String tsBeforeService = DateFormat.getDateTimeInstance().format(new Date(currentTimeMillis));
		HttpHeaders header = null;
		try {
		response = restTemplateObj.exchange(requestServiceURL, HttpMethod.valueOf(defaultRestServiceMethod), request, Class.forName(responseObjectType));
		header = response.getHeaders();
		if(null!=header.get(ICommonConstants.REASON_PHRASE)) {
			System.out.println("headerrrrrrrrrrrrr"+header.get(ICommonConstants.REASON_PHRASE)+"status code"+response.getStatusCode());
		}
		
		String statusCode = String.valueOf(response.getStatusCode());
		if(statusCode.equals(ICommonConstants.HTTPSTATUS_400) || statusCode.equals(ICommonConstants.HTTPSTATUS_404) || 
				statusCode.equals(ICommonConstants.HTTPSTATUS_405) || statusCode.equals(ICommonConstants.HTTPSTATUS_409) || 
				statusCode.equals(ICommonConstants.HTTPSTATUS_500) || statusCode.equals(ICommonConstants.HTTPSTATUS_502) || 
				statusCode.equals(ICommonConstants.HTTPSTATUS_503)) 
		{
			throw new CustomException(statusCode,String.valueOf(header.get(ICommonConstants.REASON_PHRASE)));
		}
		
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new CustomException("","Service Exception Occured!!!");
			
		}
		currentTimeMillis = System.currentTimeMillis();
		String tsAfterService = DateFormat.getDateTimeInstance().format(currentTimeMillis);
		if (null != response) {
			 responseObject = response.getBody();
		}
			 
		LoggerManager.writeServerInfoLog(requestServiceURL, requestObject.getTokenId(), tsBeforeService , tsAfterService, ""+response.getStatusCodeValue());
		
		return responseObject;
	}
}
