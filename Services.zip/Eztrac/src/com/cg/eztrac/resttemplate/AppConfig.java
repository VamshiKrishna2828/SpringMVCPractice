package com.cg.eztrac.resttemplate;

import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:appurlcontroller.properties")
public class AppConfig implements EnvironmentAware {
	private Environment environment;

    @Override
    public void setEnvironment(final Environment environment) {
        this.environment = environment;
    }

    public void myMethod(String str) {
        final String myPropertyValue = environment.getProperty(str);
    }
	
}
