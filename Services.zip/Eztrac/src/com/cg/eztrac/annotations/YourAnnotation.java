/**
 * 
 */
package com.cg.eztrac.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Payload;

/**
 * @author nageorge
 *
 */
	@Target(value=ElementType.FIELD)
	@Retention(RetentionPolicy.RUNTIME)
	@Documented
	// @Constraint(validatedBy=YourValidator.class)
	public @interface YourAnnotation {
		
		String message() default "Your Validation message goes here";
	    Class<?>[] groups() default {};
	    Class<? extends Payload>[] payload() default {};
	}



