package DAO;
// Generated Dec 26, 2017 7:22:42 PM by Hibernate Tools 5.2.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class UserView.
 * @see DAO.UserView
 * @author Hibernate Tools
 */
@Stateless
public class UserViewHome {

	private static final Log log = LogFactory.getLog(UserViewHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(UserView transientInstance) {
		log.debug("persisting UserView instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(UserView persistentInstance) {
		log.debug("removing UserView instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public UserView merge(UserView detachedInstance) {
		log.debug("merging UserView instance");
		try {
			UserView result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public UserView findById(UserViewId id) {
		log.debug("getting UserView instance with id: " + id);
		try {
			UserView instance = entityManager.find(UserView.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
