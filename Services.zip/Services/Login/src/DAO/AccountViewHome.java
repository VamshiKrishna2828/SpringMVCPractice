package DAO;
// Generated Dec 26, 2017 7:22:42 PM by Hibernate Tools 5.2.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class AccountView.
 * @see DAO.AccountView
 * @author Hibernate Tools
 */
@Stateless
public class AccountViewHome {

	private static final Log log = LogFactory.getLog(AccountViewHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(AccountView transientInstance) {
		log.debug("persisting AccountView instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(AccountView persistentInstance) {
		log.debug("removing AccountView instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public AccountView merge(AccountView detachedInstance) {
		log.debug("merging AccountView instance");
		try {
			AccountView result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public AccountView findById(AccountViewId id) {
		log.debug("getting AccountView instance with id: " + id);
		try {
			AccountView instance = entityManager.find(AccountView.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
