package com.capgemini.LoginService;
public class CommonConstants {

	public static final String STATUS_ACTIVE = "A";
	public static final String STATUS_MIGRATION = "M";
	public static final String SUCCESS_CODE = "SL1000";
	public static final String SUCCESS_DESC = "The request was processed successfully.";
/*	public static final String EMPTY_RESULTSET_CODE = "200";
	public static final String EMPTY_RESULTSET_DESC="No matching records found!";*/
	public static final String INVALID_USER_CODE = "SL1001";
	public static final String INVALID_USER_DESC="User authentication failed:Invalid User Details";
	public static final String YYYY_MM_DD_FORMAT = "yyyy-MM-dd";
	public static final String SERVICE_ERR_CD = "FL1001";
	public static final String SERVICE_ERR_MSG = "Error occurred in webservice";
	public static final String REASON_PHRASE = "Reason-Phrase";
	private CommonConstants() {}
}
