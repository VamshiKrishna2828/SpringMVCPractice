package com.capgemini.LoginService;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Login.Responsemodel.LoginInfoRes;
import com.capgemini.Login.LoginInfoReq;

@RestController
@RequestMapping(value = "/login")
public class LoginController {
	

	/*@RequestMapping(method = RequestMethod.POST)
	public @ResponseBody
	LoginInfoRes login(@RequestBody LoginInfoReq loginInfo)
	{
		LoginInfoRes loginReturn = null;
		TransformLogin login = new TransformLogin();
		try{
		loginReturn = login.validateUser(loginInfo.getLoginId(), loginInfo.getPassowrd());
		}
		catch(Exception e) {
			constructErrorResponse(loginInfo, loginReturn);
		} 
		return loginReturn;
	    
	}*/
	
	@RequestMapping(method = RequestMethod.POST)
	@ResponseStatus
	public ResponseEntity<LoginInfoRes> login(@RequestBody LoginInfoReq loginInfo) {
		LoginInfoRes loginReturn = null;
		HttpHeaders responseHeaders = null;
		TransformLogin login = new TransformLogin();
		try {
			 loginReturn = login.validateUser(loginInfo.getLoginId(), loginInfo.getPassowrd());
		    } 
		catch (Exception e) {
			    constructErrorResponse(loginInfo, loginReturn);
		 }
		if (loginReturn.getResponseCode().equalsIgnoreCase(CommonConstants.INVALID_USER_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.INVALID_USER_DESC);
			return new ResponseEntity<LoginInfoRes>(responseHeaders,HttpStatus.NOT_FOUND);
		} else if(loginReturn.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			return new ResponseEntity<LoginInfoRes>(loginReturn,responseHeaders,HttpStatus.OK);
		}
		else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			return new ResponseEntity<LoginInfoRes>(loginReturn,responseHeaders,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	public void constructErrorResponse(LoginInfoReq loginInfo, LoginInfoRes resp) {
		resp.setTokenID(loginInfo.getTokenId());
		resp.setResponseCode(CommonConstants.SERVICE_ERR_CD);
		resp.setResponseDescription(CommonConstants.SERVICE_ERR_MSG);
	}
}
