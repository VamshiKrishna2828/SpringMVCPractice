package com.capgemini.LoginService;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class CommonUtil {

	private static ObjectWriter om = new ObjectMapper().writerWithDefaultPrettyPrinter();
	
	private CommonUtil() {}
	
	public static String getJsonString(Object object) throws JsonProcessingException {
		return om.writeValueAsString(object);
	}
	
	public static String convertDateToString(Date date, String toFormat) {
		if (date == null || StringUtils.isEmpty(toFormat)) { return null; }
		String returnVal = null;
		SimpleDateFormat sdf = new SimpleDateFormat(toFormat);
		returnVal = sdf.format(date);
		return returnVal;
	}
	
	public static Date convertStringToDate(String dateString, String toFormat) throws ParseException {
		if (StringUtils.isEmpty(dateString) || StringUtils.isEmpty(toFormat)) { return null; }
		SimpleDateFormat sdf = new SimpleDateFormat(toFormat);
		Date returnVal = sdf.parse(dateString);
		return returnVal;
	}
	
	public static String getCurrentSystemDate(String toFormat)
	{
		Calendar cal = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat(toFormat);
		return dateFormat.format(cal.getTime());
	}

}
