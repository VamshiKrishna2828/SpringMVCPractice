package com.capgemini.LoginService;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.Login.HomePageData;
import com.capgemini.Login.RolePersmission;
import com.capgemini.Login.SubSections;
import com.capgemini.Login.UserDetail;
import com.capgemini.Login.UserLocations;
import com.capgemini.Login.Responsemodel.LoginInfoRes;

import DAO.PurchaseOrder;
import DAO.SubSection;
import DAO.User;
import DAO.UserDAOImpl;
import DAO.UserLocation;
import DAO.UserRole;


/*
 Fetch user details from user table and validate user login details
 */

public class TransformLogin {

	public LoginInfoRes validateUser(String userloginId,String userpassword) {
		DAO.User data = null;
		LoginInfoRes loginReturn = new LoginInfoRes();
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
		Query  personList = session.createQuery("from User where loginId=:loginId and password=:password and statusCd=:statusCd");
		personList.setString("loginId",userloginId);
		personList.setString("password", userpassword);
		personList.setString("statusCd","A");
		@SuppressWarnings("unchecked")
		List<User> list = personList.list();
	    if (list == null || list.isEmpty()) {
	    	loginReturn.setResponseCode(CommonConstants.INVALID_USER_CODE);
			loginReturn.setResponseDescription(CommonConstants.INVALID_USER_DESC);
			session.flush();
			session.close();
			context.close();
			return loginReturn;
	    }
		data = (DAO.User)list.get(0);
		if(data != null)
		{
				Set<UserLocation> userLocations = new HashSet<UserLocation>(0);
				UserDetail userDedail = new UserDetail();
				userDedail.setEmailId(data.getEmailAddress());
				userDedail.setEmployeeCode(data.getEmployeeCd());
				userDedail.setInductionFlag(data.getInductionFlag());
				userDedail.setClientReportingFlag(data.getClientReportingFlag());
				userDedail.setTelMobileNum(data.getTelNoMobile());
				userDedail.setTelOfficeNum(data.getTelNoOffice());
				userDedail.setUsername(data.getName());
				userLocations = data.getUserLocations();
				List<UserLocations> userlocList = new ArrayList<UserLocations>(data.getUserLocations().size());
				if (!userLocations.isEmpty())
				{
				   for(UserLocation userLocation : userLocations)
				     {
					   if(userLocation.getId().getStatusCd().equalsIgnoreCase("A"))
					   {
						   UserLocations userloc = new UserLocations();
						   userloc.setLocationId(userLocation.getId().getLocationId());
						   userloc.setOnsiteFlag(userLocation.getId().getOnsiteFlag());
						   userloc.setStartDate(CommonUtil.convertDateToString(userLocation.getId().getStartDate(), CommonConstants.YYYY_MM_DD_FORMAT));
						   userloc.setEndDate(CommonUtil.convertDateToString(userLocation.getId().getEndDate(), CommonConstants.YYYY_MM_DD_FORMAT)); 
						   userloc.setLocation(userLocation.getParamValue().getName());
						   userlocList.add(userloc);
					   }
				     }
				}
				userDedail.setUserId(data.getUserId());
				userDedail.setUnitAssigned(data.getSubAccount().getAccount().getAccountName());
				userDedail.setClientReportingFlag(data.getClientReportingFlag());
				userDedail.setClientSsoId(data.getClientSsoId());
				userDedail.setInductionFlag(data.getInductionFlag());
				userDedail.setAccountName(data.getSubAccount().getAccount().getAccountName());
				userDedail.setSubAccountId(data.getSubAccount().getSubAccountId());
				userDedail.setSubAccountName(data.getSubAccount().getSubAccountName());
				userDedail.setGdcName(data.getSubAccount().getSbu().getGdc().getGdcName());
				userDedail.setSbu(data.getSubAccount().getSbu().getSbuName());
     			RolePersmission role = null;
				List<RolePersmission> sublistRole = new ArrayList<RolePersmission>(data.getUserRolesForUserId().size());
				Iterator<UserRole> iter = data.getUserRolesForUserId().iterator();//check status Y
				while (iter.hasNext()) {
					role = new RolePersmission();
					UserRole roleDAO = ((UserRole)iter.next());
					role.setRoleId(roleDAO.getRole().getRoleId());
					role.setRoleName(roleDAO.getRole().getRoleDesc());
					List<SubSections> sublistSection = new ArrayList<SubSections>(roleDAO.getRole().getSubSections().size());
					Iterator<SubSection> iter1 = roleDAO.getRole().getSubSections().iterator();	
					while (iter1.hasNext()) {
						SubSections sub = new SubSections();
						SubSection subnext = (SubSection)iter1.next();
						sub.setSubSectionId(subnext.getSubSectionId());
						sub.setSubSectionName(subnext.getSubSectionName());
						sublistSection.add(sub);
				}
				sublistRole.add(role);
				}
				loginReturn.setUserDedail(userDedail);
				loginReturn.setUserlocations(userlocList);
				loginReturn.setRolepermission(sublistRole);
				loginReturn.setResponseCode(CommonConstants.SUCCESS_CODE);
				loginReturn.setResponseDescription(CommonConstants.SUCCESS_DESC);
		}
		session.flush();
		session.close();
		context.close();	
		return loginReturn;
	}
	
}
