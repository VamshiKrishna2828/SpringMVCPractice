package com.capgemini.Login.Responsemodel;


import java.util.List;

import com.capgemini.Login.Account;
import com.capgemini.Login.GDC;
import com.capgemini.Login.HomePageData;
import com.capgemini.Login.RolePersmission;
import com.capgemini.Login.UserDetail;
import com.capgemini.Login.UserLocations;



public class LoginInfoRes {

	private UserDetail userDedail;
	//private HomePageData homePageData;
	private List<RolePersmission> rolepermission;
	private List<UserLocations> userlocations;
	private String responseCode;
	private String responseDescription;
	private String tokenID;
	public String getTokenID() {
		return tokenID;
	}
	public void setTokenID(String tokenID) {
		this.tokenID = tokenID;
	}
	public UserDetail getUserDedail() {
		return userDedail;
	}
	public void setUserDedail(UserDetail userDedail) {
		this.userDedail = userDedail;
	}
/*	public HomePageData getHomePageData() {
		return homePageData;
	}
	public void setHomePageData(HomePageData homePageData) {
		this.homePageData = homePageData;
	}
	*/
	public List<RolePersmission> getRolepermission() {
		return rolepermission;
	}
	public void setRolepermission(List<RolePersmission> rolepermission) {
		this.rolepermission = rolepermission;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	public List<UserLocations> getUserlocations() {
		return userlocations;
	}
	public void setUserlocations(List<UserLocations> userlocations) {
		this.userlocations = userlocations;
	}
	
}
