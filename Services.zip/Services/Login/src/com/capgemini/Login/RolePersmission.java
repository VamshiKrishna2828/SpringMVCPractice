package com.capgemini.Login;

import java.util.List;

public class RolePersmission {
	
	Integer roleId;
	String roleName;
//	List<SubSections> subSection;
////	String token;
////	String sessionId;
////	String channel;
//	private String responseCode;
//	private String responseDescription;
	
	
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	
	
	
	
	
	

}
