package com.capgemini.Login;

public class SubSections {
	private int subSectionId;
	//private ParamValue paramValue;
	//private Section section;
	private String subSectionName;
	private String statusCd;
	//private Date createdOn;
	public int getSubSectionId() {
		return subSectionId;
	}
	public void setSubSectionId(int subSectionId) {
		this.subSectionId = subSectionId;
	}
	public String getSubSectionName() {
		return subSectionName;
	}
	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
}
