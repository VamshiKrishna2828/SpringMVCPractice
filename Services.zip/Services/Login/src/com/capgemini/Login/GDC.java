package com.capgemini.Login;

public class GDC {
	private int gdcId;
	private String gdcName;
	private String statusCd;
	public int getGdcId() {
		return gdcId;
	}
	public void setGdcId(int gdcId) {
		this.gdcId = gdcId;
	}
	public String getGdcName() {
		return gdcName;
	}
	public void setGdcName(String gdcName) {
		this.gdcName = gdcName;
	}
	public String getStatusCd() {
		return statusCd;
	}
	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}

}
