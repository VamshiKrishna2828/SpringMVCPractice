package com.capgemini.Login;

import java.util.HashSet;
import java.util.Set;

import DAO.UserLocation;

public class UserDetail {
	/*private String eventDate;*/
	private String username;
    private String emailId;
	//private String location;
	private String employeeCode;
	private String unitAssigned;
	private String gdcName;
	private String accountName;
	private String subAccountName;
	private String sbu;
	private int userId;
	private String clientReportingFlag;
	private String clientSsoId;
	private String inductionFlag;
	private String telOfficeNum;
	private String telMobileNum;
	private int subAccountId;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getClientSsoId() {
		return clientSsoId;
	}
	public void setClientSsoId(String clientSsoId) {
		if(clientSsoId != null)
		this.clientSsoId = clientSsoId;
	}
/*	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}*/
/*	public String getUserName() {
		return username;
	}
	public void setUserName(String userName) {
		this.username = userName;
	}*/
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
/*	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}*/
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getUnitAssigned() {
		return unitAssigned;
	}
	public void setUnitAssigned(String unitAssigned) {
		this.unitAssigned = unitAssigned;
	}
	public String getGdcName() {
		return gdcName;
	}
	public void setGdcName(String gdcName) {
		this.gdcName = gdcName;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	
	public String getSubAccountName() {
		return subAccountName;
	}
	public void setSubAccountName(String subAccountName) {
		this.subAccountName = subAccountName;
	}
	public String getSbu() {
		return sbu;
	}
	public void setSbu(String sbu) {
		this.sbu = sbu;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		if(userId != 0)
		this.userId = userId;
	}
	public String getClientReportingFlag() {
		return clientReportingFlag;
	}
	public void setClientReportingFlag(String clientReportingFlag) {
		this.clientReportingFlag = clientReportingFlag;
	}
	
	public String getInductionFlag() {
		return inductionFlag;
	}
	public void setInductionFlag(String inductionFlag) {
		if(inductionFlag != null)
		this.inductionFlag = inductionFlag;
	}
	public String getTelOfficeNum() {
		return telOfficeNum;
	}
	public void setTelOfficeNum(String telOfficeNum) {
		this.telOfficeNum = telOfficeNum;
	}
	public String getTelMobileNum() {
		return telMobileNum;
	}
	public void setTelMobileNum(String telMobileNum) {
		this.telMobileNum = telMobileNum;
	}
	public int getSubAccountId() {
		return subAccountId;
	}
	public void setSubAccountId(int subAccountId) {
		this.subAccountId = subAccountId;
	}
	
	
}
