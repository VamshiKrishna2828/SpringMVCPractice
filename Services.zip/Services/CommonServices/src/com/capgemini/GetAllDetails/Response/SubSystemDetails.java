package com.capgemini.GetAllDetails.Response;

public class SubSystemDetails {
	    Integer SubSystemID;
	    String subSystemName;
	    String subSystemTech;
	    String subSystemEmail;
		
		public Integer getSubSystemID() {
			return SubSystemID;
		}
		public void setSubSystemID(Integer subSystemID) {
			SubSystemID = subSystemID;
		}
		public String getSubSystemName() {
			return subSystemName;
		}
		public void setSubSystemName(String subSystemName) {
			this.subSystemName = subSystemName;
		}
		public String getSubSystemTech() {
			return subSystemTech;
		}
		public void setSubSystemTech(String subSystemTech) {
			this.subSystemTech = subSystemTech;
		}
		public String getSubSystemEmail() {
			return subSystemEmail;
		}
		public void setSubSystemEmail(String subSystemEmail) {
			this.subSystemEmail = subSystemEmail;
		}
}
