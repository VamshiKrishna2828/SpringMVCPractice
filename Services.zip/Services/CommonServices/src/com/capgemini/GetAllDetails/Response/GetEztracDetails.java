package com.capgemini.GetAllDetails.Response;

import java.util.List;

public class GetEztracDetails {
	private SectionsRes sectionRes;
	private SystemRes sysRes;
	private ParamDetailsRes paramRes;
	private NotificationRes notRes;
	private InvoiceCutOffRes invRes;
	private ResourceRes resourceRes;
	private RolePermissionRes roleRes;
	private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	public SectionsRes getSectionRes() {
		return sectionRes;
	}
	public void setSectionRes(SectionsRes sectionRes) {
		this.sectionRes = sectionRes;
	}
	public SystemRes getSysRes() {
		return sysRes;
	}
	public void setSysRes(SystemRes sysRes) {
		this.sysRes = sysRes;
	}
	public ParamDetailsRes getParamRes() {
		return paramRes;
	}
	public void setParamRes(ParamDetailsRes paramRes) {
		this.paramRes = paramRes;
	}
	public NotificationRes getNotRes() {
		return notRes;
	}
	public void setNotRes(NotificationRes notRes) {
		this.notRes = notRes;
	}
	public InvoiceCutOffRes getInvRes() {
		return invRes;
	}
	public void setInvRes(InvoiceCutOffRes invRes) {
		this.invRes = invRes;
	}
	public ResourceRes getResourceRes() {
		return resourceRes;
	}
	public void setResourceRes(ResourceRes resourceRes) {
		this.resourceRes = resourceRes;
	}
	public RolePermissionRes getRoleRes() {
		return roleRes;
	}
	public void setRoleRes(RolePermissionRes roleRes) {
		this.roleRes = roleRes;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	
}
