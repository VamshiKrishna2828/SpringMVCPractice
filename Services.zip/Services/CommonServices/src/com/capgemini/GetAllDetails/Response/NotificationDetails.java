package com.capgemini.GetAllDetails.Response;

public class NotificationDetails {
	
	private Integer notifyTypeId;
	private String descripton;
	private String template;
	public Integer getNotifyTypeId() {
		return notifyTypeId;
	}
	public void setNotifyTypeId(Integer notifyTypeId) {
		this.notifyTypeId = notifyTypeId;
	}
	public String getDescripton() {
		return descripton;
	}
	public void setDescripton(String descripton) {
		this.descripton = descripton;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}

}
