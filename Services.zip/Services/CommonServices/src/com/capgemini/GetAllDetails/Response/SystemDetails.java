package com.capgemini.GetAllDetails.Response;

import java.util.Date;
import java.util.List;



public class SystemDetails {
	Integer systemID;
	String systemName;
   
    List<SubSystemDetails> subsystemDetails;
	public Integer getSystemID() {
		return systemID;
	}
	public void setSystemID(Integer systemID) {
		this.systemID = systemID;
	}
	public String getSystemName() {
		return systemName;
	}
	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}
	
	public List<SubSystemDetails> getSubsystemDetails() {
		return subsystemDetails;
	}
	public void setSubsystemDetails(List<SubSystemDetails> subsystemDetails) {
		this.subsystemDetails = subsystemDetails;
	}
	
    
    
}
