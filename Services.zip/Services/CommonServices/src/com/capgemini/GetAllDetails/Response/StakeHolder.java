package com.capgemini.GetAllDetails.Response;

public class StakeHolder {
	Integer stakeHolderId;
	public Integer getStakeHolderId() {
		return stakeHolderId;
	}
	public void setStakeHolderId(Integer stakeHolderId) {
		this.stakeHolderId = stakeHolderId;
	}
	public Integer getStakeHolderType() {
		return stakeHolderType;
	}
	public void setStakeHolderType(Integer stakeHolderType) {
		this.stakeHolderType = stakeHolderType;
	}
	Integer stakeHolderType;
	

}
