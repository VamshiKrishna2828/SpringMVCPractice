package com.capgemini.GetAllDetails.Response;

import java.util.List;

public class NotificationRes {
	
	List<NotificationDetails> notificationDetails;
	private String tokenId;
	private String channelId;
	private String responseCode;
	private String responseDescription;
	public List<NotificationDetails> getNotificationDetails() {
		return notificationDetails;
	}
	public void setNotificationDetails(List<NotificationDetails> notificationDetails) {
		this.notificationDetails = notificationDetails;
	}
	public String getTokenId() {
		return tokenId;
	}
	public void setTokenId(String tokenId) {
		this.tokenId = tokenId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseDescription() {
		return responseDescription;
	}
	public void setResponseDescription(String responseDescription) {
		this.responseDescription = responseDescription;
	}
	

}
