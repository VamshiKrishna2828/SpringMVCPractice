package com.capgemini.GetAllDetails.Response;

public class AllResourceRes {

}
