package com.capgemini.GetAllDetails.Response;

public class ParamValueDetails {
	Integer paramvalueID;
	   String paramName;
	   String paramValue;
	
	public Integer getParamvalueID() {
		return paramvalueID;
	}
	public void setParamvalueID(Integer paramvalueID) {
		this.paramvalueID = paramvalueID;
	}
	
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getParamValue() {
		return paramValue;
	}
	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

}
