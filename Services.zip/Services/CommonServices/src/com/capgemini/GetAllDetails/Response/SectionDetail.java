package com.capgemini.GetAllDetails.Response;

import java.util.List;

public class SectionDetail {
	    
		Integer sectionID;
		Integer sectionType;
		String sectionName;
		List<SubSectionDetails> subSection;
		
		public Integer getSectionType() {
			return sectionType;
		}
		public void setSectionType(Integer sectionType) {
			this.sectionType = sectionType;
		}
		public Integer getSectionID() {
			return sectionID;
		}
		public void setSectionID(Integer sectionID) {
			this.sectionID = sectionID;
		}
		public String getSectionName() {
			return sectionName;
		}
		public void setSectionName(String sectionName) {
			this.sectionName = sectionName;
		}
		public List<SubSectionDetails> getSubSection() {
			return subSection;
		}
		public void setSubSection(List<SubSectionDetails> subSection) {
			this.subSection = subSection;
		}
		
		
		

}
