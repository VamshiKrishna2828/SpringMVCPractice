package com.capgemini.GetAllDetails.Response;

import java.util.List;

public class StakeHolderRes {
	
List<StakeHolder> stakeHolderDetail;

public List<StakeHolder> getStakeHolderDetail() {
	return stakeHolderDetail;
}

public void setStakeHolderDetail(List<StakeHolder> stakeHolderDetail) {
	this.stakeHolderDetail = stakeHolderDetail;
} 

}
