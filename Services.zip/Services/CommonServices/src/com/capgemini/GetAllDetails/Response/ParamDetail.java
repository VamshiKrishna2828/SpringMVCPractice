package com.capgemini.GetAllDetails.Response;

import java.util.List;



public class ParamDetail {
   Integer paramTypeID;
   String paramTypeName;
 
   List<ParamValueDetails> paramValue;
   public Integer getParamTypeID() {
	return paramTypeID;
}
public void setParamTypeID(Integer paramTypeID) {
	this.paramTypeID = paramTypeID;
}
public String getParamTypeName() {
	return paramTypeName;
}
public void setParamTypeName(String paramTypeName) {
	this.paramTypeName = paramTypeName;
}

public List<ParamValueDetails> getParamValue() {
	return paramValue;
}
public void setParamValue(List<ParamValueDetails> paramValue) {
	this.paramValue = paramValue;
}


   
   
}
