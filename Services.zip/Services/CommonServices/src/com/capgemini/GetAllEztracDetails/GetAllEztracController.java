package com.capgemini.GetAllEztracDetails;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.GetAllDetails.Request.Request;
import com.capgemini.GetAllDetails.Response.GetEztracDetails;
import com.capgemini.GetAllDetails.Response.InvoiceCutOffRes;
import com.capgemini.GetAllDetails.Response.NotificationRes;
import com.capgemini.GetAllDetails.Response.ParamDetailsRes;
import com.capgemini.GetAllDetails.Response.ResourceRes;
import com.capgemini.GetAllDetails.Response.RolePermissionRes;
import com.capgemini.GetAllDetails.Response.SectionsRes;
import com.capgemini.GetAllDetails.Response.SystemRes;
import com.capgemini.GetAllEztracDetails.tranform.CommonConstants;
import com.capgemini.GetAllEztracDetails.tranform.TransFormInvoiceCutoff;
import com.capgemini.GetAllEztracDetails.tranform.TransFormNotificationData;
import com.capgemini.GetAllEztracDetails.tranform.TransformParamDetails;
import com.capgemini.GetAllEztracDetails.tranform.TransformResourceData;
import com.capgemini.GetAllEztracDetails.tranform.TransformRolePermissionDetails;
import com.capgemini.GetAllEztracDetails.tranform.TransformSectionDetails;
import com.capgemini.GetAllEztracDetails.tranform.TransformSystemDetails;

@RestController
public class GetAllEztracController {
	private GetEztracDetails response;

	@RequestMapping(method = RequestMethod.POST, value = "/getAllEztracDetail")
	public @ResponseBody GetEztracDetails getAllEztracDetailPost(@RequestBody Request request) {
		/*
		 * response = new GetEztracDetails();
		 * 
		 * response.setSysRes(getAllSystemDetailsPost(request));
		 * response.setInvRes(getInvoiceCutOff(request));
		 * response.setNotRes(getAllNotificationType(request));
		 * response.setParamRes(getAllParamDetailsPost(request));
		 * response.setResourceRes(GetResourceDetails(request));
		 * response.setRoleRes(getAllRolePermissionPost(request));
		 * response.setChannelId(request.getChannel());
		 * response.setSectionRes(getAllSectionDetailsPost(request));
		 * response.setTokenId(request.getToken()); return response;
		 * 
		 */

		return response;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/getAllSectionDetails")
	public ResponseEntity<SectionsRes> getAllSectionDetailsPost(@RequestBody Request request) {
		SectionsRes resp = new SectionsRes();
		HttpHeaders responseHeaders = null;
		ResponseEntity<SectionsRes> sectionResponseEntity;
		try {
			TransformSectionDetails transformSectionDetails = new TransformSectionDetails();
			resp = transformSectionDetails.transfromSectionDetails(request);
		} catch (Exception e) {
			constructErrorResponse(request, resp);
		}

		if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.EMPTY_RESULTSET_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.EMPTY_RESULTSET_DESC);
			sectionResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.NO_CONTENT);

		} else if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CD)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			sectionResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.OK);
		} else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			sectionResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return sectionResponseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/getAllSystemDetails")
	public ResponseEntity<SystemRes> getAllSystemDetailsPost(@RequestBody Request request) {
		SystemRes resp = new SystemRes();
		ResponseEntity<SystemRes> systemDtlResponseEntity;
		try {
			TransformSystemDetails transformSystemDetails = new TransformSystemDetails();
			resp = transformSystemDetails.transfromSystemDetails(request);
		} catch (Exception e) {
			constructErrorResponse(request, resp);
		}

		HttpHeaders responseHeaders = null;
		if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.EMPTY_RESULTSET_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.EMPTY_RESULTSET_DESC);
			systemDtlResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.NO_CONTENT);

		} else if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CD)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			systemDtlResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.OK);
		} else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			systemDtlResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return systemDtlResponseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/getAllParamDetails")
	public ResponseEntity<ParamDetailsRes> getAllParamDetailsPost(@RequestBody Request request) {
		ParamDetailsRes resp = new ParamDetailsRes();
		ResponseEntity<ParamDetailsRes> paramDetailsResponseEntity;
		try {
			TransformParamDetails transformParamDetails = new TransformParamDetails();
			resp = transformParamDetails.transfromParamDetails(request);
		} catch (Exception e) {
			constructErrorResponse(request, resp);
		}

		HttpHeaders responseHeaders = null;
		if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.EMPTY_RESULTSET_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.EMPTY_RESULTSET_DESC);
			paramDetailsResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.NO_CONTENT);

		} else if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CD)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			paramDetailsResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.OK);
		} else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			paramDetailsResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return paramDetailsResponseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/getAllRolePermission")
	public ResponseEntity<RolePermissionRes> getAllRolePermissionPost(@RequestBody Request request) {
		RolePermissionRes resp = new RolePermissionRes();
		ResponseEntity<RolePermissionRes> rolePermissionResponseEntity;
		try {
			TransformRolePermissionDetails transformRolePermissionDetails = new TransformRolePermissionDetails();
			resp = transformRolePermissionDetails.transRoleDetail(request);
		} catch (Exception e) {
			constructErrorResponse(request, resp);
		}

		HttpHeaders responseHeaders = null;
		if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.EMPTY_RESULTSET_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.EMPTY_RESULTSET_DESC);
			rolePermissionResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.NO_CONTENT);

		} else if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CD)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			rolePermissionResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.OK);
		} else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			rolePermissionResponseEntity = new ResponseEntity<>(resp, responseHeaders,
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return rolePermissionResponseEntity;

	}

	@RequestMapping(method = RequestMethod.POST, value = "/getAllNotificationType")
	public ResponseEntity<NotificationRes> getAllNotificationType(@RequestBody Request request) {
		NotificationRes resp = new NotificationRes();
		ResponseEntity<NotificationRes> notificationResponseEntity;
		try {
			TransFormNotificationData transFormNotificationData = new TransFormNotificationData();
			resp = transFormNotificationData.transNotificationData(request);
		} catch (Exception e) {
			constructErrorResponse(request, resp);
		}

		HttpHeaders responseHeaders = null;
		if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.EMPTY_RESULTSET_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.EMPTY_RESULTSET_DESC);
			notificationResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.NO_CONTENT);

		} else if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CD)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			notificationResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.OK);
		} else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			notificationResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return notificationResponseEntity;

	}

	@RequestMapping(method = RequestMethod.POST, value = "/getInvoiceCutOff")
	public ResponseEntity<InvoiceCutOffRes> getInvoiceCutOff(@RequestBody Request request) {
		InvoiceCutOffRes resp = new InvoiceCutOffRes();
		ResponseEntity<InvoiceCutOffRes> invoiceCutOffResponseEntity;

		try {
			TransFormInvoiceCutoff transFormInvoiceCutoff = new TransFormInvoiceCutoff();
			resp = transFormInvoiceCutoff.transNotificationData(request);
		} catch (Exception e) {
			constructErrorResponse(request, resp);
		}

		HttpHeaders responseHeaders = null;
		if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.EMPTY_RESULTSET_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.EMPTY_RESULTSET_DESC);
			invoiceCutOffResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.NO_CONTENT);

		} else if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CD)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			invoiceCutOffResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.OK);
		} else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			invoiceCutOffResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return invoiceCutOffResponseEntity;

	}

	@RequestMapping(method = RequestMethod.POST, value = "/getITPMDetails")
	public ResponseEntity<ResourceRes> GetPMDetails(@RequestBody Request request) {
		ResourceRes resp = new ResourceRes();
		ResponseEntity<ResourceRes> resourceResResponseEntity;
		try {
			TransformResourceData TransformResourceData = new TransformResourceData();
			resp = TransformResourceData.transResourceDetails(request, CommonConstants.ROLE_ITPM);
		} catch (Exception e) {
			constructErrorResponse(request, resp);
		}
		HttpHeaders responseHeaders = null;
		if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.EMPTY_RESULTSET_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.EMPTY_RESULTSET_DESC);
			resourceResResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.NO_CONTENT);

		} else if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CD)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			resourceResResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.OK);
		} else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			resourceResResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return resourceResResponseEntity;

	}

	@RequestMapping(method = RequestMethod.POST, value = "/getPMODetails")
	public ResponseEntity<ResourceRes> GetPMODetails(@RequestBody Request request) {
		ResourceRes resp = new ResourceRes();
		ResponseEntity<ResourceRes> resourceResResponseEntity;
		try {
			TransformResourceData TransformResourceData = new TransformResourceData();
			resp = TransformResourceData.transResourceDetails(request, CommonConstants.ROLE_PMO);
		} catch (Exception e) {
			constructErrorResponse(request, resp);
		}
		HttpHeaders responseHeaders = null;
		if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.EMPTY_RESULTSET_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.EMPTY_RESULTSET_DESC);
			resourceResResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.NO_CONTENT);

		} else if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CD)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			resourceResResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.OK);
		} else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			resourceResResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return resourceResResponseEntity;

	}

	@RequestMapping(method = RequestMethod.POST, value = "/getAllResourceDetails")
	public ResponseEntity<ResourceRes> GetResourceDetails(@RequestBody Request request) {
		ResourceRes resp = new ResourceRes();
		ResponseEntity<ResourceRes> resourceResResponseEntity;
		try {
			TransformResourceData transformResourceData = new TransformResourceData();
			resp = transformResourceData.transResourceDetails(request);
		} catch (Exception e) {
			constructErrorResponse(request, resp);
		}
		HttpHeaders responseHeaders = null;
		if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.EMPTY_RESULTSET_CODE)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.EMPTY_RESULTSET_DESC);
			resourceResResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.NO_CONTENT);

		} else if (resp.getResponseCode().equalsIgnoreCase(CommonConstants.SUCCESS_CD)) {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SUCCESS_DESC);
			resourceResResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.OK);
		} else {
			responseHeaders = new HttpHeaders();
			responseHeaders.set(CommonConstants.REASON_PHRASE, CommonConstants.SERVICE_ERR_MSG);
			resourceResResponseEntity = new ResponseEntity<>(resp, responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return resourceResResponseEntity;

	}

	public void constructErrorResponse(Request request, SectionsRes resp) {
		resp.setTokenId(request.getToken());
		resp.setResponseCode(CommonConstants.SERVICE_ERR_CD);
		resp.setResponseDescription(CommonConstants.SERVICE_ERR_MSG);
	}

	public void constructErrorResponse(Request request, SystemRes resp) {
		resp.setTokenId(request.getToken());
		resp.setResponseCode(CommonConstants.SERVICE_ERR_CD);
		resp.setResponseDescription(CommonConstants.SERVICE_ERR_MSG);
	}

	public void constructErrorResponse(Request request, ParamDetailsRes resp) {
		resp.setTokenId(request.getToken());
		resp.setResponseCode(CommonConstants.SERVICE_ERR_CD);
		resp.setResponseDescription(CommonConstants.SERVICE_ERR_MSG);
	}

	public void constructErrorResponse(Request request, RolePermissionRes resp) {
		resp.setTokenId(request.getToken());
		resp.setResponseCode(CommonConstants.SERVICE_ERR_CD);
		resp.setResponseDescription(CommonConstants.SERVICE_ERR_MSG);
	}

	public void constructErrorResponse(Request request, NotificationRes resp) {
		resp.setTokenId(request.getToken());
		resp.setResponseCode(CommonConstants.SERVICE_ERR_CD);
		resp.setResponseDescription(CommonConstants.SERVICE_ERR_MSG);
	}

	public void constructErrorResponse(Request request, InvoiceCutOffRes resp) {
		resp.setTokenId(request.getToken());
		resp.setResponseCode(CommonConstants.SERVICE_ERR_CD);
		resp.setResponseDescription(CommonConstants.SERVICE_ERR_MSG);
	}

	public void constructErrorResponse(Request request, ResourceRes resp) {
		resp.setTokenId(request.getToken());
		resp.setResponseCode(CommonConstants.SERVICE_ERR_CD);
		resp.setResponseDescription(CommonConstants.SERVICE_ERR_MSG);
	}
}
