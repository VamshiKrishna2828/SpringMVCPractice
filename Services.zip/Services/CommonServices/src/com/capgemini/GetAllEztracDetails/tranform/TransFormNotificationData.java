package com.capgemini.GetAllEztracDetails.tranform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.GetAllDetails.Request.Request;
import com.capgemini.GetAllDetails.Response.NotificationDetails;
import com.capgemini.GetAllDetails.Response.NotificationRes;

import DAO.NotificationType;

import DAO.UserDAOImpl;

public class TransFormNotificationData {
public NotificationRes transNotificationData(Request req) {
		
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		NotificationRes notiRes = new NotificationRes();
		
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
		Query  personList = session.createQuery("from NotificationType where statusCd =:statusCd and subAccount.subAccountId =:subId order by notifyTypeId");
		personList.setParameter("statusCd",CommonConstants.STATUS_ACTIVE);
		personList.setParameter("subId",req.getSubAccountId());
		@SuppressWarnings("unchecked")
		List<NotificationType> list = personList.list();
	    if (list == null || list.isEmpty()) {
	    	notiRes.setResponseCode(CommonConstants.EMPTY_RESULTSET_CODE);
	    	notiRes.setResponseDescription(CommonConstants.EMPTY_RESULTSET_DESC);
	    	notiRes.setTokenId(req.getToken());
	    	session.flush();
	    	session.close();
			context.close();
			return notiRes;
	    }
	 else
	  {
		Iterator<NotificationType> iter = list.iterator();
		NotificationDetails notification = new NotificationDetails();
		List<NotificationDetails> notificationList = new ArrayList<NotificationDetails>(list.size());
		while (iter.hasNext()) {
			NotificationType notifyDao = (NotificationType)iter.next();
			if(notifyDao.getStatusCd().equalsIgnoreCase(CommonConstants.STATUS_ACTIVE)){
			notification.setDescripton(notifyDao.getDescripton());
			notification.setNotifyTypeId(notifyDao.getNotifyTypeId());
			notification.setTemplate(notifyDao.getTemplate());
			notificationList.add(notification);
		}
		}
		notiRes.setNotificationDetails(notificationList);
		notiRes.setTokenId(req.getToken());
		notiRes.setResponseCode(CommonConstants.SUCCESS_CD);
		notiRes.setResponseDescription(CommonConstants.SUCCESS_DESC);
		session.close();
		context.close();
		return notiRes;
	    }	
	}
}
