package com.capgemini.GetAllEztracDetails.tranform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.GetAllDetails.Request.Request;
import com.capgemini.GetAllDetails.Response.SectionDetail;
import com.capgemini.GetAllDetails.Response.SectionsRes;
import com.capgemini.GetAllDetails.Response.SubSectionDetails;

import DAO.Section;
import DAO.SubSection;
import DAO.UserDAOImpl;
public class TransformSectionDetails {
	
	@SuppressWarnings("unchecked")
	public SectionsRes transfromSectionDetails(Request req) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		SectionsRes res = new SectionsRes();
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
		Query  sectionList = session.createQuery("from Section where statusCd =:statusCd and subAccount.subAccountId =:subId order by sectionId");
		sectionList.setParameter("statusCd",CommonConstants.STATUS_ACTIVE);
		sectionList.setParameter("subId",req.getSubAccountId());
		List<Section> list = sectionList.list();
	    if (list == null || list.isEmpty()) {
	    	res.setResponseCode(CommonConstants.EMPTY_RESULTSET_CODE);
	    	res.setResponseDescription(CommonConstants.EMPTY_RESULTSET_DESC);
	    	res.setTokenId(req.getToken());
	    	session.flush();
	    	session.close();
			context.close();
			return res;
	    }
	    else{
		Iterator<Section> iter = list.iterator();
		List<SectionDetail> section = new ArrayList<SectionDetail>(list.size());
		while (iter.hasNext()) {
			SectionDetail sec = new SectionDetail(); 
			Section sub = ((Section)iter.next());
			sec.setSectionID(sub.getSectionId());
			sec.setSectionName(sub.getSectionName());
			sec.setSectionType(sub.getParamValue().getValueId());
			Iterator<SubSection> iter1 = sub.getSubSections().iterator();
			List<SubSectionDetails> subsections = new ArrayList<SubSectionDetails>(sub.getSubSections().size());
			while (iter1.hasNext()) {
				SubSection subSection = ((SubSection)iter1.next());
				if(subSection.getStatusCd().equalsIgnoreCase(CommonConstants.STATUS_ACTIVE))
				{
					SubSectionDetails subsection = new SubSectionDetails();
					subsection.setSubSectionID(subSection.getSubSectionId());
					subsection.setSubSectionName(subSection.getSubSectionName());
					subsection.setSubSectionType(subSection.getParamValue().getValueId());
					subsections.add(subsection);
				}
			}
			sec.setSubSection(subsections);
			section.add(sec);
		}
		res.setSectionDetails(section);
		res.setTokenId(req.getToken());
		res.setResponseCode(CommonConstants.SUCCESS_CD);
		res.setResponseDescription(CommonConstants.SUCCESS_DESC);
		session.close();
		context.close();
		return res;
	    }
	}
/*	public static void main(String[] args) {

		Request r = new Request();
		r.setSubAccountId(1);
		SectionsRes res = transfromSectionDetails(r);
		System.out.println("Resulttttt" + res.getSectionDetails().get(0).getSectionName());
		
	}*/
}
