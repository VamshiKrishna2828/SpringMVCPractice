package com.capgemini.GetAllEztracDetails.tranform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.GetAllDetails.Request.Request;
import com.capgemini.GetAllDetails.Response.SubSystemDetails;
import com.capgemini.GetAllDetails.Response.SystemDetails;
import com.capgemini.GetAllDetails.Response.SystemRes;
import DAO.SubSystem;
import DAO.System;
import DAO.UserDAOImpl;

public class TransformSystemDetails {
	
	
	@SuppressWarnings("unchecked")
	public SystemRes transfromSystemDetails(Request req) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		SystemRes sysRes = new SystemRes();
		
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
		Query systemList = session.createQuery("from System where statusCd =:statusCd and subAccount.subAccountId =:subId order by systemId");
		systemList.setParameter("statusCd", CommonConstants.STATUS_ACTIVE);
		systemList.setParameter("subId", req.getSubAccountId());
		List<System> list = systemList.list();
	    if (list == null || list.isEmpty()) {
	    	sysRes.setResponseCode(CommonConstants.EMPTY_RESULTSET_CODE);
	    	sysRes.setResponseDescription(CommonConstants.EMPTY_RESULTSET_DESC);
	    	sysRes.setTokenId(req.getToken());
	    	session.flush();
	    	session.close();
			context.close();
			return sysRes;
	    }
	    else{
		Iterator<System> iter = list.iterator();
		List<SystemDetails> system = new ArrayList<SystemDetails>(list.size());
		while (iter.hasNext()) {
			SystemDetails sys = new SystemDetails(); 
			System sub = ((System)iter.next());
			sys.setSystemID(sub.getSystemId());
			sys.setSystemName(sub.getSystemName());
			Iterator<SubSystem> iter1 = sub.getSubSystems().iterator();
			List<SubSystemDetails> subsyslist = new ArrayList<SubSystemDetails>(sub.getSubSystems().size());
			while (iter1.hasNext()) {
				SubSystem subSys = ((SubSystem)iter1.next());
				if(subSys.getStatusCd().equalsIgnoreCase(CommonConstants.STATUS_ACTIVE)) {
					SubSystemDetails subsection = new SubSystemDetails();
					subsection.setSubSystemEmail(subSys.getSysEmail());
					subsection.setSubSystemID(subSys.getSubSystemId());
					subsection.setSubSystemName(subSys.getSubSystemName());
					subsyslist.add(subsection);
				}
			}
			sys.setSubsystemDetails(subsyslist);
			system.add(sys);
		}
		session.flush();
		session.close();
		context.close();
		sysRes.setSystemDetails(system);
		sysRes.setResponseCode(CommonConstants.SUCCESS_CD);
		sysRes.setResponseDescription(CommonConstants.SUCCESS_DESC);
		sysRes.setTokenId(req.getToken());
		return sysRes;
	}
	}
}
