package com.capgemini.GetAllEztracDetails.tranform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.GetAllDetails.Request.Request;
import com.capgemini.GetAllDetails.Response.RolePermissionDetails;
import com.capgemini.GetAllDetails.Response.SectionDetail;
import com.capgemini.GetAllDetails.Response.StakeHolder;
import com.capgemini.GetAllDetails.Response.StakeHolderRes;
import com.capgemini.GetAllDetails.Response.SubSectionDetails;

import DAO.Role;
import DAO.Section;
import DAO.SubSection;
import DAO.UserDAOImpl;

public class TransformStakeHolderDetails {
	public StakeHolderRes transStakeHolderData(Request req) {
		
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
		Query  personList = session.createQuery("from Stakeholder where subAccount.subAccountId =:subId ");
		personList.setParameter("subId",req.getSubAccountId());
		@SuppressWarnings("unchecked")
		List<Role> list = personList.list();
		Iterator iter = list.iterator();
		StakeHolderRes stakeHolder = new StakeHolderRes();
		List<StakeHolder> listStake = new ArrayList<StakeHolder>(list.size());
		while (iter.hasNext()) {
			StakeHolder stake = new StakeHolder(); 
/*			Stakeholder stakeDao = ((Stakeholder)iter.next());
			stake.setStakeHolderId(stakeDao.getStakeholderId());
			stake.setStakeHolderType(stakeDao.getParamValue().getValueId());
*/			listStake.add(stake);
		}
		stakeHolder.setStakeHolderDetail(listStake);
		return stakeHolder;	
			
	}

}
