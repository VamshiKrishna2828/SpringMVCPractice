package com.capgemini.GetAllEztracDetails.tranform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.GetAllDetails.Request.Request;
import com.capgemini.GetAllDetails.Response.InvoiceCutOffDetail;
import com.capgemini.GetAllDetails.Response.InvoiceCutOffRes;
import com.capgemini.GetAllDetails.Response.NotificationDetails;

import DAO.InvoiceCutoff;
import DAO.NotificationType;
import DAO.UserDAOImpl;


public class TransFormInvoiceCutoff {
public InvoiceCutOffRes transNotificationData(Request req) {
		
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		InvoiceCutOffRes invres = new InvoiceCutOffRes();
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
		Query  personList = session.createQuery("from InvoiceCutoff where statusCd =:statusCd and subAccount.subAccountId=:subAccountId order by createdOn");
		personList.setParameter("statusCd",CommonConstants.STATUS_ACTIVE);
		personList.setParameter("subAccountId",req.getSubAccountId());
		@SuppressWarnings("unchecked")
		List<InvoiceCutoff> list = personList.list();
	    if (list == null || list.isEmpty()) {
	    	invres.setResponseCode(CommonConstants.EMPTY_RESULTSET_CODE);
	    	invres.setResponseDescription(CommonConstants.EMPTY_RESULTSET_DESC);
	    	session.flush();
	    	session.close();
			context.close();
			return invres;
	    }
	    else{
		Iterator<InvoiceCutoff> iter = list.iterator();
		List<InvoiceCutOffDetail> invoiceCutOffList = new ArrayList<InvoiceCutOffDetail>(list.size());
		while (iter.hasNext()) {
			InvoiceCutoff invoiceDao = (InvoiceCutoff)iter.next();
			InvoiceCutOffDetail invoiceCutOff = new InvoiceCutOffDetail();
			if(invoiceDao.getStatusCd().equalsIgnoreCase(CommonConstants.STATUS_ACTIVE)){
			invoiceCutOff.setInvoiceDt(invoiceDao.getId().getInvoiceDay());
			invoiceCutOff.setInvoiceMonth(invoiceDao.getId().getInvoiceMonth());
			invoiceCutOff.setInvoiceYear((invoiceDao.getId().getInvoiceYear()));
			invoiceCutOffList.add(invoiceCutOff);
			}
		}
		invres.setInvoiceCutOffDetail(invoiceCutOffList);
		invres.setTokenId(req.getToken());
		invres.setResponseCode(CommonConstants.SUCCESS_CD);
		invres.setResponseDescription(CommonConstants.SUCCESS_DESC);
		session.close();
		context.close();
		return invres;
	    }
	}

}
