package com.capgemini.GetAllEztracDetails.tranform;
public class CommonConstants {

	
	public static final String STATUS_ACTIVE = "A";
	public static final String SUCCESS_CD = "SP1000";
	public static final String SUCCESS_DESC = "The request was processed successfully.";
	public static final String EMPTY_RESULTSET_CODE = "SP1001";
	public static final String EMPTY_RESULTSET_DESC="No matching records found for the given criteria!";
	public static final Integer ROLE_ITPM = 6;
	public static final Integer ROLE_PMO = 2;
	public static final String SERVICE_ERR_CD = "FC1001";
	public static final String SERVICE_ERR_MSG = "Error occurred in webservice";
	public static final String REASON_PHRASE = "Reason-Phrase";
	
	private CommonConstants() {}
}
