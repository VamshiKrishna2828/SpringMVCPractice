package com.capgemini.GetAllEztracDetails.tranform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.GetAllDetails.Request.Request;
import com.capgemini.GetAllDetails.Response.ParamDetail;
import com.capgemini.GetAllDetails.Response.ParamDetailsRes;
import com.capgemini.GetAllDetails.Response.ParamValueDetails;


import DAO.ParamType;
import DAO.ParamValue;
import DAO.Section;

import DAO.UserDAOImpl;

public class TransformParamDetails {
	public ParamDetailsRes transfromParamDetails(Request req) {
		DAO.User data = null;
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		ParamDetailsRes paraDetailRes = new ParamDetailsRes();
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
		Query  personList = session.createQuery("from ParamType where statusCd =:statusCd and subAccount.subAccountId =:subId order by typeId");
		personList.setParameter("statusCd",CommonConstants.STATUS_ACTIVE);
		personList.setParameter("subId",req.getSubAccountId());
		@SuppressWarnings("unchecked")
		List<ParamType> list = personList.list();
	    if (list == null || list.isEmpty()) {
	    	paraDetailRes.setResponseCode(CommonConstants.EMPTY_RESULTSET_CODE);
	    	paraDetailRes.setResponseDescription(CommonConstants.EMPTY_RESULTSET_DESC);
	    	paraDetailRes.setTokenId(req.getToken());
	    	session.flush();
	    	session.close();
			context.close();
			return paraDetailRes;
	    }
	    else{
		Iterator<ParamType> iter = list.iterator();
		List<ParamDetail> paramDetailList = new ArrayList<ParamDetail>(list.size());
		while (iter.hasNext()) {
			ParamDetail paramDetails = new ParamDetail(); 
			ParamType paramTypeitr = ((ParamType)iter.next());
			paramDetails.setParamTypeID(paramTypeitr.getTypeId());
			paramDetails.setParamTypeName(paramTypeitr.getTypeName());
			Iterator<ParamValue> iter1 = paramTypeitr.getParamValues().iterator();
			List<ParamValueDetails> paramValueList = new ArrayList<ParamValueDetails>(paramTypeitr.getParamValues().size());
			while (iter1.hasNext()) {
				ParamValue paramValue = ((ParamValue)iter1.next());
				if(paramValue.getStatusCd().equalsIgnoreCase(CommonConstants.STATUS_ACTIVE)) {
					ParamValueDetails paramValueDetails = new ParamValueDetails();
					paramValueDetails.setParamValue(paramValue.getValue());
					paramValueDetails.setParamvalueID(paramValue.getValueId());
					paramValueDetails.setParamName(paramValue.getName());
					paramValueList.add(paramValueDetails);
				}	
			}
			paramDetails.setParamValue(paramValueList);	
			paramDetailList.add(paramDetails);
		}
		session.flush();
		session.close();
		context.close();
		paraDetailRes.setParamDetail(paramDetailList);
		paraDetailRes.setResponseCode(CommonConstants.SUCCESS_CD);
		paraDetailRes.setResponseDescription(CommonConstants.SUCCESS_DESC);
		paraDetailRes.setTokenId(req.getToken());
		return paraDetailRes;
	}
	}
	

}
