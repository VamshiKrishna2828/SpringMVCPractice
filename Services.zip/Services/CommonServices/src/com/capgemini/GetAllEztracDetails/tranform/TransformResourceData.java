package com.capgemini.GetAllEztracDetails.tranform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.GetAllDetails.Request.Request;
import com.capgemini.GetAllDetails.Response.ResourceDetails;
import com.capgemini.GetAllDetails.Response.ResourceRes;

import DAO.Role;
import DAO.User;
import DAO.UserDAOImpl;
import DAO.UserRole;

public class TransformResourceData {
public ResourceRes transResourceDetails(Request req,Integer roleID) {
		
		
	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		ResourceRes pmRes = new ResourceRes();
		
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
	    String query = "from Role where statusCd =:statusCd and subAccount.subAccountId =:subId and roleId =:roleId "; 
		Query  personList = session.createQuery(query);
		personList.setParameter("statusCd",CommonConstants.STATUS_ACTIVE);
		personList.setParameter("subId",req.getSubAccountId());
		personList.setParameter("roleId",roleID);
		@SuppressWarnings("unchecked")
		List<Role> list = personList.list();
	    if (list == null || list.isEmpty()) {
	    	pmRes.setResponseCode(CommonConstants.EMPTY_RESULTSET_CODE);
	    	pmRes.setResponseDescription(CommonConstants.EMPTY_RESULTSET_DESC);
	    	pmRes.setTokenId(req.getToken());
	    	session.flush();
	    	session.close();
			context.close();
			return pmRes;
	    }
	 else
	  {
			Iterator<Role> iter = list.iterator();
			List<ResourceDetails> resourceDetList = null;
			while (iter.hasNext()) {
				Role role = ((Role)iter.next());
				resourceDetList = new ArrayList<ResourceDetails>(role.getUserRoles().size());
				Iterator<UserRole> iter2 = role.getUserRoles().iterator();
				while (iter2.hasNext()) {
					ResourceDetails resDetails = new ResourceDetails();
					UserRole userRoleDao = ((UserRole)iter2.next());
					if(userRoleDao.getStatusCd().equalsIgnoreCase(CommonConstants.STATUS_ACTIVE)) 
					{
						resDetails.setName(userRoleDao.getUserByUserId().getName());
						resDetails.setUserId(userRoleDao.getId().getUserId());
						resourceDetList.add(resDetails);
				     }
					}
				}
			pmRes.setPm(resourceDetList);
			pmRes.setTokenId(req.getToken());
			pmRes.setResponseCode(CommonConstants.SUCCESS_CD);
			pmRes.setResponseDescription(CommonConstants.SUCCESS_DESC);
			session.close();
			context.close();
			return pmRes;
			}
	}
public ResourceRes transResourceDetails(Request req) {
	
	
	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
	UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
	ResourceRes pmRes = new ResourceRes();
	
	Session session = userdao.getSessionFactory().openSession();
    session.beginTransaction();
    String query = "from User where statusCd =:statusCd and subAccount.subAccountId =:subId order by name"; 
	Query  personList = session.createQuery(query);
	personList.setParameter("statusCd",CommonConstants.STATUS_ACTIVE);
	personList.setParameter("subId",req.getSubAccountId());
	@SuppressWarnings("unchecked")
	List<User> list = personList.list();
    if (list == null || list.isEmpty()) {
    	pmRes.setResponseCode(CommonConstants.EMPTY_RESULTSET_CODE);
    	pmRes.setResponseDescription(CommonConstants.EMPTY_RESULTSET_DESC);
    	pmRes.setTokenId(req.getToken());
    	session.flush();
    	session.close();
		context.close();
		return pmRes;
    }
 else
  {
		Iterator<User> iter = list.iterator();
		List<ResourceDetails> resourceDetList = new ArrayList<ResourceDetails>();
		while (iter.hasNext()) {
			User user = ((User)iter.next());	
			Iterator<UserRole> iter2 = user.getUserRolesForUserId().iterator();
			ResourceDetails resDetails = null;
			UserRole userRoleDao = null;
			while (iter2.hasNext()) {
				userRoleDao = ((UserRole)iter2.next());
				if((userRoleDao.getStatusCd().equalsIgnoreCase(CommonConstants.STATUS_ACTIVE)) && ((userRoleDao.getRole().getRoleId().intValue()==3)||(userRoleDao.getRole().getRoleId().intValue()==4)||(userRoleDao.getRole().getRoleId().intValue()==5))) 
				{
					resDetails = new ResourceDetails();
					resDetails.setName(userRoleDao.getUserByUserId().getName());
					resDetails.setUserId(userRoleDao.getId().getUserId());
					resourceDetList.add(resDetails);
					break;
			     }
				}
			}
		pmRes.setPm(resourceDetList);
		pmRes.setTokenId(req.getToken());
		pmRes.setResponseCode(CommonConstants.SUCCESS_CD);
		pmRes.setResponseDescription(CommonConstants.SUCCESS_DESC);
		session.close();
		context.close();
		return pmRes;
		}
}

}
