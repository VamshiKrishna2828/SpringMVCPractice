package com.capgemini.GetAllEztracDetails.tranform;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.GetAllDetails.Response.GetEztracDetails;

import DAO.User;
import DAO.UserDAOImpl;

public class TransformEztracDetail {
	
	public GetEztracDetails getAlldetails() {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
		Query  personList = session.createQuery("from User where login_id=:loginId");
		personList.setParameter("loginId","");
		@SuppressWarnings("unchecked")
		List<User> list = personList.list();
			    
		return null;
		
	}

}
