package com.capgemini.GetAllEztracDetails.tranform;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.GetAllDetails.Request.Request;
import com.capgemini.GetAllDetails.Response.ParamDetail;
import com.capgemini.GetAllDetails.Response.ParamValueDetails;
import com.capgemini.GetAllDetails.Response.RolePermissionDetails;
import com.capgemini.GetAllDetails.Response.RolePermissionRes;
import com.capgemini.GetAllDetails.Response.SectionDetail;
import com.capgemini.GetAllDetails.Response.SubSectionDetails;

import DAO.ParamType;
import DAO.ParamValue;
import DAO.Role;
import DAO.Section;
import DAO.SubSection;
import DAO.UserDAOImpl;

public class TransformRolePermissionDetails {
	@SuppressWarnings("null")
	public RolePermissionRes transRoleDetail(Request req) {
		DAO.User data = null;
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		UserDAOImpl userdao = context.getBean(UserDAOImpl.class);
		RolePermissionRes rolePerRes = new RolePermissionRes();
		
		Session session = userdao.getSessionFactory().openSession();
	    session.beginTransaction();
		Query  personList = session.createQuery("from Role where statusCd =:statusCd and subAccount.subAccountId =:subId order by roleId");
		personList.setParameter("statusCd",CommonConstants.STATUS_ACTIVE);
		personList.setParameter("subId",req.getSubAccountId());
		@SuppressWarnings("unchecked")
		List<Role> list = personList.list();
	    if (list == null || list.isEmpty()) {
	    	rolePerRes.setResponseCode(CommonConstants.EMPTY_RESULTSET_CODE);
	    	rolePerRes.setResponseDescription(CommonConstants.EMPTY_RESULTSET_DESC);
	    	rolePerRes.setTokenId(req.getToken());
	    	session.flush();
	    	session.close();
			context.close();
			return rolePerRes;
	    }
	    else
	    {
		Iterator<Role> iter = list.iterator();
		List<RolePermissionDetails> roleDetails = new ArrayList<RolePermissionDetails>(list.size());
		RolePermissionDetails roleDetail =null;
		while (iter.hasNext()) {
			roleDetail= new RolePermissionDetails(); 
			Role role = ((Role)iter.next());
			roleDetail.setRoleId(role.getRoleId());
			roleDetail.setRoleName(role.getRoleDesc());
			List<SubSectionDetails> subSectionDetails = new ArrayList<SubSectionDetails>(role.getSubSections().size());
			Iterator<SubSection> iter2 = role.getSubSections().iterator();
			SubSectionDetails subSectionDetail = null;
			SubSection subSectionDao = null;
			while (iter2.hasNext()) {
				subSectionDetail = new SubSectionDetails();
				subSectionDao = ((SubSection)iter2.next());
				if(subSectionDao.getStatusCd().equalsIgnoreCase(CommonConstants.STATUS_ACTIVE)) {
				subSectionDetail.setSubSectionID(subSectionDao.getSubSectionId());
				subSectionDetail.setSubSectionName(subSectionDao.getSubSectionName());
				subSectionDetail.setSubSectionType(subSectionDao.getParamValue().getValueId());
				subSectionDetail.setSectionName(subSectionDao.getSection().getSectionName());
				subSectionDetail.setSectionType(subSectionDao.getSection().getParamValue().getValueId());
				subSectionDetail.setSectionID(subSectionDao.getSection().getSectionId());
				subSectionDetails.add(subSectionDetail);
				}
			}
			roleDetail.setSubSections(subSectionDetails);
			roleDetails.add(roleDetail);
		}
		session.flush();
		session.close();
		context.close();
		rolePerRes.setRolePerm(roleDetails);
		rolePerRes.setResponseCode(CommonConstants.SUCCESS_CD);
		rolePerRes.setResponseDescription(CommonConstants.SUCCESS_DESC); 
		rolePerRes.setTokenId(req.getToken());
		return rolePerRes;
	       }
		}

}
