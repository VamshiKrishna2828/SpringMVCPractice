package com.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.util.StringUtils;

public class Testme {

	public static void main(String[] args) {
		String s = concatenateDigits(2018,11,10);
		System.out.println(s);
		try {
			String s1 = changeFormat(s);
			System.out.println(s1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static String concatenateDigits(int... digits) {
		   StringBuilder sb = new StringBuilder(digits.length);
		   for (int digit : digits) {
		     sb.append(digit);
		   }
		   return sb.toString();
		}


public static String convertDateToString(Date date, String toFormat) {
	if (date == null || StringUtils.isEmpty(toFormat)) { return null; }
	String returnVal = null;
	SimpleDateFormat sdf = new SimpleDateFormat(toFormat);
	returnVal = sdf.format(date);
	return returnVal;
}

public static Date convertStringToDate(String dateString, String toFormat) throws ParseException {
	if (StringUtils.isEmpty(dateString) || StringUtils.isEmpty(toFormat)) { return null; }
	SimpleDateFormat sdf = new SimpleDateFormat(toFormat);
	Date returnVal = sdf.parse(dateString);
	return returnVal;
}
public static String changeFormat(String dateString) throws ParseException
{
	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	Date d1 = sdf.parse(dateString);
	sdf.applyPattern("yyyy-MM-dd");
	System.out.println(sdf.format(d1));
	String hello = sdf.format(d1);
	return hello;
}

}
