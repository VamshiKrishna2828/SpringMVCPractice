package DAO;
// Generated Feb 14, 2018 7:29:40 AM by Hibernate Tools 5.2.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class UserLocation.
 * @see DAO.UserLocation
 * @author Hibernate Tools
 */
@Stateless
public class UserLocationHome {

	private static final Log log = LogFactory.getLog(UserLocationHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(UserLocation transientInstance) {
		log.debug("persisting UserLocation instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(UserLocation persistentInstance) {
		log.debug("removing UserLocation instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public UserLocation merge(UserLocation detachedInstance) {
		log.debug("merging UserLocation instance");
		try {
			UserLocation result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public UserLocation findById(UserLocationId id) {
		log.debug("getting UserLocation instance with id: " + id);
		try {
			UserLocation instance = entityManager.find(UserLocation.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
