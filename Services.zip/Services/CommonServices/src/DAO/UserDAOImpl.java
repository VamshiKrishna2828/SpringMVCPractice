package DAO;

import java.util.List;
import java.lang.System;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class UserDAOImpl {
	
	private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
        
    }
    public SessionFactory getSessionFactory() {
        return this.sessionFactory;
        
    }
	

}
