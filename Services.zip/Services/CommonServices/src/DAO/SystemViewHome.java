package DAO;
// Generated Feb 14, 2018 7:29:40 AM by Hibernate Tools 5.2.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class SystemView.
 * @see DAO.SystemView
 * @author Hibernate Tools
 */
@Stateless
public class SystemViewHome {

	private static final Log log = LogFactory.getLog(SystemViewHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(SystemView transientInstance) {
		log.debug("persisting SystemView instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(SystemView persistentInstance) {
		log.debug("removing SystemView instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public SystemView merge(SystemView detachedInstance) {
		log.debug("merging SystemView instance");
		try {
			SystemView result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public SystemView findById(SystemViewId id) {
		log.debug("getting SystemView instance with id: " + id);
		try {
			SystemView instance = entityManager.find(SystemView.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
