package DAO;
// Generated Feb 14, 2018 7:29:40 AM by Hibernate Tools 5.2.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class AuditReport.
 * @see DAO.AuditReport
 * @author Hibernate Tools
 */
@Stateless
public class AuditReportHome {

	private static final Log log = LogFactory.getLog(AuditReportHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(AuditReport transientInstance) {
		log.debug("persisting AuditReport instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(AuditReport persistentInstance) {
		log.debug("removing AuditReport instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public AuditReport merge(AuditReport detachedInstance) {
		log.debug("merging AuditReport instance");
		try {
			AuditReport result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public AuditReport findById(AuditReportId id) {
		log.debug("getting AuditReport instance with id: " + id);
		try {
			AuditReport instance = entityManager.find(AuditReport.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
