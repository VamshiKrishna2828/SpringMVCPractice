package DAO;
// Generated Feb 14, 2018 7:29:40 AM by Hibernate Tools 5.2.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class InvoiceCutoff.
 * @see DAO.InvoiceCutoff
 * @author Hibernate Tools
 */
@Stateless
public class InvoiceCutoffHome {

	private static final Log log = LogFactory.getLog(InvoiceCutoffHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(InvoiceCutoff transientInstance) {
		log.debug("persisting InvoiceCutoff instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(InvoiceCutoff persistentInstance) {
		log.debug("removing InvoiceCutoff instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public InvoiceCutoff merge(InvoiceCutoff detachedInstance) {
		log.debug("merging InvoiceCutoff instance");
		try {
			InvoiceCutoff result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public InvoiceCutoff findById(InvoiceCutoffId id) {
		log.debug("getting InvoiceCutoff instance with id: " + id);
		try {
			InvoiceCutoff instance = entityManager.find(InvoiceCutoff.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
