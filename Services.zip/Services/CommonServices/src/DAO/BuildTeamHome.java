package DAO;
// Generated Feb 14, 2018 7:29:40 AM by Hibernate Tools 5.2.6.Final

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Home object for domain model class BuildTeam.
 * @see DAO.BuildTeam
 * @author Hibernate Tools
 */
@Stateless
public class BuildTeamHome {

	private static final Log log = LogFactory.getLog(BuildTeamHome.class);

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(BuildTeam transientInstance) {
		log.debug("persisting BuildTeam instance");
		try {
			entityManager.persist(transientInstance);
			log.debug("persist successful");
		} catch (RuntimeException re) {
			log.error("persist failed", re);
			throw re;
		}
	}

	public void remove(BuildTeam persistentInstance) {
		log.debug("removing BuildTeam instance");
		try {
			entityManager.remove(persistentInstance);
			log.debug("remove successful");
		} catch (RuntimeException re) {
			log.error("remove failed", re);
			throw re;
		}
	}

	public BuildTeam merge(BuildTeam detachedInstance) {
		log.debug("merging BuildTeam instance");
		try {
			BuildTeam result = entityManager.merge(detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public BuildTeam findById(BuildTeamId id) {
		log.debug("getting BuildTeam instance with id: " + id);
		try {
			BuildTeam instance = entityManager.find(BuildTeam.class, id);
			log.debug("get successful");
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}
}
