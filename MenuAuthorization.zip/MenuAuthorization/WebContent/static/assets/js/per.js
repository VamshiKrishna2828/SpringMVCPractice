 



$(document).ready(function() {
	/* START : To open and close the accordians */
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].onclick = function(){
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.display === "block") {
				panel.style.display = "none";
			} else {
				panel.style.display = "block";
			}
		}
	}
	var acc = document.getElementsByClassName("perccaccordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].onclick = function(){
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.display === "block") {
				panel.style.display = "none";
			} else {
				panel.style.display = "block";
			}
		}
	}
	
	
	 $("#newPerLink").click(function(){
		$('.perccaccordion').hide();
	});
	
	/* END : To open and close the accordians */
	
	/*START : Related to Modals*/
	// Get the modal
	var modal = document.getElementById('myModal');
	var modal1 = document.getElementById('myModal1');
	var modal2 = document.getElementById('myModal2');
	var modal3 = document.getElementById('myModal3');
	var modal4 = document.getElementById('myModal4');
	// Get the button that opens the modal
	var btn = document.getElementById("myBtn");
	var btn1 = document.getElementById("myBtn1");
	var btn2 = document.getElementById("myBtn2");
	var btn3 = document.getElementById("myBtn3");
	var btn4 = document.getElementById("myBtn4");
	// Get the <span> element that closes the modal
	var span = document.getElementsByClassName("close")[0];

	// When the user clicks the button, open the modal 
	btn.onclick = function() {
		modal.style.display = "block";
	}
	btn1.onclick = function() {
		modal1.style.display = "block";
	}
	btn2.onclick = function() {
		modal2.style.display = "block";
	}
	btn3.onclick = function() {
		modal3.style.display = "block";
	}
	btn4.onclick = function() {
		modal4.style.display = "block";
	}

	// When the user clicks on <span> (x), close the modal
	$("#modal2close").click(function(){
		$('#myModal2').hide();
	});
	$("#modal3close").click(function(){
		$('#myModal3').hide();
	});
	
	$("#modalclose").click(function(){
		$('#myModal').hide();
	});
	
	$("#modal1close").click(function(){
		$('#myModal1').hide();
	});
	$("#modal4close").click(function(){
		
		$('#myModal4').hide();
	});


	// When the user clicks anywhere outside of the modal, close it
	window.onclick = function(event) {
	  if (event.target == modal) {
			modal.style.display = "none";
		}
		if (event.target == modal1) {
			modal1.style.display = "none";
		}
		if (event.target == modal2) {
			modal2.style.display = "none";
		} 
	if (event.target == modal3) {
			modal3.style.display = "none";
		}  
	if (event.target == modal4) {
			modal4.style.display = "none";
		} 	
	}
	/*END : Related to Modals*/
	
	/* START : Picklist code for 'Managers to notify' */
	$.fn.pickList = function(options) {

		var opts = $.extend({}, $.fn.pickList.defaults, options);

		this.fill = function() {
			var option = '';
			$.each(opts.data, function(key, val) {
				option += '<option data-id=' + val.id + '>' + val.text + '</option>';
			});
			this.find('.pickData').append(option);
		};
		this.controll = function() {
			var pickThis = this;

		  pickThis.find(".pAdd").on('click', function() {
			var p = pickThis.find(".pickData option:selected");
			p.clone().appendTo(pickThis.find(".pickListResult"));
			p.remove();
		  });

		  pickThis.find(".pAddAll").on('click', function() {
			var p = pickThis.find(".pickData option");
			p.clone().appendTo(pickThis.find(".pickListResult"));
			p.remove();
		  });

		  pickThis.find(".pRemove").on('click', function() {
			var p = pickThis.find(".pickListResult option:selected");
			p.clone().appendTo(pickThis.find(".pickData"));
			p.remove();
		  });

		  pickThis.find(".pRemoveAll").on('click', function() {
			var p = pickThis.find(".pickListResult option");
			p.clone().appendTo(pickThis.find(".pickData"));
			p.remove();
		  });
		};
 
		this.getValues = function() {
		  var objResult = [];
		  this.find(".pickListResult option").each(function() {
			objResult.push({
			  id: $(this).data('id'),
			  text: this.text
			});
		  });
		 
		  return objResult;
		};
	

		this.init = function() {
		  var pickListHtml =
			"<div class='col-lg-12'>&nbsp;</div><div class='row'>" +
			"  <div class='col-sm-5 col-lg-offset-1 col-lg-3'>" +
			"	 <select class='form-control pickListSelect pickData' style='max-width:175%' multiple></select>" +
			" </div>" +
			" <div class='col-sm-2 col-lg-2 pickListButtons '>" +
			"	<button  type='button' class='pAdd btn btn-primary btn-sm col-lg-11'  style='height:22px;'>" + opts.add + "</button>" +
			"   <button  type='button' class='pAddAll btn btn-primary btn-sm col-lg-11'  style='height:22px;'>" + opts.addAll + "</button>" +
			"	<button  type='button' class='pRemove btn btn-primary btn-sm col-lg-11'  style='height:22px;'>" + opts.remove + "</button>" +
			"	<button  type='button' class='pRemoveAll btn btn-primary btn-sm col-lg-11'  style='height:22px; '>" + opts.removeAll + "</button>" +
			" </div>" +
			" <div class='col-sm-5 col-lg-5'>" +
			"    <select class='form-control pickListSelect pickListResult' style='max-width:55%' multiple></select>" +
			" </div>" +
			"</div>";

		  this.append(pickListHtml);

		  this.fill();
		  this.controll();
		};

		this.init();
		return this;
	};
	
	$.fn.pickList.defaults = {
		add: 'Add',
		addAll: 'Add All',
		remove: 'Remove',
		removeAll: 'Remove All'
	};
	
	var val = {
	  01: {
		id: 01,
		text: 'Employee1'
	  },
	  02: {
		id: 02,
		text: 'Employee2'
	  },
	  03: {
		id: 03,
		text: 'Employee3'
	  },
	  04: {
		id: 04,
		text: 'Employee4'
	  },
	  05: {
		id: 05,
		text: 'Employee5'
	  },
	  06: {
		id: 06,
		text: 'Employee6'
	  }
	};
	
	var pick = $("#pickList").pickList({
	  data: val
	});
	
	$("#getSelected").click(function() {
	  console.log(pick.getValues());
	});
	/* END : Picklist code for 'Managers to notify' */
	
	
	/* START : To show and hide the picklist for 'Managers to notify' */
	$("#addManagers").click(function(){
		
	$('#pickList').show();
	});
	
	$("#hideManagers").click(function(){
	
	$('#pickList').hide();
	});
	/* END : To show and hide the picklist for 'Managers to notify' */
	
	/* START : To show and hide the PER CC table in PER CC */
	$("#PerCCshowtablebutton").click(function(){
		
	$('#perCCtableshown').show();
	});
	
	$("#PerCChidetablebutton").click(function(){
	
	$('#perCCtableshown').hide();
	});
	/* END : To show and hide the PER CC table in PER CC */

 });