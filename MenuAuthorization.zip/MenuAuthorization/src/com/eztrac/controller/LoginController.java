package com.eztrac.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	
	@RequestMapping("/")
	public ModelAndView launchLogin(){
		ModelAndView mav = new ModelAndView("login","message","Hi");
		return mav;
	}
}
