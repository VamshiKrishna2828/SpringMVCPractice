package com.eztrac.DTOInitialization;

import java.util.ArrayList;
import java.util.List;

import com.eztrac.DTO.RoleDTO;
import com.eztrac.DTO.SectionDTO;
import com.eztrac.DTO.SubSectionDTO;

public class DTOInitialization {
	
	public void initializeDTO(){
		/*Section Objects*/
		SectionDTO  sectionDTO1 = new SectionDTO();
		sectionDTO1.setSectionId(1);
		sectionDTO1.setSectionName("Projects");
		SectionDTO  sectionDTO2 = new SectionDTO();
		sectionDTO2.setSectionId(2);
		sectionDTO2.setSectionName("Reports");
		SectionDTO  sectionDTO3 = new SectionDTO();
		sectionDTO3.setSectionId(3);
		sectionDTO3.setSectionName("HelpDesk");
		/*Section Objects*/
		
		/*SubSection Objects*/
		SubSectionDTO subSectionDTO1 = new SubSectionDTO();
		subSectionDTO1.setSubSectionId(1);
		subSectionDTO1.setSubSectionName("PerNew");
		
		SubSectionDTO subSectionDTO2 = new SubSectionDTO();
		subSectionDTO2.setSubSectionId(2);
		subSectionDTO2.setSubSectionName("PerEdit");
		
		SubSectionDTO subSectionDTO3 = new SubSectionDTO();
		subSectionDTO3.setSubSectionId(3);
		subSectionDTO3.setSubSectionName("BuildNew");
		
		SubSectionDTO subSectionDTO4 = new SubSectionDTO();
		subSectionDTO4.setSubSectionId(4);
		subSectionDTO4.setSubSectionName("BuildEdit");
		/*SubSection Objects*/
		
		/*RoleDTO Objects*/
		RoleDTO roleDto1 = new RoleDTO();
		roleDto1.setRoleId(1);
		roleDto1.setRoleDesc("PMO");
		List<SubSectionDTO> subSections1 = new ArrayList<SubSectionDTO>();
		subSections1.add(subSectionDTO1);
		subSections1.add(subSectionDTO2);
		subSections1.add(subSectionDTO3);
		subSections1.add(subSectionDTO4);
		roleDto1.setSubSections(subSections1);
		
		
		RoleDTO roleDto2 = new RoleDTO();
		roleDto2.setRoleId(2);
		roleDto2.setRoleDesc("User");
		List<SubSectionDTO> subSections2 = new ArrayList<SubSectionDTO>();
		subSections2.add(subSectionDTO2);
		subSections2.add(subSectionDTO4);
		roleDto1.setSubSections(subSections2);
		
		RoleDTO roleDto3 = new RoleDTO();
		roleDto3.setRoleId(3);
		roleDto3.setRoleDesc("PL");
		List<SubSectionDTO> subSections3 = new ArrayList<SubSectionDTO>();
		subSections3.add(subSectionDTO2);
		subSections3.add(subSectionDTO3);
		subSections3.add(subSectionDTO4);
		/*RoleDTO Objects*/
		
		
	}
	

}
