package com.eztrac.DTO;

import java.util.List;

public class UserRoleDTO {

	private Integer userId;// for roleId purpose
	private List<Integer> roleId;// for userID purpose

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public List<Integer> getRoleId() {
		return roleId;
	}

	public void setRoleId(List<Integer> roleId) {
		this.roleId = roleId;
	}

	public UserRoleDTO() {
		System.out.println("UserRoleDTOCreated");
	}

}
