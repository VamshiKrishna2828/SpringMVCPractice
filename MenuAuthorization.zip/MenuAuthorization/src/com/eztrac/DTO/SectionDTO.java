package com.eztrac.DTO;

import java.util.List;

public class SectionDTO {

	private Integer sectionId;
	private String sectionName;
	private List<SubSectionDTO> subSections;

	public Integer getSectionId() {
		return sectionId;
	}

	public void setSectionId(Integer sectionId) {
		this.sectionId = sectionId;
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public List<SubSectionDTO> getSubSections() {
		return subSections;
	}

	public void setSubSections(List<SubSectionDTO> subSections) {
		this.subSections = subSections;
	}

	@Override
	public String toString() {
		return "SectionDTO [sectionId=" + sectionId + ", sectionName=" + sectionName + ", subSections=" + subSections
				+ "]";
	}

	public SectionDTO() {
		System.out.println("SectionDTO created");
	}

}
