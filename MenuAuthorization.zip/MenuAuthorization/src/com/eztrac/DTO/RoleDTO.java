package com.eztrac.DTO;

import java.util.List;

public class RoleDTO {
	private Integer roleId;
	private String roleDesc;
	private List<SubSectionDTO> subSections;

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public List<SubSectionDTO> getSubSections() {
		return subSections;
	}

	public void setSubSections(List<SubSectionDTO> subSections) {
		this.subSections = subSections;
	}

	public RoleDTO() {
		System.out.println("RoleDTO created");
	}

}
