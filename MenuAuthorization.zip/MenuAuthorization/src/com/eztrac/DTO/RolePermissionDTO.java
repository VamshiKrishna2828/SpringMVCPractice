package com.eztrac.DTO;

public class RolePermissionDTO {
	
	private RoleDTO roleDto;
	private SubSectionDTO subSectionDTO;
	
	public RoleDTO getRoleDto() {
		return roleDto;
	}
	public void setRoleDto(RoleDTO roleDto) {
		this.roleDto = roleDto;
	}
	public SubSectionDTO getSubSectionDTO() {
		return subSectionDTO;
	}
	public void setSubSectionDTO(SubSectionDTO subSectionDTO) {
		this.subSectionDTO = subSectionDTO;
	}
	
	public RolePermissionDTO() {
		System.out.println("RolePermissionDTO created");
	}

}
