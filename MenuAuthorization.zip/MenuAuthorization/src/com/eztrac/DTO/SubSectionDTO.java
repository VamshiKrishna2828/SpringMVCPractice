package com.eztrac.DTO;

public class SubSectionDTO {

	private Integer subSectionId;
	private String subSectionName;

	public Integer getSubSectionId() {
		return subSectionId;
	}

	public void setSubSectionId(Integer subSectionId) {
		this.subSectionId = subSectionId;
	}

	public String getSubSectionName() {
		return subSectionName;
	}

	public void setSubSectionName(String subSectionName) {
		this.subSectionName = subSectionName;
	}

	@Override
	public String toString() {
		return "SubSectionDTO [subSectionId=" + subSectionId + ", subSectionName=" + subSectionName
				+ ", getSubSectionId()=" + getSubSectionId() + ", getSubSectionName()=" + getSubSectionName()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}

	public SubSectionDTO() {
		System.out.println("SubSectionDTO created");
	}
}
