package com.capg.DAOInt;

import java.util.List;

import com.capg.JavaBeans.Per;

public interface PerDAOInt {
	
	public void deletePER();
	public void updatePER();
	public List<Per> getPERList();
	public void savePER(Per perBean);
	public List<Per> getPerListbySearechId(String perId);
	
}
