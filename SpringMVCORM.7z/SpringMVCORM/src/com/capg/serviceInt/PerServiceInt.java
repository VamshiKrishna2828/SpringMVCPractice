package com.capg.serviceInt;

import java.util.List;

import com.capg.JavaBeans.Per;

public interface PerServiceInt {
	
	public void deletePER();
	public void updatePER();
	public List<Per> getPERList();
	void savePER(Per perBean);
	public List<Per> getPerListbySearechId(String perId);
}
