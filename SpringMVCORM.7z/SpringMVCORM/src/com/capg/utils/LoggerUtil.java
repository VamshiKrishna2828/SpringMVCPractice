package com.capg.utils;

import org.apache.logging.log4j.LogManager;;

public class LoggerUtil extends LogManager


{/*

	/*final Logger logger=null;
	
	protected LoggerUtil(String name) {
		super(name);
	}

	@Override
	public void info(Object message) {
		logger.info(message);
	}
	
	public void info(Object message,Throwable t) {
		logger.info(message,t);
	}
	
	public void debug(Object message) {
		logger.debug(message);
	}
	
	public void debug(Object message,Throwable t) {
		logger.debug(message,t);
	}

	public void warn(Object message) {
		logger.warn(message);
	}

	public void warn(Object message, Throwable t) {
		logger.warn(message, t);
	}

	public void fatal(Object message) {
		logger.fatal(message);
	}

	public void fatal(Object message,Throwable t) {
		logger.fatal(message,t);
	}
	
	public void error(Object message) {
		logger.error(message);
	}

	public void error(Object message,Throwable t) {
		logger.error(message,t);
	}
	
	public void trace(Object message) {
		logger.trace(message);
	}

	public void trace(Object message,Throwable t) {
		logger.trace(message,t);
		//logger.
	}

	@Override
	public void catching(Throwable arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void catching(Level arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Message arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(MessageSupplier arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(CharSequence arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Supplier<?> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, Message arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, MessageSupplier arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, CharSequence arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, Supplier<?> arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Message arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(MessageSupplier arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(CharSequence arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Supplier<?>... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Supplier<?> arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, Message arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, MessageSupplier arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, CharSequence arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, Object arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Supplier<?>... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, Supplier<?> arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void debug(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10, Object arg11) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void entry() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void entry(Object... arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Message arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(MessageSupplier arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(CharSequence arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Supplier<?> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, Message arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, MessageSupplier arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, CharSequence arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, Supplier<?> arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Message arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(MessageSupplier arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(CharSequence arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Supplier<?>... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Supplier<?> arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, Message arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, MessageSupplier arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, CharSequence arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, Object arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Supplier<?>... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, Supplier<?> arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void error(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10, Object arg11) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void exit() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <R> R exit(R arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void fatal(Message arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(MessageSupplier arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(CharSequence arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Supplier<?> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, Message arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, MessageSupplier arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, CharSequence arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, Supplier<?> arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Message arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(MessageSupplier arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(CharSequence arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Supplier<?>... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Supplier<?> arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, Message arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, MessageSupplier arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, CharSequence arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, Object arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Supplier<?>... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, Supplier<?> arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fatal(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10, Object arg11) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Level getLevel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <MF extends MessageFactory> MF getMessageFactory() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void info(Message arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(MessageSupplier arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(CharSequence arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Supplier<?> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, Message arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, MessageSupplier arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, CharSequence arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, Supplier<?> arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Message arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(MessageSupplier arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(CharSequence arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Supplier<?>... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Supplier<?> arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, Message arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, MessageSupplier arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, CharSequence arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, Object arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Supplier<?>... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, Supplier<?> arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void info(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10, Object arg11) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isDebugEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDebugEnabled(Marker arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled(Level arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isEnabled(Level arg0, Marker arg1) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isErrorEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isErrorEnabled(Marker arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isFatalEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isFatalEnabled(Marker arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isInfoEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isInfoEnabled(Marker arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isTraceEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isTraceEnabled(Marker arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isWarnEnabled() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isWarnEnabled(Marker arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void log(Level arg0, Message arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, MessageSupplier arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, CharSequence arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Supplier<?> arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, Message arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, MessageSupplier arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, CharSequence arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, Supplier<?> arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Message arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, MessageSupplier arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, CharSequence arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Object arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Supplier<?>... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Supplier<?> arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, Message arg2, Throwable arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, MessageSupplier arg2, Throwable arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, CharSequence arg2, Throwable arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, Object arg2, Throwable arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object... arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Supplier<?>... arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Throwable arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, Supplier<?> arg2, Throwable arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10, Object arg11) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10, Object arg11) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void log(Level arg0, Marker arg1, String arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10, Object arg11, Object arg12) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printf(Level arg0, String arg1, Object... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printf(Level arg0, Marker arg1, String arg2, Object... arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <T extends Throwable> T throwing(T arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T extends Throwable> T throwing(Level arg0, T arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void trace(Message arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(MessageSupplier arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(CharSequence arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Supplier<?> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, Message arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, MessageSupplier arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, CharSequence arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, Supplier<?> arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Message arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(MessageSupplier arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(CharSequence arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Supplier<?>... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Supplier<?> arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, Message arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, MessageSupplier arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, CharSequence arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, Object arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Supplier<?>... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, Supplier<?> arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trace(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10, Object arg11) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public EntryMessage traceEntry() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EntryMessage traceEntry(Supplier<?>... arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EntryMessage traceEntry(Message arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EntryMessage traceEntry(String arg0, Object... arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EntryMessage traceEntry(String arg0, Supplier<?>... arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void traceExit() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <R> R traceExit(R arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void traceExit(EntryMessage arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public <R> R traceExit(String arg0, R arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <R> R traceExit(EntryMessage arg0, R arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <R> R traceExit(Message arg0, R arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void warn(Message arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(MessageSupplier arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(CharSequence arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Supplier<?> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, Message arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, MessageSupplier arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, CharSequence arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, Supplier<?> arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Message arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(MessageSupplier arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(CharSequence arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Supplier<?>... arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Supplier<?> arg0, Throwable arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, Message arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, MessageSupplier arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, CharSequence arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, Object arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Supplier<?>... arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, Supplier<?> arg1, Throwable arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1, Object arg2) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1, Object arg2, Object arg3) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1, Object arg2, Object arg3, Object arg4) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(String arg0, Object arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void warn(Marker arg0, String arg1, Object arg2, Object arg3, Object arg4, Object arg5, Object arg6,
			Object arg7, Object arg8, Object arg9, Object arg10, Object arg11) {
		// TODO Auto-generated method stub
		
	}
	
	

*/}
