package com.capg.DAOImpl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Repository;

import com.capg.DAOInt.UserDAOInterface;
import com.capg.JavaBeans.User;

@Repository
public class UserDAOImpl implements UserDAOInterface {
	
	Logger logger = LogManager.getRootLogger(); 
	
	@Autowired
	private DriverManagerDataSource dataSource;
		
	public DriverManagerDataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DriverManagerDataSource dataSource) {
		this.dataSource = dataSource;
	}

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFacory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/*public static Logger getLogger() {
		return logger;
	}*/
	/*public AnnotationSessionFactoryBean getSessionFactory() {
		return sessionFactory;
	}*/

	@Override
	/*@Transactional*/
	public void save(User user) {
		System.out.println(dataSource+" "+"is the datasource");
		System.out.println(sessionFactory+" "+"is sessionFactory object autowired");
		sessionFactory.openSession().save(user);
	}

	@Override
	public void update(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public User getUser(User user) {
		String query = "select * from User where username="+"'"+user.getUsername()+"' and "+"password="+"'"+user.getPassword()+"'";
		SQLQuery queryObj = sessionFactory.openSession().createSQLQuery(query);
		@SuppressWarnings("unchecked")
		List<Object[]> rows = queryObj.list();
		if(rows.size()!=0){
			for(Object[] row : rows){
				if(row[0].toString()!=null && row[1].toString()!=null && row[2].toString()!=null){
					user.setUserid(Integer.parseInt(row[0].toString()));
					user.setUsername(row[1].toString());
					user.setPassword(row[2].toString());
				}
			}
			return user;
		}
		else{
			return null;
		}
	}

}
