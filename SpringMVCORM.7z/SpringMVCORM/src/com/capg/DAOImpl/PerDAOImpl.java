package com.capg.DAOImpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capg.DAOInt.PerDAOInt;
import com.capg.JavaBeans.Per;

@Repository
public class PerDAOImpl implements PerDAOInt {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFacory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	//private static final DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	@Override
	public void savePER(Per per) {
		sessionFactory.openSession().save(per);
	}

	@Override
	public void deletePER() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updatePER() {
		// TODO Auto-generated method stub

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Per> getPERList() {
		Per per = (Per) sessionFactory.openSession().get(Per.class, 1);
		Query query = sessionFactory.openSession().createQuery("from Per");
		List<Per> perList = query.list();
		return perList;
	}
	public  List<Per> getPerListbySearechId(String perId){
		Criteria query = sessionFactory.openSession().createCriteria(Per.class);
		query.add(Restrictions.like("perId", perId, MatchMode.START));
		List<Per> result = query.list();
		System.out.println(result);
		return result;
	}
}
