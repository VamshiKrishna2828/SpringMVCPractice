package com.capg.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capg.JavaBeans.User;
import com.capg.serviceInt.UserServiceInterface;

@Controller
public class WelcomeController {
	
	//private static Logger logger = Logger.getLogger(WelcomeController.class);
	Logger logger = LogManager.getRootLogger(); 
	
	@Autowired
	private UserServiceInterface usi;
		
	public UserServiceInterface getUsi() {
		return usi;
	}

	public void setUsi(UserServiceInterface usi) {
		this.usi = usi;
	}

	@RequestMapping("/preLogin")
	public ModelAndView message(){
		if(logger.isDebugEnabled()){
			logger.debug("showPER is executed!");
		}
		String message = "Please Login";
		return new ModelAndView("Login","message",message);
	}
	
	@RequestMapping("/userLoginCheck.html")
	public ModelAndView loginCheck(@ModelAttribute("user") User user){
		if(logger.isDebugEnabled()){
			logger.debug("showPER is executed!");
		}
		user = usi.getUser(user);
		ModelAndView model;
		if(user!=null){
			model = new ModelAndView("LoginSuccess");
			model.addObject("message","Welcome to EzTrac System");
		}
		else{
			model = new ModelAndView("Login");
			model.addObject("errormessage","Please Provide Valid Username and Password");
		}
		return model;
	}
	
	@RequestMapping("/saveUser.html")
	public ModelAndView saveUser(@ModelAttribute("user") User user){
		if(logger.isDebugEnabled()){
			logger.debug("showPER is executed!");
		}
		ModelAndView model = new ModelAndView("LoginSuccess");
		model.addObject("message","Welcome to EzTrac System");
		usi.save(user);
		return model;
	}
}
