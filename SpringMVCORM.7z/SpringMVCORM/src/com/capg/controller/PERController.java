package com.capg.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.capg.JavaBeans.Per;
import com.capg.serviceInt.PerServiceInt;
import com.google.gson.Gson;

@Controller
public class PERController {
	
	///private static Logger logger = Logger.getLogger(PerController.class);
	
	Logger logger = LogManager.getRootLogger(); 
	@Autowired
	private PerServiceInt perService;
	
	public PerServiceInt getPerService() {
		return perService;
	}
	public void setPerService(PerServiceInt perService) {
		this.perService = perService;
	} 
	
	@RequestMapping(value="/per.html")
	public ModelAndView showPER(){
		if(logger.isDebugEnabled()){
			logger.debug("In DEBUG");
		}
		List<Per> perList = perService.getPERList();
		//System.out.println(perList.size());
		ModelAndView model = new ModelAndView("PERList");
		model.addObject(perList);
		model.addObject("message", "PERList");
		return model;
	}
	@RequestMapping("/newPER.html")
	public ModelAndView showNewPER(){
		if(logger.isDebugEnabled()){
			logger.debug("showPER is executed!");
		}
		Per per = new Per();
		ModelAndView model = new ModelAndView("Per");
		model.addObject("per", per);
		model.addObject("message", "Project Estimation Request");
		return model;
	}
	@RequestMapping(value="/savePER.html", method=RequestMethod.POST)
	public ModelAndView savePER(@ModelAttribute("per") @Valid Per per,BindingResult result){
		if(result.hasErrors()){
			System.out.println("In hasErrors()"+result.getErrorCount());
			ModelAndView model = new ModelAndView("Per");
			Map<String,String> results=new HashMap<String,String>();
			results.put("errorCount",""+result.getErrorCount());
			model.addAllObjects(results);
			return model;
		}
		perService.savePER(per);
		List<Per> perList = perService.getPERList();
		ModelAndView model = new ModelAndView("PERList");
		model.addObject("message", "PER List");
		model.addObject(perList);
		return model;
	}
	
	@RequestMapping(value="/serchPerId", method=RequestMethod.GET)
	public @ResponseBody String searchAutoComplete(@RequestParam(value = "perId") String perId){
		System.out.println(perId+" Is my PerID");
		List<Per> result= perService.getPerListbySearechId(perId);
		System.out.println(result);
		String json_n = new Gson().toJson(result);
		System.out.println(json_n);
		return json_n;
	}
	
}
