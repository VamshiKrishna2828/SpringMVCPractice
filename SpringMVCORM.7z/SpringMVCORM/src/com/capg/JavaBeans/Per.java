package com.capg.JavaBeans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "per")
public class Per {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(name = "PerId", nullable=false)
	@NotBlank(message="Cannot be blank")
	private String perId;
	
	
	@NotBlank(message="Cannot be blank")
	private String shortdesc;
	
	@Column(name = "receiptDate")
	@DateTimeFormat(pattern="MM/dd/yyyy")
	private Date receiptDate;
	
	// private List<String> occToNot;
	// private List<String> managersToNot;
	public String getPerId() {
		return perId;
	}

	public void setPerId(String perId) {
		this.perId = perId;
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	/*
	 * public List<String> getOccToNot() { return occToNot; }
	 * 
	 * public void setOccToNot(List<String> occToNot) { this.occToNot =
	 * occToNot; }
	 * 
	 * public List<String> getManagersToNot() { return managersToNot; }
	 * 
	 * public void setManagersToNot(List<String> managersToNot) {
	 * this.managersToNot = managersToNot; }
	 */
	public String getShortdesc() {
		return shortdesc;
	}

	public void setShortdesc(String shortdesc) {
		this.shortdesc = shortdesc;
	}

	public Date getReceiptDate() {
		return receiptDate;
	}

	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}
	
	@Override
	public String toString() {
		return "Per [PerId=" + perId + ", Short Description=" + shortdesc + ", Receipt Date=" + receiptDate+"]";
	}

}
