package com.capg.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.DAOInt.UserDAOInterface;
import com.capg.JavaBeans.User;
import com.capg.serviceInt.UserServiceInterface;


@Service
public class UserServiceImpl implements UserServiceInterface {
	
	@Autowired
	private UserDAOInterface udi;
	
	public UserDAOInterface getUdi() {
		return udi;
	}

	public void setUdi(UserDAOInterface udi) {
		this.udi = udi;
	}

	@Override
	public void save(User user) {
		udi.save(user);
	}

	@Override
	public void update(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public User getUser(User user) {
		return udi.getUser(user);
	}

}
