package com.capg.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.DAOInt.PerDAOInt;
import com.capg.JavaBeans.Per;
import com.capg.serviceInt.PerServiceInt;

@Service
public class PerServiceImpl implements PerServiceInt {
	
	@Autowired
	private PerDAOInt perDAOInt;
	
	public PerDAOInt getPerDAOInt() {
		return perDAOInt;
	}

	public void setPerDAOInt(PerDAOInt perDAOInt) {
		this.perDAOInt = perDAOInt;
	}

	@Override
	public void deletePER() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updatePER() {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Per> getPERList() {
		return perDAOInt.getPERList();
	}

	@Override
	public void savePER(Per perBean) {
		perDAOInt.savePER(perBean);
	}

	@Override
	public List<Per> getPerListbySearechId(String perId) {
		return perDAOInt.getPerListbySearechId(perId);
	}
	
	

}
